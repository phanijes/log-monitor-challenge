#!/usr/bin/env sh
set -e
KONG_SPECS_FOLDER="${KONG_API_FOLDER}/configurations/kong"
if [ $# -eq 0 ]; then
    echo "No arguments supplied"
    exit 1
fi
if [ "$1" != "diff" ] && [ "$1" != "sync" ];  then
    echo "Only diff & sync are supported"
    exit 1
fi
if [ -z "$(ls -A ${KONG_SPECS_FOLDER})" ]; then
    echo "Kong configs folder is empty"
    exit 1
fi

for f in ${KONG_SPECS_FOLDER}/${ENV}/*/spec.yaml; do
    folderpath="$(dirname $f)"
    tagname="$(basename $folderpath)"
    echo "Adding configuration for ${tagname}:"

    cat "$f" | deck gateway $1 --select-tag "${tagname}" --headers "kong-admin-token:${KONG_TOKEN}" --kong-addr "${KONG_ADMIN_URL}" --headers "Accept:application/json";
done
