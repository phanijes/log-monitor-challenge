#!/usr/bin/env python3

import os
from glob import glob
from openapi_spec_validator import validate
from openapi_spec_validator.readers import read_from_filename

def validate_openapi_spec_format():
    openapispec_files = [openapi_file_path for dirpath, _, _ in os.walk("configurations/openapi") for openapi_file_path in glob(os.path.join(dirpath, 'openapi.yaml'))]

    print(f"Files to validate: {openapispec_files}")

    for openapi_spec_file in openapispec_files:
        spec_dict, _ = read_from_filename(openapi_spec_file)
        # If no exception is raised by validate(), the spec is valid
        validate(spec_dict)
        print(f"OK - {openapi_spec_file}")

validate_openapi_spec_format()
