import argparse


class Cli(object):
    """Input parameters processing"""

    def __init__(self):
        self.parser = argparse.ArgumentParser()
        self.parser.add_argument("--source", help="base folder containing the openapi specs", default="./configurations/openapi")
        self.parser.add_argument("--generated", help="folder to store generation results", default="./configurations/generated")
        self.parser.add_argument("--target", help="folder to store generation results", default="./configurations/kong")
        self.parser.add_argument("--static", help="folder to store generation results", default="./configurations/static")
        self.parser.add_argument("--config", help="configuration file", default="./configurations/config.yaml")
        self.parser.add_argument("--envs", help="folder to store generation results", nargs="+", default=["dev", "tst", "ppr", "prd"])

    def generate_args(self, commands):
        try:
            args = self.parser.parse_args(commands)
            if args.target and args.source and args.generated:
                return args
        except argparse.ArgumentTypeError as e:
            print("Invalid command line argument. See --help.")
            print(str(e))
        return None
