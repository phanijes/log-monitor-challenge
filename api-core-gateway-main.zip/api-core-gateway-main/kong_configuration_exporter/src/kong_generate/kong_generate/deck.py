import os
import subprocess


class DeckException(Exception):
    pass


class Deck(object):
    def openapi2kong(kong_spec_folder, openapi_file, kong_spec_file, api_name):
        output = subprocess.CompletedProcess("", -1)
        try:
            if not os.path.exists(kong_spec_folder):
                os.makedirs(kong_spec_folder)
            output = subprocess.run(
                ["deck", "file", "openapi2kong", "--uuid-base", api_name, "--spec", openapi_file, "-o", kong_spec_file],
                capture_output=True,
                timeout=5,
                check=True,
            )
        except subprocess.CalledProcessError as e:
            print_and_raise_error(f"failed to execute deck file openapi2kong for {openapi_file}", e, output)

    def tag(kong_spec_file, api_name):
        output = subprocess.CompletedProcess("", -1)
        try:
            output = subprocess.run(
                ["deck", "file", "add-tags", "-s", kong_spec_file, "-o", kong_spec_file, api_name],
                capture_output=True,
                timeout=5,
                check=True,
            )
        except subprocess.CalledProcessError as e:
            print_and_raise_error(f"failed to execute deck file tag for {api_name}", e, output)

    def patch_value(kong_spec_file, selector, value):
        output = subprocess.CompletedProcess("", -1)
        try:
            output = subprocess.run(
                ["deck", "file", "patch", "-s", kong_spec_file, "-o", kong_spec_file, "--selector", selector, "--value", value],
                capture_output=True,
                timeout=5,
                check=True,
            )
        except subprocess.CalledProcessError as e:
            print_and_raise_error(f"failed to execute deck file patch for {selector} {value}", e, output)

    def validate(kong_spec_file):
        output = subprocess.CompletedProcess("", -1)
        try:
            output = subprocess.run(
                ["deck", "file", "validate", kong_spec_file],
                capture_output=True,
                timeout=5,
                check=True,
            )
        except subprocess.CalledProcessError as e:
            print_and_raise_error(f"kong spec validation failed for {kong_spec_file}", e, output)


def print_and_raise_error(msg, e, output):
    print(msg)
    print(str(e))
    print(output.stderr)
    print(output.stdout)
    raise DeckException(msg)
