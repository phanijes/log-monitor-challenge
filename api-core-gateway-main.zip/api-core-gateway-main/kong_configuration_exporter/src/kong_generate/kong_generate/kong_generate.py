#!/usr/bin/env python3

from deck import Deck
from cli import Cli

import sys
import os
import json
import mergedeep
import yaml
import shutil

PLUGIN_TEMPLATES_FOLDER = "./kong_generate/plugin_templates"
UPSTREAM_TEMPLATES_FOLDER = "./kong_generate/upstream_templates"
ENVIRONMENTS_SECTION = "environments"
TEMPORARY_SUBFOLDER = "temp"
API_NAME_VARIABLE = "api_name"
OPENAPI_FILENAME = "openapi.yaml"
CFG_FILENAME = "cfg.yaml"
KONG_SPEC_FILENAME = "spec.yaml"
OPEN_DEL = "<^"
CLOSE_DEL = "^>"


def parse_api_configuration(cfg_file):
    with open(cfg_file, "r") as f:
        cfg = yaml.load(f, Loader=yaml.SafeLoader)
    # TODO: validate the config
    return cfg["configuration"]


def add_plugins(kong_spec_file, api_cfg, plugin_templates, env):
    plugins = []
    plugin_configs = mergedeep.merge({}, api_cfg.get("plugins", {}), api_cfg.get(ENVIRONMENTS_SECTION, {}).get(env, {}).get("plugins", {}))
    for plugin_name in plugin_configs:
        template = plugin_templates[plugin_name]
        if template is None:
            raise ValueError(f"plugin {plugin_name} is unknown")
        plugin_cfg = plugin_configs[plugin_name]
        merged = mergedeep.merge({}, template, plugin_cfg)
        plugins.append(merged)
    Deck.patch_value(kong_spec_file, "$..services[*].plugins", json.dumps(plugins))


def add_upstreams(kong_spec_file, api_cfg, env):
    upstream_configs = api_cfg.get(ENVIRONMENTS_SECTION, {}).get(env, {}).get("upstreams", [])
    if len(upstream_configs) == 0:
        upstream_configs = api_cfg.get("upstreams", [])
    if len(upstream_configs) == 0:
        return

    with open(UPSTREAM_TEMPLATES_FOLDER + "/upstream.yaml", "r") as ff:
        upstream_template = yaml.load(ff, Loader=yaml.SafeLoader)

    def apply_upstream_template(upstream):
        merged = mergedeep.merge({}, upstream_template, upstream)
        return merged

    upstreams = map(apply_upstream_template, upstream_configs)
    upstreams = list(upstreams)
    Deck.patch_value(kong_spec_file, "$..upstreams", json.dumps(upstreams))


def fix_openapi_conversion(kong_spec_file, api_name, api_cfg):
    # set placeholder for the back-end URL
    Deck.patch_value(kong_spec_file, "$..services[*]", f'host:"{OPEN_DEL}backend_url{CLOSE_DEL}"')
    # use api_name as service name
    Deck.patch_value(kong_spec_file, "$..services[*]", f'name: "{api_name}"')
    # deck patch is dumb - it will always append the value even if it exists already. Works for now, but we will need a better solution in future.
    Deck.patch_value(kong_spec_file, "$..routes[*].methods", '["OPTIONS"]')
    # remove basepath from back-end
    Deck.patch_value(kong_spec_file, "$..services[*]", "path:")
    # and set it for each route
    add_base_path(kong_spec_file, api_cfg)


def customize_spec(kong_spec_file, api_cfg, env):
    plugins = read_plugin_templates()
    add_plugins(kong_spec_file, api_cfg, plugins, env)
    add_upstreams(kong_spec_file, api_cfg, env)


def add_base_path(kong_spec_file, api_cfg):
    base_path = api_cfg["base_path"]
    with open(kong_spec_file, "r+") as f:
        kong_spec = yaml.load(f, Loader=yaml.SafeLoader)
        for svc in kong_spec["services"]:
            for route in svc["routes"]:
                route["paths"][0] = route["paths"][0].replace("~/", f"~{base_path}/")
        yaml.safe_dump(kong_spec, f)


def read_plugin_templates():
    plugins = {}
    for f in os.scandir(PLUGIN_TEMPLATES_FOLDER):
        if not f.is_file():
            continue
        with open(f.path, "r") as ff:
            payload = yaml.load(ff, Loader=yaml.SafeLoader)
        plugin_name = payload["name"]
        plugins[plugin_name] = payload
    return plugins


def generate_base_kong_specs(source_folder, generated_folder):
    """Generate base Kong specs from openapi specs"""
    source_folders = [f.name for f in os.scandir(source_folder) if f.is_dir()]
    for src_folder in source_folders:
        print(f"generating kong spec for api '{src_folder}'... ")
        try:
            # prepare source files
            openapi_folder = os.path.join(source_folder, src_folder)
            openapi_file = os.path.join(openapi_folder, OPENAPI_FILENAME)
            cfg_file = os.path.join(openapi_folder, CFG_FILENAME)

            api_cfg = parse_api_configuration(cfg_file)
            # replace '/'s and remove the root one
            api_name = api_cfg["base_path"].replace("/", "_")[1:]

            # prepare base spec files
            kong_spec_folder = os.path.join(generated_folder, api_name)
            kong_spec_file = os.path.join(kong_spec_folder, KONG_SPEC_FILENAME)

            Deck.openapi2kong(kong_spec_folder, openapi_file, kong_spec_file, api_name)
            fix_openapi_conversion(kong_spec_file, api_name, api_cfg)
            Deck.validate(kong_spec_file)
            # copy config file to generated folder.
            shutil.copyfile(cfg_file, os.path.join(kong_spec_folder, CFG_FILENAME))
            print(f"generating base kong spec for '{src_folder}'... done")
        except Exception as e:
            print("error generating Kong spec")
            print(str(e))
            return False
    return True


def generate_environments(config, base_spec_file, generated_folder, target_folder, api_name, envs, api_cfg):
    # TODO: validate environments with known list - to avoid typos, etc.
    for env in envs:
        env_cfg = api_cfg[ENVIRONMENTS_SECTION].get(env, None)
        if env_cfg is None:
            print(f"\tno configuration for {env} for api '{api_name}'. Skipped.")
            continue
        print(f"\tgenerating environment {env} for api '{api_name}'... ")

        temp_env_spec_folder = os.path.join(generated_folder, TEMPORARY_SUBFOLDER, env, api_name)
        temp_env_spec_file = os.path.join(temp_env_spec_folder, KONG_SPEC_FILENAME)
        if not os.path.exists(temp_env_spec_folder):
            os.makedirs(temp_env_spec_folder)
        shutil.copyfile(base_spec_file, temp_env_spec_file)

        print("\t\tbuilding spec file")
        customize_spec(temp_env_spec_file, api_cfg, env)
        Deck.tag(temp_env_spec_file, api_name)

        print("\t\tsetting environment variables")
        set_environment_variables(config, api_cfg, env_cfg, temp_env_spec_file, api_name, env)

        Deck.validate(temp_env_spec_file)

        env_spec_folder = os.path.join(target_folder, env, api_name)
        env_spec_file = os.path.join(env_spec_folder, KONG_SPEC_FILENAME)
        if not os.path.exists(env_spec_folder):
            os.makedirs(env_spec_folder)
        print("\t\tcopying results to target location")
        shutil.copyfile(temp_env_spec_file, env_spec_file)
        print(f"\tgenerating environment {env} for api '{api_name}'... done")
    return True


def set_environment_variables(config, api_cfg, env_cfg, kong_spec_file, api_name, env):
    with open(kong_spec_file, "r") as f:
        base_spec = f.read()

    spec = apply_variables_to_placeholders(config, api_cfg, base_spec, api_name, env)
    if not spec:
        # TODO: better output?
        print(f"failed to replace environment parameters, list of values {env_cfg}")
        return False

    with open(kong_spec_file, "w") as f:
        f.write(spec)


def apply_variables_to_placeholders(config, api_cfg, spec, api_name, env):

    # TODO: do we need to stringify all the values?
    # shallow merge is enough here - variables should be simple values like string or number
    env_cfg = api_cfg.get(ENVIRONMENTS_SECTION, {}).get(env, {}).get("variables", {}) | config.get(ENVIRONMENTS_SECTION, {}).get(env, {}).get("variables", {})
    # add api_name to variables
    env_cfg[API_NAME_VARIABLE] = api_name
    environment_settings_per_environment = {key.lower().replace(f"{env.lower()}_", ""): value for key, value in os.environ.items() if key.lower().startswith(f"{env}_".lower())}
    env_cfg = env_cfg | environment_settings_per_environment
    # replace all the environment parameters
    try:
        # multiple passes to allow using variables in variables. Up to 5 levels for now.
        for _ in range(5):
            # escape {} values and enable string formatting
            spec = spec.replace("{", "|<|").replace("}", "|>|").replace(OPEN_DEL, "{").replace(CLOSE_DEL, "}")
            spec = spec.format(**env_cfg)
            # unescape {} values
            spec = spec.replace("|<|", "{").replace("|>|", "}")
    except Exception as e:
        print(str(e))
        return None
    return spec


def generate_kong_specs_per_environment(config, generated_folder, target_folder, envs):
    spec_folders = [f.name for f in os.scandir(generated_folder) if f.is_dir()]
    # as folder structure is auto-generated, we can be sure that folder name = api name
    for api_name in spec_folders:
        if api_name == TEMPORARY_SUBFOLDER:
            continue
        print(f"generating environments for spec '{api_name}'... ")
        try:
            # prepare source files
            kong_spec_folder = os.path.join(generated_folder, api_name)
            kong_spec_file = os.path.join(kong_spec_folder, KONG_SPEC_FILENAME)
            cfg_file = os.path.join(kong_spec_folder, CFG_FILENAME)
            api_cfg = parse_api_configuration(cfg_file)

            print(f"generating environments for spec '{api_name}'... done")
            generate_environments(config, kong_spec_file, generated_folder, target_folder, api_name, envs, api_cfg)
        except Exception as e:
            print("error generating environments")
            print(str(e))
            return False
    return True


def load_configuration(config_file_path):
    with open(config_file_path, "r") as ff:
        payload = yaml.load(ff, Loader=yaml.SafeLoader)
    return payload


def main():
    """Main entrypoint"""
    # verify env vars and input
    args = Cli().generate_args(sys.argv[1:])
    if args is None:
        print("No command specified.  See --help.")
        sys.exit(4)
    # clean-up the generated folder if it exists
    if os.path.exists(args.generated):
        shutil.rmtree(args.generated)
    # load configuration file
    config = load_configuration(args.config)
    # TODO: verify openapi specs
    # generate base kong spec from openapi for each API and store it in the base location location
    # for each env - parametrize the kong config according to params file (must be present)
    if not generate_base_kong_specs(args.source, args.generated):
        sys.exit(101)
    # copy static (native Kong) specs
    # shutil.copytree(args.static, args.generated, dirs_exist_ok=True)
    if not generate_kong_specs_per_environment(config, args.generated, args.target, args.envs):
        sys.exit(102)


if __name__ == "__main__":
    main()
