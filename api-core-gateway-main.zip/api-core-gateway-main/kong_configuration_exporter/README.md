## Gitlab pipeline usage:
**kong-config-remove** (manual) \
    Configuration:
    - **CONFIG_TAGS_TO_REMOVE** - all resources with the provided tags will be removed.

## Openapi to Kong convertion overview 
    Opeanpi schemas should be stored in 'configurations/openapi' folder. Each schema must be named 'openapi.yaml' and have its own folder (name does not matter). Along with schema, a configuration file 'cfg.yaml' must be created.
    Each API is tagged with basepath (with '/' replaced by '_'). This allows us to enable single API level updates via decK by using tag-selector.
    Kong decK tool is used for initial conversion and patching; additional transformation and parameters injection is done after that.
    First, base Kong spec version is created, with all the required plugins, routes, etc. in 'configurations/generated' folder. This base spec has placeholders in format '<^variable_name^>' for environment dependent parameters.
    Next, per-environment configurations are created from base spec by replacing all the placeholders with the actual values suitable for the target environment. The resulted specs are stored in 'configurations/kong/$ENV/$api_tag' folder.
    Additionally, non-openapi (native Kong) specs are supported as well - they must be added to the 'configurations/static' folder (per environment for now, so in '$ENV/$api_tag' subfolder each).

### sample cfg.yaml structure
configuration:
  base_path: /data-discovery/v1
  plugins:
    cors: {}
    request-transformer: 
      config:
        replace:
          headers:
          - Host:<^transformer_url^>
  environments:
    dev:
      backend_url: 1.1.1.1
      transformer_url: back-end.dev.example.com
    tst:
      backend_url: 2.2.2.2
      transformer_url: back-end.tst.example.com

- **base_path** is mandatory - it is used ass a prefix for all API routes.
- **plugin** sections serves 2 purposes: listing plugins which must be added to the API, and adding custom configuration for the plugins (may contain placeholders). The custom configuration will be merged with the base template of the plugin.
- **environments** section allows to define environment specific variables for the API. This section must be present for all the environments the API must be present in (even if no variables are required). Additionally, if spec contains placeholders - they all must be populated here for each environment.
