import yaml
import os
import re
 
def load_env_variables(prefix):
    """Load environment variables that match a given prefix."""
    myPattern = re.compile(r'{prefix}\w+'.format(prefix=prefix))
    my_env_variables = {key.replace(prefix, '').lower(): val for key, val in os.environ.items() if myPattern.match(key)}
    return my_env_variables
 
def update_yaml_config(cfg_file_path, env_prefix):
    """Update the YAML configuration based on environment variables with a specific prefix."""
    # Load the YAML file
    with open(cfg_file_path, 'r') as file:
        yaml_dict = yaml.safe_load(file)
 
    current_env = os.getenv('ENV')
  
    env_variables = load_env_variables(env_prefix)
  
    if current_env in yaml_dict['configuration']['environments']:
        env_config = yaml_dict['configuration']['environments'][current_env]
       
        for key, value in env_variables.items():
            yaml_key = f"{key}"  
            if yaml_key in env_config:
                env_config[yaml_key] = f"{value}:443"
 
  
    with open(cfg_file_path, 'w') as file:
        yaml.dump(yaml_dict, file, default_flow_style=False, sort_keys=False)
    print(f"Configuration file for '{current_env}' environment updated and written to '{cfg_file_path}'")
 

cfg_file_path_ddisc = 'src/kong_generate/configurations/openapi/datadiscoveryv1/cfg.yaml'
cfg_file_path_bulk = 'src/kong_generate/configurations/openapi/fileretrievalv1/cfg.yaml'
ddisc_env_prefix = "DDISC_"
bulk_env_prefix = "BULK_"
 
update_yaml_config(cfg_file_path_ddisc, ddisc_env_prefix)
update_yaml_config(cfg_file_path_bulk, bulk_env_prefix)