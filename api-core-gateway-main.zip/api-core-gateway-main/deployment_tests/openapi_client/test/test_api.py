# from openapi_client import openapi_client
# from openapi_client.models.business_glossary_term_list import (
#     BusinessGlossaryTermList
# )
# from openapi_client.rest import ApiException
from pprint import pprint
from openapi_client.configuration import Configuration
from openapi_client.api_client import ApiClient
from openapi_client.api.business_glossary_terms_api import (
    BusinessGlossaryTermsApi
)
import os


# Defining the host is optional and defaults to http://localhost/data-discovery/v1
# See configuration.py for a list of all supported configuration parameters.
configuration = Configuration(
    host=os.environ["PPR_DD_API_URL"],
    access_token=os.environ["DD_BEARER_TOKEN"]
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization: BearerAuth
# configuration = Configuration(
#     access_token = os.environ["DD_BEARER_TOKEN"]
# )

# Enter a context with an instance of the API client
with ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = BusinessGlossaryTermsApi(api_client)
    limit = 56  # int | Number of results to be included in response, defaulting to 50 if not provided (optional)
    offset = 56  # int | An offset from which the list of results are retrieved, defaulting to 0 if not provided (optional)

    try:
        # Get a list of business glossary terms
        api_response = api_instance.business_glossary_term_interface_list(limit=limit, offset=offset)
        print("The response of BusinessGlossaryTermsApi->business_glossary_term_interface_list:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling BusinessGlossaryTermsApi->business_glossary_term_interface_list: %s\n" % e)