# MarketingDatasetReference

A marketing dataset reference

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **str** | Unique identifier for the resource | [readonly] 
**title** | **str** | Title or name of the resource | 

## Example

```python
from openapi_client.models.marketing_dataset_reference import MarketingDatasetReference

# TODO update the JSON string below
json = "{}"
# create an instance of MarketingDatasetReference from a JSON string
marketing_dataset_reference_instance = MarketingDatasetReference.from_json(json)
# print the JSON string representation of the object
print(MarketingDatasetReference.to_json())

# convert the object into a dict
marketing_dataset_reference_dict = marketing_dataset_reference_instance.to_dict()
# create an instance of MarketingDatasetReference from a dict
marketing_dataset_reference_from_dict = MarketingDatasetReference.from_dict(marketing_dataset_reference_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


