# openapi_client.BusinessGlossaryTermsApi

All URIs are relative to *http://localhost/data-discovery/v1*

Method | HTTP request | Description
------------- | ------------- | -------------
[**business_glossary_term_interface_get**](BusinessGlossaryTermsApi.md#business_glossary_term_interface_get) | **GET** /business-glossary-terms/{id} | Get a business glossary term by Id
[**business_glossary_term_interface_get_fields**](BusinessGlossaryTermsApi.md#business_glossary_term_interface_get_fields) | **GET** /business-glossary-terms/{id}/fields | Get a list of fields associated with a business glossary term
[**business_glossary_term_interface_list**](BusinessGlossaryTermsApi.md#business_glossary_term_interface_list) | **GET** /business-glossary-terms | Get a list of business glossary terms


# **business_glossary_term_interface_get**
> BusinessGlossaryTermDetail business_glossary_term_interface_get(id)

Get a business glossary term by Id

The endpoint returns a business glossary term

### Example

* Bearer Authentication (BearerAuth):

```python
import openapi_client
from openapi_client.models.business_glossary_term_detail import BusinessGlossaryTermDetail
from openapi_client.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost/data-discovery/v1
# See configuration.py for a list of all supported configuration parameters.
configuration = openapi_client.Configuration(
    host = "http://localhost/data-discovery/v1"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization: BearerAuth
configuration = openapi_client.Configuration(
    access_token = os.environ["DD_BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with openapi_client.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = openapi_client.BusinessGlossaryTermsApi(api_client)
    id = 'id_example' # str | The identifier for the business glossary term

    try:
        # Get a business glossary term by Id
        api_response = api_instance.business_glossary_term_interface_get(id)
        print("The response of BusinessGlossaryTermsApi->business_glossary_term_interface_get:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling BusinessGlossaryTermsApi->business_glossary_term_interface_get: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **str**| The identifier for the business glossary term | 

### Return type

[**BusinessGlossaryTermDetail**](BusinessGlossaryTermDetail.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | The request has succeeded. |  -  |
**400** | The server could not understand the request due to invalid syntax. |  -  |
**401** | Access is unauthorized. |  -  |
**403** | Access is forbidden |  -  |
**404** | The server cannot find the requested resource. |  -  |
**405** | Client error |  -  |
**408** | Client error |  -  |
**415** | Client error |  -  |
**429** | Client error |  -  |
**500** | Server error |  -  |
**502** | Server error |  -  |
**503** | Service unavailable. |  -  |
**504** | Server error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **business_glossary_term_interface_get_fields**
> FieldList business_glossary_term_interface_get_fields(id, limit=limit, offset=offset)

Get a list of fields associated with a business glossary term

Returns a list of fields

### Example

* Bearer Authentication (BearerAuth):

```python
import openapi_client
from openapi_client.models.field_list import FieldList
from openapi_client.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost/data-discovery/v1
# See configuration.py for a list of all supported configuration parameters.
configuration = openapi_client.Configuration(
    host = "http://localhost/data-discovery/v1"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization: BearerAuth
configuration = openapi_client.Configuration(
    access_token = os.environ["DD_BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with openapi_client.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = openapi_client.BusinessGlossaryTermsApi(api_client)
    id = 'id_example' # str | The identifier for the business glossary term
    limit = 56 # int | Number of results to be included in response, defaulting to 50 if not provided (optional)
    offset = 56 # int | An offset from which the list of results are retrieved, defaulting to 0 if not provided (optional)

    try:
        # Get a list of fields associated with a business glossary term
        api_response = api_instance.business_glossary_term_interface_get_fields(id, limit=limit, offset=offset)
        print("The response of BusinessGlossaryTermsApi->business_glossary_term_interface_get_fields:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling BusinessGlossaryTermsApi->business_glossary_term_interface_get_fields: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **str**| The identifier for the business glossary term | 
 **limit** | **int**| Number of results to be included in response, defaulting to 50 if not provided | [optional] 
 **offset** | **int**| An offset from which the list of results are retrieved, defaulting to 0 if not provided | [optional] 

### Return type

[**FieldList**](FieldList.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | The request has succeeded. |  -  |
**400** | The server could not understand the request due to invalid syntax. |  -  |
**401** | Access is unauthorized. |  -  |
**403** | Access is forbidden |  -  |
**404** | The server cannot find the requested resource. |  -  |
**405** | Client error |  -  |
**408** | Client error |  -  |
**415** | Client error |  -  |
**429** | Client error |  -  |
**500** | Server error |  -  |
**502** | Server error |  -  |
**503** | Service unavailable. |  -  |
**504** | Server error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **business_glossary_term_interface_list**
> BusinessGlossaryTermList business_glossary_term_interface_list(limit=limit, offset=offset)

Get a list of business glossary terms

The endpoint returns a list business glossary terms

### Example

* Bearer Authentication (BearerAuth):

```python
import openapi_client
from openapi_client.models.business_glossary_term_list import BusinessGlossaryTermList
from openapi_client.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost/data-discovery/v1
# See configuration.py for a list of all supported configuration parameters.
configuration = openapi_client.Configuration(
    host = "http://localhost/data-discovery/v1"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization: BearerAuth
configuration = openapi_client.Configuration(
    access_token = os.environ["DD_BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with openapi_client.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = openapi_client.BusinessGlossaryTermsApi(api_client)
    limit = 56 # int | Number of results to be included in response, defaulting to 50 if not provided (optional)
    offset = 56 # int | An offset from which the list of results are retrieved, defaulting to 0 if not provided (optional)

    try:
        # Get a list of business glossary terms
        api_response = api_instance.business_glossary_term_interface_list(limit=limit, offset=offset)
        print("The response of BusinessGlossaryTermsApi->business_glossary_term_interface_list:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling BusinessGlossaryTermsApi->business_glossary_term_interface_list: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **limit** | **int**| Number of results to be included in response, defaulting to 50 if not provided | [optional] 
 **offset** | **int**| An offset from which the list of results are retrieved, defaulting to 0 if not provided | [optional] 

### Return type

[**BusinessGlossaryTermList**](BusinessGlossaryTermList.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | The request has succeeded. |  -  |
**400** | The server could not understand the request due to invalid syntax. |  -  |
**401** | Access is unauthorized. |  -  |
**403** | Access is forbidden |  -  |
**404** | The server cannot find the requested resource. |  -  |
**405** | Client error |  -  |
**408** | Client error |  -  |
**415** | Client error |  -  |
**429** | Client error |  -  |
**500** | Server error |  -  |
**502** | Server error |  -  |
**503** | Service unavailable. |  -  |
**504** | Server error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

