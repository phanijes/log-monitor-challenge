# UseCasesAndArticlesLink

The link to use cases and articles

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **str** | Unique identifier for the resource | 
**entity_type** | **str** | Entity type | 
**title** | **str** | Title or name of the resource | 
**description** | **str** | Description | 
**url** | **str** | Publication link URL | 

## Example

```python
from openapi_client.models.use_cases_and_articles_link import UseCasesAndArticlesLink

# TODO update the JSON string below
json = "{}"
# create an instance of UseCasesAndArticlesLink from a JSON string
use_cases_and_articles_link_instance = UseCasesAndArticlesLink.from_json(json)
# print the JSON string representation of the object
print(UseCasesAndArticlesLink.to_json())

# convert the object into a dict
use_cases_and_articles_link_dict = use_cases_and_articles_link_instance.to_dict()
# create an instance of UseCasesAndArticlesLink from a dict
use_cases_and_articles_link_from_dict = UseCasesAndArticlesLink.from_dict(use_cases_and_articles_link_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


