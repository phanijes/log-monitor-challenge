# MarketingDatasetDetail

A marketing dataset detail

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**coverage_count** | **str** | Brief description of coverage | 
**data_types** | **str** | Data types | 
**features_and_benefits** | **str** | Features and benefits / what you get | 
**temporal_coverage_description** | **str** | Temporal coverage description | 
**temporal_coverage_year_to** | **int** | Year for which temporal coverage ends | 
**search_keywords** | **List[str]** | Search keywords | 
**related_datasets** | [**List[MarketingDataset]**](MarketingDataset.md) | Related datasets | 
**related_products** | [**List[DataProduct]**](DataProduct.md) | Related products | 
**use_cases_and_articles** | [**List[UseCasesAndArticlesLink]**](UseCasesAndArticlesLink.md) | Use cases and articles | 
**more_solutions** | [**List[DeliveryProductLink]**](DeliveryProductLink.md) | More solutions on LSEG.com | 
**tags** | **List[str]** | Tags | 
**landing_page** | **str** | Landing page link | 
**entity_type** | **str** | Entity type | 
**description** | **str** | Description | 
**primary_refinitiv_data_taxonomy** | **str** | Primary refinitiv data taxonomy/category | 
**temporal_coverage_year_from** | **int** | Year for which temporal coverage starts | 
**data_frequency_description** | **str** | Data frequency | 
**categories** | [**List[Category]**](Category.md) | Categories | 
**geography_description** | **str** | Geographical coverage / regions | 
**id** | **str** | Unique identifier for the resource | [readonly] 
**title** | **str** | Title or name of the resource | 

## Example

```python
from openapi_client.models.marketing_dataset_detail import MarketingDatasetDetail

# TODO update the JSON string below
json = "{}"
# create an instance of MarketingDatasetDetail from a JSON string
marketing_dataset_detail_instance = MarketingDatasetDetail.from_json(json)
# print the JSON string representation of the object
print(MarketingDatasetDetail.to_json())

# convert the object into a dict
marketing_dataset_detail_dict = marketing_dataset_detail_instance.to_dict()
# create an instance of MarketingDatasetDetail from a dict
marketing_dataset_detail_from_dict = MarketingDatasetDetail.from_dict(marketing_dataset_detail_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


