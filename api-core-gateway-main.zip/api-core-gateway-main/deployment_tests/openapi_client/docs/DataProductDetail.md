# DataProductDetail

A data product detail

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**features_and_benefits** | **str** | Features and benefits / what you get | 
**temporal_coverage_year_from** | **int** | Year for which temporal coverage starts | 
**geography_description** | **str** | Geographical coverage / regions | 
**data_frequency_description** | **str** | Data frequency description | 
**data_formats** | **List[str]** | Data formats | 
**file_formats** | **List[str]** | File formats | 
**related_products** | [**List[DataProductReference]**](DataProductReference.md) | Related products | 
**product_alerts_and_notifications** | [**List[ProductAlertsAndNotificationsItem]**](ProductAlertsAndNotificationsItem.md) | Product alerts and notifications | 
**use_cases_and_articles** | [**List[UseCasesAndArticlesLink]**](UseCasesAndArticlesLink.md) | Related use cases and articles | 
**rights_and_restrictions** | [**ProductRightsAndRestrictionsBlock**](ProductRightsAndRestrictionsBlock.md) | Product rights and restrictions | 
**tags** | **List[str]** | Tags | 
**entity_type** | **str** | Entity type | 
**description** | **str** | Description | 
**marketing_summary** | **str** | Marketing summary / short description | 
**commercial_product_title** | **str** | Commercial product that delivers the data product | 
**associated_datasets** | [**List[MarketingDataset]**](MarketingDataset.md) | Associated datasets | [optional] 
**delivery_methods** | [**List[DeliveryMechanism]**](DeliveryMechanism.md) | Delivery methods | 
**id** | **str** | Unique identifier for the resource | [readonly] 
**title** | **str** | Title or name of the resource | 

## Example

```python
from openapi_client.models.data_product_detail import DataProductDetail

# TODO update the JSON string below
json = "{}"
# create an instance of DataProductDetail from a JSON string
data_product_detail_instance = DataProductDetail.from_json(json)
# print the JSON string representation of the object
print(DataProductDetail.to_json())

# convert the object into a dict
data_product_detail_dict = data_product_detail_instance.to_dict()
# create an instance of DataProductDetail from a dict
data_product_detail_from_dict = DataProductDetail.from_dict(data_product_detail_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


