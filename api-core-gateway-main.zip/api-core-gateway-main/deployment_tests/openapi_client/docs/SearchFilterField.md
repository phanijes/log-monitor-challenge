# SearchFilterField

An enumeration with the available filter fields

## Enum

* `ID` (value: `'id'`)

* `ENTITYTYPE` (value: `'entityType'`)

* `COVERAGESTARTYEAR` (value: `'coverageStartYear'`)

* `PRODUCT` (value: `'product'`)

* `DELIVERYMETHOD` (value: `'deliveryMethod'`)

* `REGION` (value: `'region'`)

* `ACCESS` (value: `'access'`)

* `TAGS` (value: `'tags'`)

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


