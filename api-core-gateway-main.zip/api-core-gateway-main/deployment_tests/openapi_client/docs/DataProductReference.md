# DataProductReference

A data product reference

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **str** | Unique identifier for the resource | [readonly] 
**title** | **str** | Title or name of the resource | 

## Example

```python
from openapi_client.models.data_product_reference import DataProductReference

# TODO update the JSON string below
json = "{}"
# create an instance of DataProductReference from a JSON string
data_product_reference_instance = DataProductReference.from_json(json)
# print the JSON string representation of the object
print(DataProductReference.to_json())

# convert the object into a dict
data_product_reference_dict = data_product_reference_instance.to_dict()
# create an instance of DataProductReference from a dict
data_product_reference_from_dict = DataProductReference.from_dict(data_product_reference_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


