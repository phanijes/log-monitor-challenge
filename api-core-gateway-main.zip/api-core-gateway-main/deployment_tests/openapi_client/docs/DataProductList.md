# DataProductList

A list of data products

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**products** | [**List[DataProduct]**](DataProduct.md) | List of data products | 

## Example

```python
from openapi_client.models.data_product_list import DataProductList

# TODO update the JSON string below
json = "{}"
# create an instance of DataProductList from a JSON string
data_product_list_instance = DataProductList.from_json(json)
# print the JSON string representation of the object
print(DataProductList.to_json())

# convert the object into a dict
data_product_list_dict = data_product_list_instance.to_dict()
# create an instance of DataProductList from a dict
data_product_list_from_dict = DataProductList.from_dict(data_product_list_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


