# BusinessGlossaryTermSearchResult

A business glossary term search result

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**search_score** | **float** | Azure AI Search response search score | 
**entity_type** | **str** | Entity type | 
**description** | **str** | Description / definition | 
**associated_datasets** | [**List[MarketingDatasetReference]**](MarketingDatasetReference.md) | Associated datasets | [optional] 
**id** | **str** | Unique identifier for the resource | [readonly] 
**title** | **str** | Title or name of the resource | 

## Example

```python
from openapi_client.models.business_glossary_term_search_result import BusinessGlossaryTermSearchResult

# TODO update the JSON string below
json = "{}"
# create an instance of BusinessGlossaryTermSearchResult from a JSON string
business_glossary_term_search_result_instance = BusinessGlossaryTermSearchResult.from_json(json)
# print the JSON string representation of the object
print(BusinessGlossaryTermSearchResult.to_json())

# convert the object into a dict
business_glossary_term_search_result_dict = business_glossary_term_search_result_instance.to_dict()
# create an instance of BusinessGlossaryTermSearchResult from a dict
business_glossary_term_search_result_from_dict = BusinessGlossaryTermSearchResult.from_dict(business_glossary_term_search_result_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


