# DeliveryProductLink

The link to a delivery product

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **str** | Unique identifier for the resource | 
**entity_type** | **str** | Entity type | 
**title** | **str** | Title or name of the resource | 
**description** | **str** | Description | 

## Example

```python
from openapi_client.models.delivery_product_link import DeliveryProductLink

# TODO update the JSON string below
json = "{}"
# create an instance of DeliveryProductLink from a JSON string
delivery_product_link_instance = DeliveryProductLink.from_json(json)
# print the JSON string representation of the object
print(DeliveryProductLink.to_json())

# convert the object into a dict
delivery_product_link_dict = delivery_product_link_instance.to_dict()
# create an instance of DeliveryProductLink from a dict
delivery_product_link_from_dict = DeliveryProductLink.from_dict(delivery_product_link_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


