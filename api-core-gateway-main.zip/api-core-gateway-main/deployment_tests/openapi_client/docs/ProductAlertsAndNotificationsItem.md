# ProductAlertsAndNotificationsItem

The product alerts and notification item

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **str** | Unique identifier for the resource | 
**title** | **str** | Title or name of the resource | 
**effective_date** | **date** | Effective date of alert/notification | 

## Example

```python
from openapi_client.models.product_alerts_and_notifications_item import ProductAlertsAndNotificationsItem

# TODO update the JSON string below
json = "{}"
# create an instance of ProductAlertsAndNotificationsItem from a JSON string
product_alerts_and_notifications_item_instance = ProductAlertsAndNotificationsItem.from_json(json)
# print the JSON string representation of the object
print(ProductAlertsAndNotificationsItem.to_json())

# convert the object into a dict
product_alerts_and_notifications_item_dict = product_alerts_and_notifications_item_instance.to_dict()
# create an instance of ProductAlertsAndNotificationsItem from a dict
product_alerts_and_notifications_item_from_dict = ProductAlertsAndNotificationsItem.from_dict(product_alerts_and_notifications_item_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


