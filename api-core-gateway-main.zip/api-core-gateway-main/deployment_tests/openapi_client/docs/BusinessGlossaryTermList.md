# BusinessGlossaryTermList

A list of business glossary terms

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**terms** | [**List[BusinessGlossaryTerm]**](BusinessGlossaryTerm.md) | List of business glossary terms | 

## Example

```python
from openapi_client.models.business_glossary_term_list import BusinessGlossaryTermList

# TODO update the JSON string below
json = "{}"
# create an instance of BusinessGlossaryTermList from a JSON string
business_glossary_term_list_instance = BusinessGlossaryTermList.from_json(json)
# print the JSON string representation of the object
print(BusinessGlossaryTermList.to_json())

# convert the object into a dict
business_glossary_term_list_dict = business_glossary_term_list_instance.to_dict()
# create an instance of BusinessGlossaryTermList from a dict
business_glossary_term_list_from_dict = BusinessGlossaryTermList.from_dict(business_glossary_term_list_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


