# MarketingDatasetList

A list of marketing datasets

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**datasets** | [**List[MarketingDataset]**](MarketingDataset.md) | List of marketing datasets | 

## Example

```python
from openapi_client.models.marketing_dataset_list import MarketingDatasetList

# TODO update the JSON string below
json = "{}"
# create an instance of MarketingDatasetList from a JSON string
marketing_dataset_list_instance = MarketingDatasetList.from_json(json)
# print the JSON string representation of the object
print(MarketingDatasetList.to_json())

# convert the object into a dict
marketing_dataset_list_dict = marketing_dataset_list_instance.to_dict()
# create an instance of MarketingDatasetList from a dict
marketing_dataset_list_from_dict = MarketingDatasetList.from_dict(marketing_dataset_list_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


