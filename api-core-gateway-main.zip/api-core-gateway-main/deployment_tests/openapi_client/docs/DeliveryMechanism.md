# DeliveryMechanism

The delivery mechanism

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**title** | **str** | Title or name of the resource | 
**description** | **str** | Description | 
**url** | **str** | Delivery mechanism URL | 

## Example

```python
from openapi_client.models.delivery_mechanism import DeliveryMechanism

# TODO update the JSON string below
json = "{}"
# create an instance of DeliveryMechanism from a JSON string
delivery_mechanism_instance = DeliveryMechanism.from_json(json)
# print the JSON string representation of the object
print(DeliveryMechanism.to_json())

# convert the object into a dict
delivery_mechanism_dict = delivery_mechanism_instance.to_dict()
# create an instance of DeliveryMechanism from a dict
delivery_mechanism_from_dict = DeliveryMechanism.from_dict(delivery_mechanism_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


