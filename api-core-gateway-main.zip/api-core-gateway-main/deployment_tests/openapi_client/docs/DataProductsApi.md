# openapi_client.DataProductsApi

All URIs are relative to *http://localhost/data-discovery/v1*

Method | HTTP request | Description
------------- | ------------- | -------------
[**data_product_interface_get**](DataProductsApi.md#data_product_interface_get) | **GET** /products/{id} | Get a data product by Id
[**data_product_interface_get_fields**](DataProductsApi.md#data_product_interface_get_fields) | **GET** /products/{id}/fields | Get a list of fields associated with a data product
[**data_product_interface_list**](DataProductsApi.md#data_product_interface_list) | **GET** /products | Get a list of data products


# **data_product_interface_get**
> DataProductDetail data_product_interface_get(id)

Get a data product by Id

The endpoint returns a data product

### Example

* Bearer Authentication (BearerAuth):

```python
import openapi_client
from openapi_client.models.data_product_detail import DataProductDetail
from openapi_client.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost/data-discovery/v1
# See configuration.py for a list of all supported configuration parameters.
configuration = openapi_client.Configuration(
    host = "http://localhost/data-discovery/v1"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization: BearerAuth
configuration = openapi_client.Configuration(
    access_token = os.environ["DD_BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with openapi_client.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = openapi_client.DataProductsApi(api_client)
    id = 'id_example' # str | The identifier for the data product

    try:
        # Get a data product by Id
        api_response = api_instance.data_product_interface_get(id)
        print("The response of DataProductsApi->data_product_interface_get:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling DataProductsApi->data_product_interface_get: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **str**| The identifier for the data product | 

### Return type

[**DataProductDetail**](DataProductDetail.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | The request has succeeded. |  -  |
**400** | The server could not understand the request due to invalid syntax. |  -  |
**401** | Access is unauthorized. |  -  |
**403** | Access is forbidden |  -  |
**404** | The server cannot find the requested resource. |  -  |
**405** | Client error |  -  |
**408** | Client error |  -  |
**415** | Client error |  -  |
**429** | Client error |  -  |
**500** | Server error |  -  |
**502** | Server error |  -  |
**503** | Service unavailable. |  -  |
**504** | Server error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **data_product_interface_get_fields**
> FieldList data_product_interface_get_fields(id, limit=limit, offset=offset)

Get a list of fields associated with a data product

Returns a list of fields

### Example

* Bearer Authentication (BearerAuth):

```python
import openapi_client
from openapi_client.models.field_list import FieldList
from openapi_client.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost/data-discovery/v1
# See configuration.py for a list of all supported configuration parameters.
configuration = openapi_client.Configuration(
    host = "http://localhost/data-discovery/v1"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization: BearerAuth
configuration = openapi_client.Configuration(
    access_token = os.environ["DD_BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with openapi_client.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = openapi_client.DataProductsApi(api_client)
    id = 'id_example' # str | The identifier for the data product
    limit = 56 # int | Number of results to be included in response, defaulting to 50 if not provided (optional)
    offset = 56 # int | An offset from which the list of results are retrieved, defaulting to 0 if not provided (optional)

    try:
        # Get a list of fields associated with a data product
        api_response = api_instance.data_product_interface_get_fields(id, limit=limit, offset=offset)
        print("The response of DataProductsApi->data_product_interface_get_fields:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling DataProductsApi->data_product_interface_get_fields: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **str**| The identifier for the data product | 
 **limit** | **int**| Number of results to be included in response, defaulting to 50 if not provided | [optional] 
 **offset** | **int**| An offset from which the list of results are retrieved, defaulting to 0 if not provided | [optional] 

### Return type

[**FieldList**](FieldList.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | The request has succeeded. |  -  |
**400** | The server could not understand the request due to invalid syntax. |  -  |
**401** | Access is unauthorized. |  -  |
**403** | Access is forbidden |  -  |
**404** | The server cannot find the requested resource. |  -  |
**405** | Client error |  -  |
**408** | Client error |  -  |
**415** | Client error |  -  |
**429** | Client error |  -  |
**500** | Server error |  -  |
**502** | Server error |  -  |
**503** | Service unavailable. |  -  |
**504** | Server error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **data_product_interface_list**
> DataProductList data_product_interface_list(limit=limit, offset=offset)

Get a list of data products

The endpoint returns a list of data products

### Example

* Bearer Authentication (BearerAuth):

```python
import openapi_client
from openapi_client.models.data_product_list import DataProductList
from openapi_client.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost/data-discovery/v1
# See configuration.py for a list of all supported configuration parameters.
configuration = openapi_client.Configuration(
    host = "http://localhost/data-discovery/v1"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization: BearerAuth
configuration = openapi_client.Configuration(
    access_token = os.environ["DD_BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with openapi_client.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = openapi_client.DataProductsApi(api_client)
    limit = 56 # int | Number of results to be included in response, defaulting to 50 if not provided (optional)
    offset = 56 # int | An offset from which the list of results are retrieved, defaulting to 0 if not provided (optional)

    try:
        # Get a list of data products
        api_response = api_instance.data_product_interface_list(limit=limit, offset=offset)
        print("The response of DataProductsApi->data_product_interface_list:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling DataProductsApi->data_product_interface_list: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **limit** | **int**| Number of results to be included in response, defaulting to 50 if not provided | [optional] 
 **offset** | **int**| An offset from which the list of results are retrieved, defaulting to 0 if not provided | [optional] 

### Return type

[**DataProductList**](DataProductList.md)

### Authorization

[BearerAuth](../README.md#BearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | The request has succeeded. |  -  |
**400** | The server could not understand the request due to invalid syntax. |  -  |
**401** | Access is unauthorized. |  -  |
**403** | Access is forbidden |  -  |
**404** | The server cannot find the requested resource. |  -  |
**405** | Client error |  -  |
**408** | Client error |  -  |
**415** | Client error |  -  |
**429** | Client error |  -  |
**500** | Server error |  -  |
**502** | Server error |  -  |
**503** | Service unavailable. |  -  |
**504** | Server error |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

