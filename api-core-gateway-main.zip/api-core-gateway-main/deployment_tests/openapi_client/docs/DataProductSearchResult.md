# DataProductSearchResult

A data product search result

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**search_score** | **float** | Azure AI Search response search score | 
**entity_type** | **str** | Entity type | 
**description** | **str** | Description | 
**marketing_summary** | **str** | Marketing summary / short description | 
**commercial_product_title** | **str** | Commercial product that delivers the data product | 
**associated_datasets** | [**List[MarketingDataset]**](MarketingDataset.md) | Associated datasets | [optional] 
**delivery_methods** | [**List[DeliveryMechanism]**](DeliveryMechanism.md) | Delivery methods | 
**id** | **str** | Unique identifier for the resource | [readonly] 
**title** | **str** | Title or name of the resource | 

## Example

```python
from openapi_client.models.data_product_search_result import DataProductSearchResult

# TODO update the JSON string below
json = "{}"
# create an instance of DataProductSearchResult from a JSON string
data_product_search_result_instance = DataProductSearchResult.from_json(json)
# print the JSON string representation of the object
print(DataProductSearchResult.to_json())

# convert the object into a dict
data_product_search_result_dict = data_product_search_result_instance.to_dict()
# create an instance of DataProductSearchResult from a dict
data_product_search_result_from_dict = DataProductSearchResult.from_dict(data_product_search_result_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


