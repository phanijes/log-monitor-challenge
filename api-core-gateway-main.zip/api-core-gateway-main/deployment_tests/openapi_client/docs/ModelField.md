# ModelField

A field

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **str** | Unique identifier for the resource | [readonly] 
**field_code** | **str** | Field code | 
**title** | **str** | Title or name of the resource | 
**entity_type** | **str** | Entity type | 
**description** | **str** | Description / definition | 
**associated_datasets** | [**List[MarketingDatasetReference]**](MarketingDatasetReference.md) | Associated marketing datasets | 
**related_products** | [**List[DataProductReference]**](DataProductReference.md) | Related products | 
**related_business_glossary_term** | [**BusinessGlossaryTermReference**](BusinessGlossaryTermReference.md) | Related business glossary term | 
**data_type** | **str** | Data type | 

## Example

```python
from openapi_client.models.model_field import ModelField

# TODO update the JSON string below
json = "{}"
# create an instance of ModelField from a JSON string
model_field_instance = ModelField.from_json(json)
# print the JSON string representation of the object
print(ModelField.to_json())

# convert the object into a dict
model_field_dict = model_field_instance.to_dict()
# create an instance of ModelField from a dict
model_field_from_dict = ModelField.from_dict(model_field_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


