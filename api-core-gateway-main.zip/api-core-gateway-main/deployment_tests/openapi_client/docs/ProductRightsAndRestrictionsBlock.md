# ProductRightsAndRestrictionsBlock

The product rights and restrictions block

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**free_trial_period** | **str** | Free trial period | 
**redistribution** | **str** | Redistribution | 

## Example

```python
from openapi_client.models.product_rights_and_restrictions_block import ProductRightsAndRestrictionsBlock

# TODO update the JSON string below
json = "{}"
# create an instance of ProductRightsAndRestrictionsBlock from a JSON string
product_rights_and_restrictions_block_instance = ProductRightsAndRestrictionsBlock.from_json(json)
# print the JSON string representation of the object
print(ProductRightsAndRestrictionsBlock.to_json())

# convert the object into a dict
product_rights_and_restrictions_block_dict = product_rights_and_restrictions_block_instance.to_dict()
# create an instance of ProductRightsAndRestrictionsBlock from a dict
product_rights_and_restrictions_block_from_dict = ProductRightsAndRestrictionsBlock.from_dict(product_rights_and_restrictions_block_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


