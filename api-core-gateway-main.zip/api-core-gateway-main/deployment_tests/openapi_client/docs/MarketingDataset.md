# MarketingDataset

A marketing dataset

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**entity_type** | **str** | Entity type | 
**description** | **str** | Description | 
**primary_refinitiv_data_taxonomy** | **str** | Primary refinitiv data taxonomy/category | 
**temporal_coverage_year_from** | **int** | Year for which temporal coverage starts | 
**data_frequency_description** | **str** | Data frequency | 
**categories** | [**List[Category]**](Category.md) | Categories | 
**geography_description** | **str** | Geographical coverage / regions | 
**id** | **str** | Unique identifier for the resource | [readonly] 
**title** | **str** | Title or name of the resource | 

## Example

```python
from openapi_client.models.marketing_dataset import MarketingDataset

# TODO update the JSON string below
json = "{}"
# create an instance of MarketingDataset from a JSON string
marketing_dataset_instance = MarketingDataset.from_json(json)
# print the JSON string representation of the object
print(MarketingDataset.to_json())

# convert the object into a dict
marketing_dataset_dict = marketing_dataset_instance.to_dict()
# create an instance of MarketingDataset from a dict
marketing_dataset_from_dict = MarketingDataset.from_dict(marketing_dataset_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


