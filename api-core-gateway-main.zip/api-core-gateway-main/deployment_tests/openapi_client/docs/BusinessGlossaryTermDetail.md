# BusinessGlossaryTermDetail

A business glossary term detail

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**classification_labels** | **List[str]** | Classification labels | [optional] 
**sensitivity_labels** | **List[str]** | Sensitivity labels | [optional] 
**entity_type** | **str** | Entity type | 
**description** | **str** | Description / definition | 
**associated_datasets** | [**List[MarketingDatasetReference]**](MarketingDatasetReference.md) | Associated datasets | [optional] 
**id** | **str** | Unique identifier for the resource | [readonly] 
**title** | **str** | Title or name of the resource | 

## Example

```python
from openapi_client.models.business_glossary_term_detail import BusinessGlossaryTermDetail

# TODO update the JSON string below
json = "{}"
# create an instance of BusinessGlossaryTermDetail from a JSON string
business_glossary_term_detail_instance = BusinessGlossaryTermDetail.from_json(json)
# print the JSON string representation of the object
print(BusinessGlossaryTermDetail.to_json())

# convert the object into a dict
business_glossary_term_detail_dict = business_glossary_term_detail_instance.to_dict()
# create an instance of BusinessGlossaryTermDetail from a dict
business_glossary_term_detail_from_dict = BusinessGlossaryTermDetail.from_dict(business_glossary_term_detail_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


