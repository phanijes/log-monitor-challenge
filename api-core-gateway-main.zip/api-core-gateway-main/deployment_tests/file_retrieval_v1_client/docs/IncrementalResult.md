# IncrementalResult


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**product_identifier** | **str** |  | [optional] 
**start_window** | **datetime** |  | [optional] 
**version** | **str** |  | [optional] 
**end_window** | **datetime** |  | [optional] 
**tables** | [**List[IncrementalTableResult]**](IncrementalTableResult.md) |  | [optional] 

## Example

```python
from openapi_client.models.incremental_result import IncrementalResult

# TODO update the JSON string below
json = "{}"
# create an instance of IncrementalResult from a JSON string
incremental_result_instance = IncrementalResult.from_json(json)
# print the JSON string representation of the object
print(IncrementalResult.to_json())

# convert the object into a dict
incremental_result_dict = incremental_result_instance.to_dict()
# create an instance of IncrementalResult from a dict
incremental_result_from_dict = IncrementalResult.from_dict(incremental_result_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


