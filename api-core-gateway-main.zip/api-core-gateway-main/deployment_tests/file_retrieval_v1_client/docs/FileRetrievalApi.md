# openapi_client.FileRetrievalApi

All URIs are relative to *http://localhost*

Method | HTTP request | Description
------------- | ------------- | -------------
[**incrementals_get**](FileRetrievalApi.md#incrementals_get) | **GET** /incrementals | 
[**incrementals_product_identifier_get**](FileRetrievalApi.md#incrementals_product_identifier_get) | **GET** /incrementals/{productIdentifier} | 
[**initializationpacks_get**](FileRetrievalApi.md#initializationpacks_get) | **GET** /initializationpacks | 
[**initializationpacks_product_identifier_get**](FileRetrievalApi.md#initializationpacks_product_identifier_get) | **GET** /initializationpacks/{productIdentifier} | 
[**initializations_get**](FileRetrievalApi.md#initializations_get) | **GET** /initializations | 
[**initializations_product_identifier_get**](FileRetrievalApi.md#initializations_product_identifier_get) | **GET** /initializations/{productIdentifier} | 


# **incrementals_get**
> Dict[str, IncrementalResult] incrementals_get(user_id=user_id, start_window=start_window, end_window=end_window)



### Example


```python
import openapi_client
from openapi_client.models.incremental_result import IncrementalResult
from openapi_client.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = openapi_client.Configuration(
    host = "http://localhost"
)


# Enter a context with an instance of the API client
with openapi_client.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = openapi_client.FileRetrievalApi(api_client)
    user_id = 'user_id_example' # str |  (optional)
    start_window = '2013-10-20T19:20:30+01:00' # datetime |  (optional)
    end_window = '2013-10-20T19:20:30+01:00' # datetime |  (optional)

    try:
        api_response = api_instance.incrementals_get(user_id=user_id, start_window=start_window, end_window=end_window)
        print("The response of FileRetrievalApi->incrementals_get:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling FileRetrievalApi->incrementals_get: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **user_id** | **str**|  | [optional] 
 **start_window** | **datetime**|  | [optional] 
 **end_window** | **datetime**|  | [optional] 

### Return type

[**Dict[str, IncrementalResult]**](IncrementalResult.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: text/plain, application/json, text/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | Success |  -  |
**204** | No Content |  -  |
**400** | Bad Request |  -  |
**401** | Unauthorized |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **incrementals_product_identifier_get**
> IncrementalResult incrementals_product_identifier_get(product_identifier, start_window, user_id=user_id, version=version, table_identifiers=table_identifiers, end_window=end_window)



### Example


```python
import openapi_client
from openapi_client.models.incremental_result import IncrementalResult
from openapi_client.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = openapi_client.Configuration(
    host = "http://localhost"
)


# Enter a context with an instance of the API client
with openapi_client.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = openapi_client.FileRetrievalApi(api_client)
    product_identifier = 'product_identifier_example' # str | 
    start_window = '2013-10-20T19:20:30+01:00' # datetime | 
    user_id = 'user_id_example' # str |  (optional)
    version = 'version_example' # str |  (optional)
    table_identifiers = ['table_identifiers_example'] # List[str] |  (optional)
    end_window = '2013-10-20T19:20:30+01:00' # datetime |  (optional)

    try:
        api_response = api_instance.incrementals_product_identifier_get(product_identifier, start_window, user_id=user_id, version=version, table_identifiers=table_identifiers, end_window=end_window)
        print("The response of FileRetrievalApi->incrementals_product_identifier_get:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling FileRetrievalApi->incrementals_product_identifier_get: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **product_identifier** | **str**|  | 
 **start_window** | **datetime**|  | 
 **user_id** | **str**|  | [optional] 
 **version** | **str**|  | [optional] 
 **table_identifiers** | [**List[str]**](str.md)|  | [optional] 
 **end_window** | **datetime**|  | [optional] 

### Return type

[**IncrementalResult**](IncrementalResult.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: text/plain, application/json, text/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | Success |  -  |
**204** | No Content |  -  |
**400** | Bad Request |  -  |
**401** | Unauthorized |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **initializationpacks_get**
> Dict[str, InitializationResult] initializationpacks_get(user_id=user_id)



### Example


```python
import openapi_client
from openapi_client.models.initialization_result import InitializationResult
from openapi_client.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = openapi_client.Configuration(
    host = "http://localhost"
)


# Enter a context with an instance of the API client
with openapi_client.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = openapi_client.FileRetrievalApi(api_client)
    user_id = 'user_id_example' # str |  (optional)

    try:
        api_response = api_instance.initializationpacks_get(user_id=user_id)
        print("The response of FileRetrievalApi->initializationpacks_get:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling FileRetrievalApi->initializationpacks_get: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **user_id** | **str**|  | [optional] 

### Return type

[**Dict[str, InitializationResult]**](InitializationResult.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: text/plain, application/json, text/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | Success |  -  |
**204** | No Content |  -  |
**400** | Bad Request |  -  |
**401** | Unauthorized |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **initializationpacks_product_identifier_get**
> InitializationResult initializationpacks_product_identifier_get(product_identifier, user_id=user_id, version=version, table_identifiers=table_identifiers)



### Example


```python
import openapi_client
from openapi_client.models.initialization_result import InitializationResult
from openapi_client.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = openapi_client.Configuration(
    host = "http://localhost"
)


# Enter a context with an instance of the API client
with openapi_client.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = openapi_client.FileRetrievalApi(api_client)
    product_identifier = 'product_identifier_example' # str | 
    user_id = 'user_id_example' # str |  (optional)
    version = 'version_example' # str |  (optional)
    table_identifiers = ['table_identifiers_example'] # List[str] |  (optional)

    try:
        api_response = api_instance.initializationpacks_product_identifier_get(product_identifier, user_id=user_id, version=version, table_identifiers=table_identifiers)
        print("The response of FileRetrievalApi->initializationpacks_product_identifier_get:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling FileRetrievalApi->initializationpacks_product_identifier_get: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **product_identifier** | **str**|  | 
 **user_id** | **str**|  | [optional] 
 **version** | **str**|  | [optional] 
 **table_identifiers** | [**List[str]**](str.md)|  | [optional] 

### Return type

[**InitializationResult**](InitializationResult.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: text/plain, application/json, text/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | Success |  -  |
**204** | No Content |  -  |
**400** | Bad Request |  -  |
**401** | Unauthorized |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **initializations_get**
> Dict[str, InitializationResult] initializations_get(user_id=user_id)



### Example


```python
import openapi_client
from openapi_client.models.initialization_result import InitializationResult
from openapi_client.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = openapi_client.Configuration(
    host = "http://localhost"
)


# Enter a context with an instance of the API client
with openapi_client.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = openapi_client.FileRetrievalApi(api_client)
    user_id = 'user_id_example' # str |  (optional)

    try:
        api_response = api_instance.initializations_get(user_id=user_id)
        print("The response of FileRetrievalApi->initializations_get:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling FileRetrievalApi->initializations_get: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **user_id** | **str**|  | [optional] 

### Return type

[**Dict[str, InitializationResult]**](InitializationResult.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: text/plain, application/json, text/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | Success |  -  |
**204** | No Content |  -  |
**400** | Bad Request |  -  |
**401** | Unauthorized |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **initializations_product_identifier_get**
> InitializationResult initializations_product_identifier_get(product_identifier, user_id=user_id, version=version, table_identifiers=table_identifiers)



### Example


```python
import openapi_client
from openapi_client.models.initialization_result import InitializationResult
from openapi_client.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = openapi_client.Configuration(
    host = "http://localhost"
)


# Enter a context with an instance of the API client
with openapi_client.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = openapi_client.FileRetrievalApi(api_client)
    product_identifier = 'product_identifier_example' # str | 
    user_id = 'user_id_example' # str |  (optional)
    version = 'version_example' # str |  (optional)
    table_identifiers = ['table_identifiers_example'] # List[str] |  (optional)

    try:
        api_response = api_instance.initializations_product_identifier_get(product_identifier, user_id=user_id, version=version, table_identifiers=table_identifiers)
        print("The response of FileRetrievalApi->initializations_product_identifier_get:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling FileRetrievalApi->initializations_product_identifier_get: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **product_identifier** | **str**|  | 
 **user_id** | **str**|  | [optional] 
 **version** | **str**|  | [optional] 
 **table_identifiers** | [**List[str]**](str.md)|  | [optional] 

### Return type

[**InitializationResult**](InitializationResult.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: text/plain, application/json, text/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** | Success |  -  |
**204** | No Content |  -  |
**400** | Bad Request |  -  |
**401** | Unauthorized |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

