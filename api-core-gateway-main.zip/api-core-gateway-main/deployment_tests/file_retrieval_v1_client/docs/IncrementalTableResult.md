# IncrementalTableResult


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**table_identifier** | **str** |  | [optional] 
**incremental_links** | **List[str]** |  | [optional] 

## Example

```python
from openapi_client.models.incremental_table_result import IncrementalTableResult

# TODO update the JSON string below
json = "{}"
# create an instance of IncrementalTableResult from a JSON string
incremental_table_result_instance = IncrementalTableResult.from_json(json)
# print the JSON string representation of the object
print(IncrementalTableResult.to_json())

# convert the object into a dict
incremental_table_result_dict = incremental_table_result_instance.to_dict()
# create an instance of IncrementalTableResult from a dict
incremental_table_result_from_dict = IncrementalTableResult.from_dict(incremental_table_result_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


