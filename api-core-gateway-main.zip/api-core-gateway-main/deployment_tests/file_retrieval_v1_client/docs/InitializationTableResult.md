# InitializationTableResult


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**table_identifier** | **str** |  | [optional] 
**init_timestamp** | **datetime** |  | [optional] 
**init_link** | **str** |  | [optional] 
**incremental_links** | **List[str]** |  | [optional] 

## Example

```python
from openapi_client.models.initialization_table_result import InitializationTableResult

# TODO update the JSON string below
json = "{}"
# create an instance of InitializationTableResult from a JSON string
initialization_table_result_instance = InitializationTableResult.from_json(json)
# print the JSON string representation of the object
print(InitializationTableResult.to_json())

# convert the object into a dict
initialization_table_result_dict = initialization_table_result_instance.to_dict()
# create an instance of InitializationTableResult from a dict
initialization_table_result_from_dict = InitializationTableResult.from_dict(initialization_table_result_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


