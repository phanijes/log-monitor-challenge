# from deployment_tests.data_discovery_v1_client import root_get
import yaml
import json
# from typing import Unionfrom fastapi import FastAPI


# app = FastAPI()

# env = "dev"
# with open(f"./configurations/kong/{env}/data-discovery_v1/spec.yaml", "r") as f:
#         print(f.read())

# root_get()

def test_assert():
    """
    Doc
    """
    pass
    # with open(f"./configurations/openapi/datadiscoveryv1/openapi.yaml", 'r') as yaml_in, open(f"./configurations/openapi/datadiscoveryv1/openapi.json", "w") as json_out:
    #     yaml_object = yaml.safe_load(yaml_in) # yaml_object will be a list or a dict
    #     json.dump(yaml_object, json_out)
    # env = "dev"
    # root_get()