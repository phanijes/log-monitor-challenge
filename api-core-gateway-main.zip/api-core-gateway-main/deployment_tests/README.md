Openapi Client generation: \
https://openapi-generator.tech/docs/installation

npm install @openapitools/openapi-generator-cli -g \
npx @openapitools/openapi-generator-cli generate -i /{PATH}/deployment-tests/deployment_tests/configurations/openapi/datadiscoveryv1/openapi.yaml -g python -o /{PATH}/deployment-tests/openapi_client
npx @openapitools/openapi-generator-cli generate -i /{PATH}/deployment-tests/deployment_tests/configurations/openapi/fileretrievalv1/openapi.yaml -g python -o /{PATH}/deployment-tests/file_retrieval_v1_client

Run tests: \
poetry run pytest