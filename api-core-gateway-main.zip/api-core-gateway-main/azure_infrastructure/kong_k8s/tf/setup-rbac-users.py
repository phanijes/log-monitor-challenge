#!/usr/bin/env python3

import os
import requests
import urllib.parse


READ_ONLY_USER_NAME = "baseReadOnlyUser"
ADMIN_USER_NAME = "baseAdminUser"
VERIFY_CERTIFICATE = False
KONG_ADMIN_TOKEN_HEADER = "Kong-Admin-Token"


def make_request_url(base_url, path):
    return urllib.parse.urljoin(base_url, path)


def check_response_status(response, request_url, allowed_codes):
    if response.status_code not in allowed_codes:
        raise RuntimeError(f"{request_url} call failed  with {response.status_code} code. {response.text}")
    return response.json()


def make_get_request(request_parameters, target_url, allowed_codes):
    response = requests.get(target_url, headers={KONG_ADMIN_TOKEN_HEADER: request_parameters["token"], "Host": request_parameters["fqdn"]}, verify=VERIFY_CERTIFICATE)
    return check_response_status(response, target_url, allowed_codes)


def make_post_request(request_parameters, target_url, payload, allowed_codes):
    response = requests.post(target_url, headers={KONG_ADMIN_TOKEN_HEADER: request_parameters["token"], "Host": request_parameters["fqdn"]}, json=payload, verify=VERIFY_CERTIFICATE)
    return check_response_status(response, target_url, allowed_codes)


def make_patch_request(request_parameters, target_url, payload, allowed_codes):
    response = requests.patch(target_url, headers={KONG_ADMIN_TOKEN_HEADER: request_parameters["token"], "Host": request_parameters["fqdn"]}, json=payload, verify=VERIFY_CERTIFICATE)
    return check_response_status(response, target_url, allowed_codes)


def check_response_error(response):
    if "message" in response:
        return None
    return response


def get_user(request_parameters, name):
    response = make_get_request(request_parameters, make_request_url(request_parameters["url"], f"/rbac/users/{name}"), [200, 404])
    return check_response_error(response)


def add_user(request_parameters, name, user_token):
    payload = {"name": name, "user_token": user_token, "enabled": True, "comment": "created by kong_k8s"}
    response = make_post_request(request_parameters, make_request_url(request_parameters["url"], "/rbac/users"), payload, [200, 201])
    return check_response_error(response)


def update_user(request_parameters, name, user_token):
    payload = {"name": name, "user_token": user_token, "enabled": True, "comment": "created by kong_k8s"}
    response = make_patch_request(request_parameters, make_request_url(request_parameters["url"], f"/rbac/users/{name}"), payload, [200])
    return check_response_error(response)


def add_role(request_parameters, name, role_name):
    payload = {"roles": role_name}
    response = make_post_request(request_parameters, make_request_url(request_parameters["url"], f"/rbac/users/{name}/roles"), payload, [200, 201])
    return check_response_error(response)


def get_user_roles(request_parameters, name):
    response = make_get_request(request_parameters, make_request_url(request_parameters["url"], f"/rbac/users/{name}/roles"), [200])
    return check_response_error(response)


def upsert_role(request_parameters, name, role_name):
    roles = get_user_roles(request_parameters, name)
    if roles is None or "roles" not in roles:
        add_role(request_parameters, name, role_name)
        return
    for role in roles["roles"]:
        if role["name"] == role_name:
            return
    add_role(request_parameters, name, role_name)


def update_user(request_parameters, name, user_token):
    user = get_user(request_parameters, name)
    if user is None:
        add_user(request_parameters, name, user_token)
        return
    if user["enabled"] != True:
        update_user(request_parameters, name, user_token)


def upsert_user_and_roles(request_parameters, name, user_token, role_name):
    admin_user = get_user(request_parameters, name)
    if admin_user is None:
        add_user(request_parameters, name, user_token)
        add_role(request_parameters, name, role_name)
    else:
        update_user(request_parameters, name, user_token)
        upsert_role(request_parameters, name, role_name)


def main():
    admin_api_url = os.environ["KONG_API_URL"]
    admin_api_fqdn = os.environ["KONG_API_FQDN"]
    superuser_token = os.environ["KONG_SUPERUSER_TOKEN"]
    admin_token = os.environ["KONG_ADMIN_TOKEN"]
    readonly_token = os.environ["KONG_READONLY_TOKEN"]
    request_parameters = {"url": admin_api_url, "fqdn": admin_api_fqdn, "token": superuser_token}
    upsert_user_and_roles(request_parameters, ADMIN_USER_NAME, admin_token, "admin")
    upsert_user_and_roles(request_parameters, READ_ONLY_USER_NAME, readonly_token, "read-only")


if __name__ == "__main__":
    main()
