#!/usr/bin/env python3
import yaml
import argparse
import os
import subprocess


def read_yaml(file_path):
    with open(file_path, "r") as file:
        return yaml.safe_load(file)


output_file_name = "./env_spec.yaml"
select_tag = "global"


def main():
    args = parse_flags()

    kong_token = os.environ.get("KONG_ADMIN_TOKEN")
    if not kong_token:
        kong_token = args.kong_token
    if not kong_token:
        raise ValueError("KONG_ADMIN_TOKEN environment variable not set and no token provided.")

    moesif_appid = os.environ.get("MOESIF_APPLICATION_ID")
    if not moesif_appid:
        moesif_appid = args.moesif_appid
    if not moesif_appid:
        raise ValueError("MOESIF_APPLICATION_ID environment variable not set and no token provided.")

    prepare_env_spec_file(spec_file=args.spec, cfg_file=args.config, env=args.env, region=args.region, filename=output_file_name, moesif_appid=moesif_appid)
    deck_tag(kong_spec_file=output_file_name, tag_value=select_tag)

    result = deck_diff(kong_spec_file=output_file_name, admin_url=args.kong_addr, tag_value=select_tag, token=kong_token)
    print(result)
    result = deck_sync(kong_spec_file=output_file_name, admin_url=args.kong_addr, tag_value=select_tag, token=kong_token)
    print(result)


def parse_flags():
    parser = argparse.ArgumentParser(description="Read a YAML file and output the payload as JSON string.")
    parser.add_argument("--spec", type=str, help="Path to the kong spec YAML file")
    parser.add_argument("--config", type=str, help="Path to the config YAML file")
    parser.add_argument("--env", type=str, help="Target environment")
    parser.add_argument("--region", type=str, help="Target region")
    parser.add_argument("--kong-addr", type=str, help="Kong API URL")
    parser.add_argument("--kong-token", type=str, help="Kong API access token")
    parser.add_argument("--moesif-appid", type=str, help="Moesif application ID")

    return parser.parse_args()


def prepare_env_spec_file(spec_file: str, cfg_file: str, env: str, region: str, filename: str, moesif_appid: str):
    spec = yaml.dump(read_yaml(spec_file))
    cfg = read_yaml(cfg_file)
    env_cfg = cfg["environments"][env]
    env_cfg["moesif_application_id"] = moesif_appid

    # escape {} values and enable string formatting
    spec = spec.replace("{", "|<|").replace("}", "|>|").replace("<^", "{").replace("^>", "}")
    spec = spec.format(**env_cfg)
    # unescape {} values
    spec = spec.replace("|<|", "{").replace("|>|", "}")

    if "<^" in spec or "^>" in spec:
        raise ValueError("Invalid spec file. Some variables left unformatted.")

    with open(filename, "w") as file:
        file.write(spec)


class DeckException(Exception):
    pass


def deck_tag(kong_spec_file: str, tag_value: str):
    output = subprocess.CompletedProcess("", -1)
    try:
        output = subprocess.run(
            ["deck", "file", "add-tags", "-s", kong_spec_file, "-o", kong_spec_file, tag_value],
            capture_output=True,
            timeout=5,
            check=True,
        )
    except Exception as e:
        print(output)
        raise e


def deck_diff(kong_spec_file: str, admin_url: str, tag_value: str, token: str):
    output = subprocess.CompletedProcess("", -1)
    try:
        output = subprocess.run(
            [
                "deck",
                "gateway",
                "diff",
                "--select-tag",
                tag_value,
                "--kong-addr",
                admin_url,
                "--headers",
                "kong-admin-token:" + token,
                "--headers",
                "Accept:application/json",
                "--tls-skip-verify",
                kong_spec_file,
            ],
            capture_output=True,
            timeout=5,
            check=True,
        )
    except Exception as e:
        print(output)
        raise e
    return str(output.stdout.decode())


def deck_sync(kong_spec_file: str, admin_url: str, tag_value: str, token: str):
    output = subprocess.CompletedProcess("", -1)
    try:
        output = subprocess.run(
            [
                "deck",
                "gateway",
                "sync",
                "--select-tag",
                tag_value,
                "--kong-addr",
                admin_url,
                "--headers",
                "kong-admin-token:" + token,
                "--headers",
                "Accept:application/json",
                "--tls-skip-verify",
                kong_spec_file,
            ],
            capture_output=True,
            timeout=5,
            check=True,
        )
    except Exception as e:
        print(output)
        raise e
    return str(output.stdout.decode("utf-8"))


if __name__ == "__main__":
    main()
