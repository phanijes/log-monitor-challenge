#!/bin/bash
pg_dump "${CONNECTION_STRING} dbname=${OLD_DB}"  > dump.sql
echo "DROP DATABASE \"${NEW_DB}\";" > recreate.sql
echo "CREATE DATABASE \"${NEW_DB}\";" >> recreate.sql
psql "${CONNECTION_STRING} dbname=${OLD_DB}" < recreate.sql
psql "${CONNECTION_STRING} dbname=${NEW_DB}" < dump.sql