# Kong authentication and authorization plugins

## General information

Kong provides several plugins for authentication and authorization, with "OpenID Connect" being the most suitable for use within the company. However, being a generic, this plugin cannot fulfill all the requirements for authentication and authorization (authNZ), namely AAA ODPS integration and multiple IDP support.

Two custom plugins are developed to satisfy the requirements. Unlike the Kong's "OpenID Connect", authN and authZ are separated:

- **AuthN** plugin performs authentication
- **ODPSAuth** plugin performs authorization.

### Download plugins bundle

[BAMS UI link](https://bams-aws.refinitiv.com/ui/repos/tree/General/default.generic.global/a51695/kong-plugins)

[Direct download link](https://bams-aws.refinitiv.com/ui/native/default.generic.cloud/a51695/kong-plugins/)

## Image preparation

For Kong to utilize custom plugins, they must be embedded into the Kong image. Non-lua plugins additionally have to be registered with plugin server ([Kong documentation](https://docs.konghq.com/gateway/latest/plugin-development/pluginserver/go/#example-configuration)).
Additionally, for plugins to be loaded, they must be enabled in configuration via ***plugins*** environment variable or configuration file parameter.
Here is a simple example of Dockerfile which could be used to embed the authn & odpsauth plugins in the KDI golden image. Note: all the "default" Kong plugins are enabled via ***bundled*** keyword.

```dockerfile
FROM bams-aws.refinitiv.com/a250506-kdi/kong-debian/kdi-gateway:latest
USER root
COPY --chmod=555 --chown=root:root ./plugins/authn /usr/local/bin
COPY --chmod=555 --chown=root:root ./plugins/odpsauth /usr/local/bin
ENV CONFIGFILE=/etc/kong/kong.conf
ENV KONGPREFIX=/kong_prefix
RUN echo "plugins = bundled,authn,odpsauth">> $CONFIGFILE \
 && echo "pluginserver_names = authn,odpsauth" >> $CONFIGFILE \
 && echo "pluginserver_authn_socket = $KONGPREFIX/authn.socket" >> $CONFIGFILE \
 && echo "pluginserver_authn_query_cmd = /usr/local/bin/authn -dump -kong-prefix $KONGPREFIX" >> $CONFIGFILE \
 && echo "pluginserver_authn_start_cmd = /usr/local/bin/authn -kong-prefix $KONGPREFIX" >> $CONFIGFILE \
 && echo "pluginserver_odpsauth_socket = $KONGPREFIX/odpsauth.socket" >> $CONFIGFILE \
 && echo "pluginserver_odpsauth_query_cmd = /usr/local/bin/odpsauth -dump -kong-prefix $KONGPREFIX" >> $CONFIGFILE \
 && echo "pluginserver_odpsauth_start_cmd = /usr/local/bin/odpsauth -kong-prefix $KONGPREFIX" >> $CONFIGFILE
USER kong
```

## Kong deployment with custom plugins

### Helm chart specifics

Kong provides a Helm chart allowing to simplify the deployment ([Repository](https://github.com/Kong/charts)). In "default" configuration the chart adds ***KONG_PLUGINS*** environment variable with value '*bundled*', effectively overriding the value from configuration file. For custom plugins to be loaded by Kong, this variable has to be disabled or include all the required custom plugins. Example:

```yaml
env:
  plugins: bundled,authn,odpsauth
```

### Using environment variables with non-lua plugins

Kong (or more specifically, nginx) starts external (non-lua) plugins as separate processes and clears the environment variables ([nginx documentation](http://nginx.org/en/docs/ngx_core_module.html#env)). As a result, all the environment variables specified for Kong itself are not available for these plugins. Current workaround is to use a dedicated nginx directive to preserve some of them. All the environment variables which should be available in external plugin have to be specified in ***KONG_NGINX_MAIN_ENV*** variable. Here is an example of sharing Azure credentials with the plugin via helm chart:

```yaml
env:
  nginx_main_env: AZURE_TENANT_ID;env AZURE_CLIENT_SECRET;env AZURE_CLIENT_ID
```

Note: ***env*** command has to be used in case more than 1 variable is required.

## Environment variables vault (*advanced*)

As Kong do not support vault for external plugins, a simple environment variables vault was implemented within the plugins. This allows to store sensitive configuration values in environment variables and avoid need to keep them in git. The syntax is identical to the Kong vault. Example: ***"{vault://env/PLUGIN_PARAMETERS/ping-client-id}"***, where *'PLUGIN_PARAMETERS'* is the variable name containing JSON and *'ping-client-id'* is the JSON key to extract.

## Cache configuration

Both plugins support back-end query results caching. Two type of caching is supported:

- **in-memory**: simple cache implementation storing data in plugin's memory.
- **Redis**: external Redis cache connection. Allows sharing cache between Kong data plane replicas.

Additionally, there are two ways of cache configuration: per plugin instance & global.

### Per instance (replica) cache configuration

This is the default mode aligned with usual Kong plugin configuration approach: plugin configuration has ***"cache"*** section, which allows to define all the required parameters. In such case, cache is created per plugin replica (note: Kong starts several replicas per plugin instance), i.e. one cache instance per replica per plugin instance per Kong data plane container. In-memory cache might not be very efficient in this setup. For redis however, the cache data is stored externally, so only Redis connection pools will be duplicated.

### Global cache configuration (*advanced*)

As an alternative, it is possible to setup a singular cache configuration which could be reused by all plugin instances. As configuration is global, it does not require or depend on any particular plugin instance.  The configuration is provided via environment variable ***GLOBAL_PLUGIN_SETTINGS*** and must contain JSON payload. On Kong startup, plugin will attempt to read the variable, init cache and will produce an error in log failing to do so.

Here is the description of the expected JSON payload:

- `cache_configuration`: Configuration settings for global cache. Might contain the following fields:
  - `inmemory_enabled`: Boolean flag to enable or disable in-memory cache.
  - `redis_enabled`: Boolean flag to enable or disable Redis cache.
  - `redis_url`: The URL for the Redis server, with port. Mandatory if enabled.
  - `redis_is_cluster`: Must be enabled if Redis is running in cluster mode (multiple instances).
  - `redis_is_tls`: Must be enabled if TLS is required for Redis connection.
  - `redis_username`: The username for Redis authentication (if required). Can use environment variable vault.
  - `redis_password`: The password for Redis authentication (if required). Can use environment variable vault.

Example:

```json
{"cache_configuration": {"redis_enabled": true,"redis_url": "172.28.56.152:6379","redis_is_cluster": false,"redis_is_tls": false,"redis_username": "","redis_password": "","inmemory_enabled": true}}
```

Note: configuring global cache does not mean it will be used by all plugin instances! Each instance could be configured to use global or per replica cache individually. If global cache is selected, it is possible to use in-memory and/or Redis, but only if they are configured. I.e., if both cache types are globally enabled, each plugin instance can choose which one (or both) to use. However, if a particular cache type is not configured globally, but enabled in plugin configuration, error message will be produced on each request and no caching performed for that cache type.

## AuthN configuration

AuthN plugin allows to perform verification of access tokens from any of the supported IDP (AAA STS, Ping, Heimdall, Entra). In case the token is valid and not expired yet, it also extracts the AAA UUID (or Entra OID) from the token or introspect result and sets it as the Kong's authenticated credential ID. Optionally, it can cache the introspect results (AAA STS, Ping). AAA UUID or Entra OID as well as token kind (IDP) could also be forwarded to the upstream via configured headers.

Plugin configuration parameters are described below. Related option are grouped together.

### common

- `preserve_authorization_header`: Boolean flag to preserve the authorization header in upstream requests as-is. If disabled, authorization header is removed.
- `authorization_header_name`: The name of the authorization header. At least one of authorization header or cookie must be configured.
- `authorization_cookie_name`: The name of the authorization cookie. At least one of authorization header or cookie must be configured.
- `unauthorized_error_message`: Error message to return with 401 status code. If specified, overrides default messages provided by the plugin.
- `log_level`: The log level for the plugin. Default is `info`.

### ping

Configuration settings for Ping authentication. Ping can generate both JWT and Opaque tokens. JWKS & introspect URLs are obtained via the issuer URL. Service account's client ID & secret with access to introspect endpoint are required for opaque tokens introspection to work.

- `ping.enabled`: Boolean flag to enable or disable Ping authentication.
- `ping.issuer`: The issuer URL. Mandatory if enabled. Example: "https://login.stage.ciam.refinitiv.com".
- `ping.client_id`: The client ID for token introspection. Mandatory if enabled. Can use environment variable vault.
- `ping.client_secret`: The client secret for token introspection. Mandatory if enabled. Can use environment variable vault.

### entra

Configuration settings for Entra authentication. Entra generates JWT tokens only. JWKS is obtained from the matched issuer. Either ***'allowed_issuers'*** or ***'prefix'*** and must be set.

- `entra.enabled`: Boolean flag to enable or disable Entra authentication.
- `entra.prefix`: Issuer prefix. Could be used in case **ANY** Entra issuer should be allowed.
- `entra.allowed_issuers`: The list of allowed issuers. If not empty, ***'prefix'*** is ignored.
- `entra.allowed_audience`: A list of allowed values for audience ('aud') token field. Optional.

### cache

Configuration settings for caching for all introspect based IDP types (AAA STS, Ping). If enabled, in case of successful introspect call, the introspect result will be stored in cache for predefined period of time. Token expiration check is done on each request, regardless if the results are obtained from cache or not. It is possible to enable both in-memory and Redis cache at the same time: in such case lookup is first done in the in-memory one.

- `cache.enabled`: Boolean flag to enable or disable caching.
- `cache.use_global_cache`: Boolean flag to use global cache settings. See the *Global cache configuration* section for detail. If enabled, only 'enabled' toggles for in-memory & Redis configuration are evaluated.
- `cache.default_ttl`: The default time-to-live for cache entries in seconds. Only used in case multiple cache layers are enabled.
- inmemory_settings: Configuration settings for in-memory caching. In-memory cache is stored in the plugin's process memory.
  - `cache.inmemory_settings.enabled`: Boolean flag to enable or disable in-memory cache.
- redis_settings: Configuration settings for Redis. Redis cache is shared between pods.
  - `cache.redis_settings.enabled`: Boolean flag to enable or disable Redis cache.
  - `cache.redis_settings.redis_url`: The URL for the Redis server, with port. Mandatory if enabled.
  - `cache.redis_settings.cluster_enabled`: Must be enabled if Redis is running in cluster mode (multiple instances).
  - `cache.redis_settings.tls_enabled`: Must be enabled if TLS is required for Redis connection.
  - `cache.redis_settings.username`: The username for Redis authentication (if required). Can use environment variable vault.
  - `cache.redis_settings.password`: The password for Redis authentication (if required). Can use environment variable vault.

### sts

Configuration settings for AAA STS authentication. AAA STS does not provide JWKS or '.well-known/openid-configuration', although the token is JWT: introspect endpoint must be called and introspect URL configured explicitly.

- `sts.enabled`: Boolean flag to enable or disable STS authentication.
- `sts.url`: The introspect URL. Mandatory if enabled.
- `sts.issuers`: A list of allowed issuers. Mandatory if enabled.
- `sts.use_json`: Boolean flag to define the type of STS API: urlencoded or JSON.

### heimdall

Configuration settings for Heimdall authentication. Although Heimdall tokens are JWT and '.well-known/openid-configuration' exists, its format is custom and do not match the issuer. JWKS URL must be provided explicitly.

- `heimdall.enabled`: Boolean flag to enable or disable Heimdall authentication.
- `heimdall.issuer`: The issuer URL. Mandatory if enabled.
- `heimdall.jwks_url`: The JWKS URL. Mandatory if enabled.

### upstream

Configuration settings for passing data to upstream. All values here are optional

- `upstream.auth_token_header`: The header name for the authentication token.
- `upstream.auth_token_kind_header`: The header name for the authentication token kind.
- `upstream.entra_oid_header`: The header name for the Entra OID.
- `upstream.uuid_header`: The header name for the AAA UUID.
- `upstream.client_id_header`: The header name for the client (application) ID (Note: not all token kinds have such claim).

## ODPSAuth configuration

ODPSAuth plugin performs authorization check against AAA ODPS. It takes the configured list of PO and performs ODPS PO check for the authenticated user (AAA UUID). If user has all the required PO access is granted. It is possible to configure caching of PO check results to improve performance and reduce strain on the service. Optionally, plugin can send the matched PO to the upstream.

Plugin configuration parameters are described below. Related option are grouped together.

### common

- `log_level`: The log level for the plugin. Default is `info`.
- `forbidden_error_message`: Error message to return with 403 status code. If specified, overrides default messages provided by the plugin.

### odps

- `odps.url`: The AAA ODPS URL. Example: "https://aaa-odps-ppe-use1.int.refinitiv.com"
- `odps.appid`: Application ID provided during the ODPS onboarding.
- `odps.required_permissions`: List of PO required to access the protected resource. Format: each entry is a comma separated list of service:po pairs. These pairs are evaluated using AND operator, i.e., all PO within an entry must be matched for access to be granted. Entries themselves are evaluated using OR operator, i.e., any single matched entry is sufficient for access.

### cache

Configuration settings for caching PO check results for user. If enabled, the PO check result will be stored in cache in for predefined period of time. PO list is not requested again from back-end until cache is expired. It is possible to enable both in-memory and Redis cache at the same time: in such case lookup is first done in the in-memory one.

- `cache.enabled`: Boolean flag to enable or disable caching.
- `cache.use_global_cache`: Boolean flag to use global cache settings. See the global cache section for detail. If enabled, only 'enabled' toggles for in-memory & Redis configuration are evaluated.
- `cache.default_ttl`: The default time-to-live for cache entries in seconds. Only used in case multiple cache layers are enabled.
- inmemory_settings: Configuration settings for in-memory caching. In-memory cache is stored in the plugin's process memory.
  - `cache.inmemory_settings.enabled`: Boolean flag to enable or disable in-memory cache.
- redis_settings: Configuration settings for Redis. Redis cache is shared between pods.
  - `cache.redis_settings.enabled`: Boolean flag to enable or disable Redis cache.
  - `cache.redis_settings.redis_url`: The URL for the Redis server, with port. Mandatory if enabled.
  - `cache.redis_settings.cluster_enabled`: Must be enabled if Redis is running in cluster mode (multiple instances).
  - `cache.redis_settings.tls_enabled`: Must be enabled if TLS is required for Redis connection.
  - `cache.redis_settings.username`: The username for Redis authentication (if required). Can use environment variable vault.
  - `cache.redis_settings.password`: The password for Redis authentication (if required). Can use environment variable vault.

### upstream

Configuration settings for passing data to upstream. All values here are optional

- `upstream.po_header`: The header name for matched PO list. Format: comma separated service:po pairs.

## Configuration templates

### AuthN yaml configuration template

```yaml
plugins:
- config:
    authorization_cookie_name: null
    authorization_header_name: authorization
    cache:
      default_ttl: 300
      enabled: true
      inmemory_settings:
        enabled: true
      redis_settings:
        cluster_enabled: null
        enabled: false
        password: null
        redis_url: null
        tls_enabled: null
        username: null
      use_global_cache: false
    entra:
      allowed_audience: null
      allowed_issuers: null
      enabled: false
      prefix: null
    heimdall:
      enabled: false
      issuer: null
      jwks_url: null
    log_level: info
    ping:
      client_id: null
      client_secret: null
      enabled: false
      issuer: null
    preserve_authorization_header: null
    sts:
      enabled: false
      issuers: null
      url: null
      use_json: true
    upstream:
      auth_token_header: Auth-Token
      auth_token_kind_header: Auth-Token-Kind
      entra_oid_header: Entra-User-Identifier
      uuid_header: User-Identifier
  enabled: true
  name: authn
  protocols:
  - grpc
  - grpcs
  - http
  - https
```

### ODPSAuth yaml configuration template

```yaml
plugins:
- config:
    cache:
      default_ttl: null
      enabled: true
      inmemory_settings:
        enabled: true
      redis_settings:
        cluster_enabled: null
        enabled: null
        password: null
        redis_url: null
        tls_enabled: null
        username: null
      use_global_cache: null
    log_level: "info"
    odps:
      appid: null
      required_permissions: null
      url: null
    upstream:
      po_header: ODPS-Po-List
  enabled: true
  name: odpsauth
  protocols:
  - grpc
  - grpcs
  - http
  - https
```
