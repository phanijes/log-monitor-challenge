package main

import (
	"upstreamentra/internal/upstreamentra"

	"github.com/Kong/go-pdk/server"
)

const (
	Version = "0.1.0"
	//should be lower than request transformer to allow header manipulations
	Priority = 620
)

func main() {
	server.StartServer(upstreamentra.New, Version, Priority)
}
