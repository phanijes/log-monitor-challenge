package entra

import (
	"common/cache/base"
	"common/log"
	"context"
	"crypto/sha256"
	"encoding/json"
	"math"
	"strings"
	"time"

	"github.com/Azure/azure-sdk-for-go/sdk/azcore/policy"
	"github.com/Azure/azure-sdk-for-go/sdk/azidentity"
)

type Credentials struct {
	ClientID     string
	ClientSecret string
	TenantID     string
	Scope        string
}

type EntraTokenRequestor struct {
	cacheEnabled bool
	cache        base.Cache
	credentials  Credentials
}

func NewEntraTokenRequestor(cacheEnabled bool, cache base.Cache, creds Credentials) *EntraTokenRequestor {
	return &EntraTokenRequestor{cacheEnabled: cacheEnabled, cache: cache, credentials: creds}
}

func (tr EntraTokenRequestor) GetToken(ctx context.Context) (*AccessToken, error) {
	cachedTokenKey := tr.buildEntraCachedTokenKey(tr.credentials)
	cachedToken := tr.getTokenFromCache(ctx, cachedTokenKey)

	if cachedToken != nil {
		return cachedToken, nil
	}
	log.FromContext(ctx).Info("cache miss for Entra token", "component", "entra")

	entraToken, err := tr.generateTokenFromEntra(ctx)
	if err != nil {
		log.FromContext(ctx).Error("error during creation of Entra token", "err", err, "component", "entra")
		return nil, err
	}

	log.FromContext(ctx).Info("new Entra token requested", "component", "entra")
	tr.addTokenToCache(ctx, entraToken, cachedTokenKey)
	return entraToken, nil
}

func (tr EntraTokenRequestor) getTokenFromCache(ctx context.Context, cachedTokenKey string) *AccessToken {
	if !tr.cacheEnabled {
		return nil
	}

	cachedToken, err := tr.cache.Get(ctx, cachedTokenKey)
	if err != nil && err != base.ErrCacheMiss {
		log.FromContext(ctx).Error("error during retrieving cached Entra token", "err", err, "component", "cache")
		return nil
	}

	if err == nil && cachedToken != nil {
		accessToken := new(AccessToken)
		if err := json.Unmarshal(cachedToken, accessToken); err != nil {
			log.FromContext(ctx).Error("error during decoding cached Entra token", "err", err, "component", "cache")
			return nil
		}

		if time.Until(accessToken.ExpiresOn)/time.Second > 10 {
			return accessToken
		}
	}

	return nil
}

func (tr EntraTokenRequestor) addTokenToCache(ctx context.Context, accessToken *AccessToken, cachedTokenKey string) {
	if !tr.cacheEnabled || accessToken == nil {
		return
	}

	jsonToken, err := json.Marshal(accessToken)
	if err != nil {
		log.FromContext(ctx).Error("error during encoding Entra access token for caching", "err", err, "component",
			"cache")
		return
	}

	ttl := math.Min(180, float64(time.Until(accessToken.ExpiresOn)/time.Second))
	if ttl > 0 {
		err = tr.cache.Set(ctx, cachedTokenKey, jsonToken, int(ttl))
		if err != nil {
			log.FromContext(ctx).Error("error during writing Entra token to cache", "err", err, "component", "cache")
		}
	}
}

func (tr EntraTokenRequestor) generateTokenFromEntra(ctx context.Context) (*AccessToken, error) {
	credential, err := azidentity.NewClientSecretCredential(tr.credentials.TenantID, tr.credentials.ClientID, tr.credentials.ClientSecret, nil)
	if err != nil {
		return nil, err
	}

	token, err := credential.GetToken(ctx, policy.TokenRequestOptions{Scopes: []string{tr.credentials.Scope}})
	if err != nil {
		return nil, err
	}

	return &AccessToken{Token: token.Token, ExpiresOn: token.ExpiresOn}, nil
}

const separator = "\x00"

func (tr EntraTokenRequestor) buildEntraCachedTokenKey(creds Credentials) string {
	h := sha256.New()
	h.Write([]byte(creds.ClientSecret))
	secret := string(h.Sum(nil))
	var sb strings.Builder
	sb.WriteString("upstream_entra_token")
	sb.WriteString(separator)
	sb.WriteString(creds.ClientID)
	sb.WriteString(separator)
	sb.WriteString(secret)
	sb.WriteString(separator)
	sb.WriteString(creds.TenantID)
	return sb.String()
}
