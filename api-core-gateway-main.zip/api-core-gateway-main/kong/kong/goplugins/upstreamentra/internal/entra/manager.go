package entra

import (
	"context"
	"slices"
	"sort"
	"strings"
	"time"
)

type TokenRequestor interface {
	GetToken(ctx context.Context) (*AccessToken, error)
}

type AccessToken struct {
	Token     string
	ExpiresOn time.Time
}

type TokenRequestorManager struct {
	headerNames      []string
	headerRules      map[string]TokenRequestor
	defaultRequestor TokenRequestor
}

func NewTokenRequestorManager(defaultRequestor TokenRequestor) *TokenRequestorManager {
	return &TokenRequestorManager{
		headerNames:      []string{},
		headerRules:      make(map[string]TokenRequestor),
		defaultRequestor: defaultRequestor,
	}
}

type Header struct {
	Name  string
	Value string
}

func (trm *TokenRequestorManager) AddRequestor(headers map[string]string, requestor TokenRequestor) {
	key := trm.makeHeaderMapKey(headers)
	trm.headerRules[key] = requestor
	for name := range headers {
		if !slices.Contains(trm.headerNames, name) {
			trm.headerNames = append(trm.headerNames, name)
		}
	}
}

func (trm TokenRequestorManager) ListHeaderNames() []string {
	return trm.headerNames
}

func (trm TokenRequestorManager) GetDefaultRequestor() TokenRequestor {
	return trm.defaultRequestor
}

func (trm TokenRequestorManager) GetRequestor(ctx context.Context, headers map[string]string) (TokenRequestor, bool) {
	key := trm.makeHeaderMapKey(headers)
	requestor, ok := trm.headerRules[key]
	if !ok {
		return trm.defaultRequestor, false
	}
	return requestor, true
}

func (trm TokenRequestorManager) makeHeaderMapKey(headers map[string]string) string {
	pairs := make([]string, 0, len(headers))
	for name, value := range headers {
		pairs = append(pairs, name+":"+value)
	}
	sort.Strings(pairs)
	return strings.Join(pairs, ",")
}
