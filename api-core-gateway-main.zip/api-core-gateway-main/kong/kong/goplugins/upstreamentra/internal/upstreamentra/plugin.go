package upstreamentra

import (
	"common/cache/base"
	"common/configuration"
	"common/log"
	"common/plugin"
	"sync"
	"upstreamentra/internal/entra"
)

type DownstreamEntraPlugin struct {
	CacheSettings      plugin.CacheSettings `json:"cache"`
	DefaultCredentials CredentialsConfig    `json:"default_credentials"`
	Rules              []RuleConfig         `json:"rules"`
	LogLevel           string               `json:"log_level" schema:"default=info"`
	//
	tokenRequestorManager *entra.TokenRequestorManager
	cache                 base.Cache
	vault                 configuration.Vault
	once                  *sync.Once
	logger                log.Logger
}

type CredentialsConfig struct {
	ClientID     string `json:"client_id"`
	ClientSecret string `json:"client_secret"`
	TenantID     string `json:"tenant_id"`
	Scope        string `json:"scope"`
}

type RuleConfig struct {
	Credentials      CredentialsConfig `json:"credentials"`
	HeaderConditions map[string]string `json:"header_conditions"`
}

func New() interface{} {
	return &DownstreamEntraPlugin{once: new(sync.Once)}
}

func init() {
	plugin.InitGlobalCache(plugin.GLOBAL_PLUGIN_SETTINGS)
}

func (p *DownstreamEntraPlugin) GetSchemaFields() ([]map[string]interface{}, map[string]interface{}) {
	additionalFields := []map[string]interface{}{
		{"consumer": plugin.SchemaNoConsumer},
		{"protocols": plugin.SchemaProtocolsHttp},
	}
	checks := []map[string]interface{}{}
	checks = append(checks, plugin.SchemaCacheEntityChecks...)
	additionalConfigFields := map[string]interface{}{"entity_checks": checks}
	return additionalFields, additionalConfigFields
}
