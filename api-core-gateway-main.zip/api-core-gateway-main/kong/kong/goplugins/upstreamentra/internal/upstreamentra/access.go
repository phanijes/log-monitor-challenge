package upstreamentra

import (
	"common/configuration"
	"common/log"
	"common/plugin"
	"common/response"
	"context"
	"fmt"
	"net/http"
	"time"
	"upstreamentra/internal/entra"

	"github.com/Kong/go-pdk"
)

func (p *DownstreamEntraPlugin) Init() {
	p.logger = log.New(p.LogLevel)
	p.logger.Info("initializing plugin", "logLevel", p.LogLevel)
	p.vault = configuration.NewSimpleVault()
	p.cache = plugin.InitCache(p.vault, p.CacheSettings, p.logger)
	defaultRequestor := entra.NewEntraTokenRequestor(p.CacheSettings.Enabled, p.cache, parseCredentials(p.vault, p.DefaultCredentials, p.logger))
	p.tokenRequestorManager = entra.NewTokenRequestorManager(defaultRequestor)
	for _, rule := range p.Rules {
		r := entra.NewEntraTokenRequestor(p.CacheSettings.Enabled, p.cache, parseCredentials(p.vault, rule.Credentials, p.logger))
		p.tokenRequestorManager.AddRequestor(rule.HeaderConditions, r)
	}
}

// timeout for request processing to set in the context
// 5 seconds is more than enough
const requestTimeoutSeconds = 5

func (p *DownstreamEntraPlugin) Access(kong *pdk.PDK) {
	p.once.Do(p.Init)
	ctx, cancel := context.WithTimeout(context.Background(), time.Duration(time.Second*requestTimeoutSeconds))
	defer cancel()
	ctx = plugin.AddCorrelationIdToLogger(ctx, p.logger, kong.Request)
	err := p.access(ctx, kong)
	if err != nil {
		p.reportError(ctx, kong, err)
	}
}

func (p *DownstreamEntraPlugin) reportError(ctx context.Context, kong *pdk.PDK, err error) {
	response.KongExit(ctx, kong, err, http.Header{})
}

func (p *DownstreamEntraPlugin) access(ctx context.Context, kong *pdk.PDK) error {
	p.once.Do(p.Init)
	logger := log.FromContext(ctx)
	timeTaken := time.Now()
	defer func() {
		logger.Info("Upstream authentication time taken (ms)", "took", time.Since(timeTaken)/time.Millisecond)
	}()

	tokenRequestor := p.tokenRequestorManager.GetDefaultRequestor()
	headers, err := p.collectHeaders(ctx, kong)
	if err != nil {
		logger.Error("failed to collect headers")
		return response.NewErrorResponse(500, "internal server error")
	}
	var ok bool
	if headers != nil {
		if tokenRequestor, ok = p.tokenRequestorManager.GetRequestor(ctx, headers); !ok {
			logger.Info("no rule matching request headers. Using default settings", "headers", headers)
		}
	}

	token, err := tokenRequestor.GetToken(ctx)
	if err != nil {
		logger.Error("failed to get token", "err", err)
		return response.NewErrorResponse(500, "internal server error")
	}

	if err := kong.ServiceRequest.SetHeader("Authorization", fmt.Sprintf("Bearer %s", token.Token)); err != nil {
		logger.Error("failed to set Authorization header", "err", err)
		return response.NewErrorResponse(500, "internal server error")
	}

	logger.Info("authentication success")
	return nil
}

func (p *DownstreamEntraPlugin) collectHeaders(ctx context.Context, kong *pdk.PDK) (map[string]string, error) {
	headerNames := p.tokenRequestorManager.ListHeaderNames()
	if len(headerNames) == 0 {
		return nil, nil
	}
	headers := map[string]string{}
	for _, headerName := range headerNames {
		headerValue, err := kong.Request.GetHeader(headerName)
		if err != nil {
			log.FromContext(ctx).Error("failed to get header value", "header", headerName)
			return nil, err
		}
		headers[headerName] = headerValue
	}
	return headers, nil
}

func parseCredentials(vault configuration.Vault, credCfg CredentialsConfig, logger log.Logger) entra.Credentials {
	creds := entra.Credentials{
		ClientID:     vault.TryParseReference(credCfg.ClientID, logger),
		ClientSecret: vault.TryParseReference(credCfg.ClientSecret, logger),
		TenantID:     vault.TryParseReference(credCfg.TenantID, logger),
		Scope:        vault.TryParseReference(credCfg.Scope, logger),
	}
	if creds.Scope == "" {
		creds.Scope = "api://" + creds.ClientID + "/.default"
	}
	return creds
}
