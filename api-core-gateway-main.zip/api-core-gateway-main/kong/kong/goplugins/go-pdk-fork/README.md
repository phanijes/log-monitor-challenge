[![Build Status][gha-workflow-badge]][gha-workflow-url] [![Latest release][gha-latest-release]][gha-releases-url]

# Kong Plugin Development Kit - Go edition

Docs: https://pkg.go.dev/github.com/Kong/go-pdk.

[gha-workflow-badge]: https://github.com/Kong/go-pdk/actions/workflows/test.yml/badge.svg
[gha-workflow-url]: https://github.com/Kong/go-pdk/actions/workflows/test.yml
[gha-latest-release]: https://img.shields.io/github/v/release/Kong/go-pdk.svg
[gha-releases-url]: https://github.com/Kong/go-pdk/releases
