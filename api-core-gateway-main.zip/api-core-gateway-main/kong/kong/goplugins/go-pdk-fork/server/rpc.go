package server

import (
	"log"
	"reflect"
	"strings"
	"sync"
	"time"
)

type rpcHandler struct {
	constructor       func() interface{}
	configType        reflect.Type
	version           string // version number
	priority          int    // priority info
	lock              sync.RWMutex
	instances         map[int]*instanceData
	events            map[int]*eventData
	lastCloseInstance time.Time
}

var methodNames = [...]string{
	"Certificate",
	"Rewrite",
	"Access",
	"Response",
	"Preread",
	"Log",
}

func getHandlerNames(t reflect.Type) []string {
	handlers := []string{}
	for _, name := range methodNames {
		_, hasIt := t.MethodByName(name)
		if hasIt {
			handlers = append(handlers, strings.ToLower(name))
		}
	}
	return handlers
}

func newRpcHandler(constructor func() interface{}, version string, priority int) *rpcHandler {

	constructorType := reflect.TypeOf(constructor)
	if constructorType == nil {
		log.Printf("nil constructor")
		return nil
	}

	if constructorType.Kind() != reflect.Func {
		log.Printf("Constructor is not a function")
		return nil
	}

	if constructorType.NumIn() != 0 || constructorType.NumOut() != 1 {
		log.Printf("Wrong constructor signature")
		return nil
	}

	return &rpcHandler{
		constructor: constructor,
		configType:  reflect.TypeOf(constructor()),
		version:     version,
		priority:    priority,
		instances:   map[int]*instanceData{},
		events:      map[int]*eventData{},
	}
}

type pluginInfo struct {
	Name     string     // plugin name
	ModTime  time.Time  `codec:",omitempty"` // plugin file modification time
	LoadTime time.Time  `codec:",omitempty"` // plugin load time
	Phases   []string   // events it can handle
	Version  string     // version number
	Priority int        // priority info
	Schema   schemaDict // representation of the config schema
}

func (rh *rpcHandler) getInfo() (info pluginInfo, err error) {
	name, err := getName()
	if err != nil {
		return
	}

	info = pluginInfo{
		Name:     name,
		Phases:   getHandlerNames(rh.configType),
		Schema:   GetSchema(name, rh.configType),
		Version:  rh.version,
		Priority: rh.priority,
	}

	return
}
