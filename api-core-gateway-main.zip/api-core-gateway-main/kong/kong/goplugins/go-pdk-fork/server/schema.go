package server

import (
	"reflect"
	"strconv"
	"strings"
)

type schemaDict map[string]interface{}

func GetSchema(name string, t reflect.Type) schemaDict {
	fields := []schemaDict{}
	config := getSchemaDict(t)
	if m, ok := t.MethodByName("GetSchemaFields"); ok {
		result := m.Func.Call([]reflect.Value{reflect.New(t).Elem()})
		if len(result) > 0 {
			schemaFields, ok := result[0].Interface().([]map[string]interface{})
			if ok {
				for _, resField := range schemaFields {
					fields = append(fields, resField)
				}
			}
		}
		if len(result) > 1 {
			configItems, ok := result[1].Interface().(map[string]interface{})
			if ok {
				for key, value := range configItems {
					config[key] = value
				}
			}
		}
	}

	fields = append(fields, schemaDict{"config": config})
	schema := schemaDict{
		"name":   name,
		"fields": fields,
	}
	return schema
}

func getSchemaDict(t reflect.Type) schemaDict {
	switch t.Kind() {
	case reflect.String:
		return schemaDict{"type": "string"}

	case reflect.Bool:
		return schemaDict{"type": "boolean"}

	case reflect.Int, reflect.Int32:
		return schemaDict{"type": "integer"}

	case reflect.Uint, reflect.Uint32:
		return schemaDict{
			"type":    "integer",
			"between": []int{0, 2147483648},
		}

	case reflect.Float32, reflect.Float64:
		return schemaDict{"type": "number"}

	case reflect.Ptr:
		return getSchemaDict(t.Elem())

	case reflect.Slice:
		elemType := getSchemaDict(t.Elem())
		if elemType == nil {
			break
		}
		return schemaDict{
			"type":     "array",
			"elements": elemType,
		}

	case reflect.Map:
		kType := getSchemaDict(t.Key())
		vType := getSchemaDict(t.Elem())
		if kType == nil || vType == nil {
			break
		}
		return schemaDict{
			"type":   "map",
			"keys":   kType,
			"values": vType,
		}

	case reflect.Struct:
		fieldsArray := []schemaDict{}
		for i := 0; i < t.NumField(); i++ {
			field := t.Field(i)
			// ignore unexported fields
			if len(field.PkgPath) != 0 {
				continue
			}
			typeDecl := getSchemaDict(field.Type)
			if typeDecl == nil {
				// ignore unrepresentable types
				continue
			}
			name := field.Tag.Get("json")
			if name == "" {
				name = strings.ToLower(field.Name)
			}
			typeDecl = processSchemaTag(field.Type, field.Tag.Get("schema"), typeDecl)
			fieldsArray = append(fieldsArray, schemaDict{name: typeDecl})
		}
		return schemaDict{
			"type":   "record",
			"fields": fieldsArray,
		}
	}

	return nil
}

func processSchemaTag(fieldType reflect.Type, schemaTag string, typeDecl schemaDict) schemaDict {
	schemaField := parseSchemaTag(schemaTag)
	if schemaField.Default != nil {
		switch fieldType.Kind() {
		case reflect.String:
			typeDecl["default"] = *schemaField.Default
		case reflect.Bool:
			typeDecl["default"] = (strings.ToLower(*schemaField.Default) == "true")
		case reflect.Int, reflect.Int32:
			typeDecl["default"], _ = strconv.Atoi(*schemaField.Default)
		}
	}
	if schemaField.Required != nil {
		typeDecl["required"] = true
	}
	if schemaField.Description != nil {
		typeDecl["description"] = *schemaField.Description
	}
	return typeDecl
}

type schemaField struct {
	Required    *bool
	Default     *string
	Description *string
}

func parseSchemaTag(schemaTag string) schemaField {
	schema := schemaField{}
	if schemaTag == "" {
		return schema
	}

	parts := strings.Split(schemaTag, "|")
	for _, part := range parts {
		part = strings.TrimSpace(part)
		switch {
		case part == "required":
			schema.Required = boolRef(true)
		case strings.HasPrefix(part, "default="):
			schema.Default = stringRef(part[8:])
		//Note: description is not supported by Kong for custom plugins.
		case strings.HasPrefix(part, "description="):
			schema.Description = stringRef(part[12:])
		}
	}

	return schema
}

func stringRef(s string) *string {
	return &s
}

func boolRef(b bool) *bool {
	return &b
}
