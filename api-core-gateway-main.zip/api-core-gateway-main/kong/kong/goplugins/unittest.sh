#!/bin/bash

echo "Running unit tests..."

for d in ./*/
do
    if [[ "$d" == *"vendor"* ]] || [[ "$d" == *"go-pdk-fork"*  ]]
    then
        continue;
    fi
    echo "$d"
    (cd "$d" && go test ./... -cover) || exit 1
done

echo "...done"