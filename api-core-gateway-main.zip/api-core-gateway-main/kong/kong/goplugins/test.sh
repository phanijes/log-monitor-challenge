#!/bin/bash

go install github.com/jstemmer/go-junit-report/v2@latest
echo "Running unit tests..."

for d in ./*/
do
    if [[ "$d" == *"vendor"* ]] || [[ "$d" == *"go-pdk-fork"*  ]]
    then
        continue;
    fi
    echo "$d"
    (cd "$d" && go test ./... -cover -coverprofile=coverage.txt -json 2>&1 > test.json) || exit 1
    cat "$d/test.json" | go-junit-report -parser gojson > report.xml
    sed -i '2,$ s/^/kong\/kong\/goplugins\//' $d/coverage.txt
    sed -i 's/\("Package":"\)\([^"]*\)"/\1\/builds\/app\/app-51695\/api-gateway\/api-core-gateway\/kong\/kong\/goplugins\/\2"/' $d/test.json
    name=$(echo $d | sed 's|\./||g' | sed 's|\/||g')
    mv "report.xml" "$name.xml"
    mv "$d/coverage.txt" "$name.txt"
    mv "$d/test.json" "$name.json"
done

echo "...done"