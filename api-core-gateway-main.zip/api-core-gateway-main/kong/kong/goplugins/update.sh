#!/bin/bash

export GOPROXY=direct
echo "Updating Go dependencies..."

for d in ./*/
do
    if [[ "$d" == *"vendor"* ]]
    then
        continue;
    fi
    echo "$d"
    (cd "$d" && go mod tidy) || exit 1
done

echo "...done"