package main

import (
	"authn/internal/auth"
	"encoding/json"
	"log"
	"os"
	"reflect"
	"testing"

	"github.com/Kong/go-pdk/server"
	"github.com/stretchr/testify/assert"
)

func TestSchema(t *testing.T) {
	refSchema, err := os.ReadFile("schema.json")
	assert.NoError(t, err)

	plugin := &auth.AuthNPlugin{}
	got := server.GetSchema("authn", reflect.TypeOf(plugin))
	schema, err := json.Marshal(got)
	assert.NoError(t, err)
	log.Println(string(schema))

	assert.JSONEq(t, string(refSchema), string(schema))
}
