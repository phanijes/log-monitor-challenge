package main

import (
	"authn/internal/auth"

	"github.com/Kong/go-pdk/server"
)

const (
	Version = "0.0.1"
	//openid-connect is 1050.
	Priority = 1045
)

func main() {
	server.StartServer(auth.New, Version, Priority)
}
