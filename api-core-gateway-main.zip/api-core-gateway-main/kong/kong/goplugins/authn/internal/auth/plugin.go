package auth

import (
	"authn/internal/introspect"
	"common/cache/base"
	"common/configuration"
	"common/log"
	"common/plugin"
	"sync"
)

type PingSettings struct {
	Enabled      bool   `json:"enabled"`
	Issuer       string `json:"issuer"`
	ClientID     string `json:"client_id"`
	ClientSecret string `json:"client_secret"`
}

type EntraSettings struct {
	Enabled         bool     `json:"enabled"`
	Prefix          string   `json:"prefix"`
	AllowedIssuers  []string `json:"allowed_issuers"`
	AllowedAudience []string `json:"allowed_audience"`
}

type STSSettings struct {
	Enabled bool     `json:"enabled"`
	URL     string   `json:"url"`
	Issuers []string `json:"issuers"`
	UseJSON bool     `json:"use_json" schema:"default=true"`
}

type HeimdallSettings struct {
	Enabled bool   `json:"enabled"`
	Issuer  string `json:"issuer"`
	JWKSURL string `json:"jwks_url"`
}

type UpstreamSettings struct {
	UUIDHeader          string `json:"uuid_header" schema:"default=User-Identifier"`
	EntraOidHeader      string `json:"entra_oid_header" schema:"default=Entra-User-Identifier"`
	AuthTokenHeader     string `json:"auth_token_header" schema:"default=Auth-Token"`
	AuthTokenKindHeader string `json:"auth_token_kind_header" schema:"default=Auth-Token-Kind"`
	ClientIdHeader      string `json:"client_id_header"`
}

type AuthNPlugin struct {
	PingSettings             PingSettings         `json:"ping"`
	EntraSettings            EntraSettings        `json:"entra"`
	CacheSettings            plugin.CacheSettings `json:"cache"`
	STSSettings              STSSettings          `json:"sts"`
	HeimdallSettings         HeimdallSettings     `json:"heimdall"`
	UpstreamSettings         UpstreamSettings     `json:"upstream"`
	KeepAuthHeader           bool                 `json:"preserve_authorization_header"`
	AuthorizationHeaderName  string               `json:"authorization_header_name" schema:"default=Authorization"`
	AuthorizationCookieName  string               `json:"authorization_cookie_name"`
	UnauthorizedErrorMessage string               `json:"unauthorized_error_message"`
	LogLevel                 string               `json:"log_level" schema:"default=info"`
	//Non-configuration fields below
	introspector introspect.TokenIntrospector
	once         *sync.Once
	cache        base.Cache
	logger       log.Logger
	vault        configuration.Vault
}

func New() interface{} {
	return &AuthNPlugin{once: new(sync.Once)}
}

func init() {
	plugin.InitGlobalCache(plugin.GLOBAL_PLUGIN_SETTINGS)
}

func (p *AuthNPlugin) GetSchemaFields() ([]map[string]interface{}, map[string]interface{}) {
	additionalFields := []map[string]interface{}{
		{"consumer": plugin.SchemaNoConsumer},
		{"protocols": plugin.SchemaProtocolsHttp},
	}
	checks := []map[string]interface{}{}
	checks = append(checks, entityChecks...)
	checks = append(checks, plugin.SchemaCacheEntityChecks...)
	additionalConfigFields := map[string]interface{}{"entity_checks": checks}
	return additionalFields, additionalConfigFields
}

var entityChecks = []map[string]interface{}{
	{
		"conditional": map[string]interface{}{
			"if_field":   "ping.enabled",
			"if_match":   map[string]interface{}{"eq": true},
			"then_field": "ping.issuer",
			"then_match": map[string]interface{}{"required": true},
		},
	},
	{
		"conditional": map[string]interface{}{
			"if_field":   "sts.enabled",
			"if_match":   map[string]interface{}{"eq": true},
			"then_field": "sts.url",
			"then_match": map[string]interface{}{"required": true},
		},
	},
	{
		"conditional": map[string]interface{}{
			"if_field":   "sts.enabled",
			"if_match":   map[string]interface{}{"eq": true},
			"then_field": "sts.issuers",
			"then_match": map[string]interface{}{"required": true},
		},
	},
	{
		"conditional": map[string]interface{}{
			"if_field":   "heimdall.enabled",
			"if_match":   map[string]interface{}{"eq": true},
			"then_field": "heimdall.issuer",
			"then_match": map[string]interface{}{"required": true},
		},
	},
	{
		"conditional": map[string]interface{}{
			"if_field":   "heimdall.enabled",
			"if_match":   map[string]interface{}{"eq": true},
			"then_field": "heimdall.jwks_url",
			"then_match": map[string]interface{}{"required": true},
		},
	},
	{
		"conditional_at_least_one_of": map[string]interface{}{
			"if_field":             "entra.enabled",
			"if_match":             map[string]interface{}{"eq": true},
			"then_at_least_one_of": []string{"entra.prefix", "entra.allowed_issuers"},
			"then_err":             "either 'entra.prefix' or 'entra.allowed_issuers' must be configured",
		},
	},
}
