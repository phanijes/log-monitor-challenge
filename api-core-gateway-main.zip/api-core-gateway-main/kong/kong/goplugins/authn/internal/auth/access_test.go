package auth

import (
	"authn/internal/introspect"
	"common/log"
	"common/response"
	"context"
	"errors"
	"testing"
	"time"

	kongclient "github.com/Kong/go-pdk/client"
	kongentities "github.com/Kong/go-pdk/entities"
	"github.com/stretchr/testify/assert"
)

type mockKongRequest struct {
	headers map[string]string
	f       func(header string) (string, error)
	err     error
}

func (m *mockKongRequest) GetHeader(header string) (string, error) {
	if m.f != nil {
		return m.f(header)
	}
	return m.headers[header], m.err
}

func TestAuthNPlugin_isActive(t *testing.T) {
	tests := []struct {
		name   string
		result *introspect.IntrospectResult
		want   bool
	}{
		{
			"nil",
			nil,
			false,
		},
		{
			"inactive",
			&introspect.IntrospectResult{Active: false},
			false,
		},
		{
			"expired",
			&introspect.IntrospectResult{Active: true, Expiration: time.Now().Add(time.Second * -5).Unix()},
			false,
		},
		{
			"valid",
			&introspect.IntrospectResult{Active: true, Expiration: time.Now().Add(time.Second * 5).Unix()},
			true,
		},
	}
	p := &AuthNPlugin{}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			got := p.isActive(tt.result)
			assert.Equal(t, tt.want, got)
		})
	}
}

type mockClientAuthenticator struct {
	consumer *kongentities.Consumer
	creds    *kongclient.AuthenticatedCredential
	err      error
}

func (m *mockClientAuthenticator) Authenticate(consumer *kongentities.Consumer, credential *kongclient.AuthenticatedCredential) error {
	m.consumer = consumer
	m.creds = credential
	return m.err
}

type mockRequestHeaderSetter struct {
	headers  map[string][]string
	setErr   error
	clearErr error
}

func (m *mockRequestHeaderSetter) SetHeaders(headers map[string][]string) error {
	if m.headers == nil {
		m.headers = headers
	} else {
		for k, v := range headers {
			m.headers[k] = v
		}
	}
	return m.setErr
}

func (m *mockRequestHeaderSetter) ClearHeader(name string) error {
	delete(m.headers, name)
	return m.clearErr
}

type mockIntrospector struct {
	ctx    context.Context
	token  string
	result *introspect.IntrospectResult
	err    error
}

func (m *mockIntrospector) Introspect(ctx context.Context, token string) (*introspect.IntrospectResult, error) {
	m.ctx = ctx
	m.token = token
	return m.result, m.err
}

func TestAuthNPlugin_introspect(t *testing.T) {
	exp := time.Now().Add(time.Second * 5).Unix()
	tests := []struct {
		name         string
		introspector introspect.TokenIntrospector
		token        string
		credentialId string
		expected     *introspect.IntrospectResult
		errMsg       string
	}{
		{
			"ok",
			&mockIntrospector{result: &introspect.IntrospectResult{Active: true, Expiration: exp, Kind: "ping", UUID: "myId"}},
			"myToken",
			"myId",
			&introspect.IntrospectResult{UUID: "myId", Expiration: exp, Active: true, Kind: "ping"},
			"",
		},
		{
			"error",
			&mockIntrospector{err: errors.New("some error")},
			"",
			"",
			nil,
			"some error",
		},
		{
			"inactive token",
			&mockIntrospector{result: &introspect.IntrospectResult{Active: false}},
			"",
			"",
			nil,
			"token inactive or expired",
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			p := &AuthNPlugin{introspector: tt.introspector}
			result, err := p.introspect(log.NewContext(context.Background(), log.NewSimpleLogger()), tt.token)
			if err != nil || tt.errMsg != "" {
				assert.EqualError(t, err, tt.errMsg)
				return
			}
			assert.NoError(t, err)
			assert.Equal(t, tt.expected, result)
		})
	}
}

func TestAuthNPlugin_createFactoryCfg(t *testing.T) {
	tests := []struct {
		name   string
		plugin *AuthNPlugin
		want   introspect.FactoryCfg
	}{
		{
			"empty",
			&AuthNPlugin{},
			introspect.FactoryCfg{},
		},
		{
			"ping only",
			&AuthNPlugin{PingSettings: PingSettings{Enabled: true, Issuer: "https://ping.com"}},
			introspect.FactoryCfg{PingIssuer: "https://ping.com"},
		},
		{
			"entra only",
			&AuthNPlugin{EntraSettings: EntraSettings{Enabled: true, Prefix: "abc", AllowedIssuers: []string{"https://ms.com"}, AllowedAudience: []string{"123"}}},
			introspect.FactoryCfg{EntraPrefix: "abc", EntraIssuers: []string{"https://ms.com"}, EntraAudience: []string{"123"}},
		},
		{
			"ping & entra",
			&AuthNPlugin{
				PingSettings:  PingSettings{Enabled: true, Issuer: "https://ping.com"},
				EntraSettings: EntraSettings{Enabled: true, Prefix: "abc", AllowedIssuers: []string{"https://ms.com"}, AllowedAudience: []string{"123"}},
			},
			introspect.FactoryCfg{PingIssuer: "https://ping.com", EntraPrefix: "abc", EntraIssuers: []string{"https://ms.com"}, EntraAudience: []string{"123"}},
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			got := tt.plugin.createFactoryCfg()
			assert.Equal(t, tt.want, got)
		})
	}
}

func TestAuthNPlugin_wrapErrorResponse(t *testing.T) {
	tests := []struct {
		name           string
		custom401Error string
		err            error
		errMsg         string
	}{
		{
			"context canceled",
			"does not matter",
			context.Canceled,
			"status: 504, code: 504, message: authentication timeout",
		},
		{
			"token error",
			"",
			introspect.NewInvalidToken(errors.New("token error")),
			"status: 401, code: 401, message: token expired",
		},
		{
			"token custom error",
			"Unauthorized",
			introspect.NewInvalidToken(errors.New("token error")),
			"status: 401, code: 401, message: Unauthorized",
		},
		{
			"communication error",
			"does not matter",
			introspect.NewCommunicationError(errors.New("call error")),
			"status: 502, code: 502, message: authentication failed",
		},
		{
			"internal/generic error",
			"does not matter",
			errors.New("some error"),
			"status: 500, code: 500, message: internal server error",
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			p := &AuthNPlugin{UnauthorizedErrorMessage: tt.custom401Error}
			err := p.wrapErrorResponse(tt.err)
			resp := &response.ErrorResponse{}
			assert.ErrorAs(t, err, &resp)
			assert.EqualError(t, err, tt.errMsg)
		})
	}
}
func TestAuthNPlugin_getToken(t *testing.T) {
	tests := []struct {
		name        string
		plugin      *AuthNPlugin
		kongRequest requestHeaderGetter
		want        string
		errMsg      string
	}{
		{
			"header token",
			&AuthNPlugin{AuthorizationHeaderName: "Authorization"},
			&mockKongRequest{headers: map[string]string{"Authorization": "Bearer abc"}},
			"abc",
			"",
		},
		{
			"header token error",
			&AuthNPlugin{AuthorizationHeaderName: "Authorization"},
			&mockKongRequest{err: errors.New("some error"), headers: map[string]string{"Authorization": "Bearer abc"}},
			"",
			"error reading 'Authorization' header: some error",
		},
		{
			"non-bearer token",
			&AuthNPlugin{AuthorizationHeaderName: "Authorization"},
			&mockKongRequest{headers: map[string]string{"Authorization": "Basic abc"}},
			"",
			"non-Bearer header value",
		},
		{
			"cookie token",
			&AuthNPlugin{AuthorizationCookieName: "auth_cookie"},
			&mockKongRequest{headers: map[string]string{"Cookie": "auth_cookie=abc"}},
			"abc",
			"",
		},
		{
			"cookie token error",
			&AuthNPlugin{AuthorizationCookieName: "auth_cookie"},
			&mockKongRequest{err: errors.New("some error"), headers: map[string]string{"Cookie": "auth_cookie=abc"}},
			"",
			"error reading cookie: some error",
		},
		{
			"no token location configured",
			&AuthNPlugin{},
			&mockKongRequest{},
			"",
			"no access token location configured",
		},
		{
			"header token with fallback to cookie",
			&AuthNPlugin{AuthorizationHeaderName: "Authorization", AuthorizationCookieName: "auth_cookie"},
			&mockKongRequest{headers: map[string]string{"Authorization": "Bearer abc"}},
			"abc",
			"",
		},
		{
			"header token error with fallback to cookie",
			&AuthNPlugin{AuthorizationHeaderName: "Authorization", AuthorizationCookieName: "auth_cookie"},
			&mockKongRequest{headers: map[string]string{"Authorization": "Bearer abc", "Cookie": "auth_cookie=abc"},
				f: func(header string) (string, error) {
					if header == "Authorization" {
						return "", errors.New("some error")
					}
					return "auth_cookie=abc", nil
				}},
			"abc",
			"",
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			got, err := tt.plugin.getToken(tt.kongRequest)
			if err != nil || tt.errMsg != "" {
				assert.EqualError(t, err, tt.errMsg)
				return
			}
			assert.NoError(t, err)
			assert.Equal(t, tt.want, got)
		})
	}
}
func TestAuthNPlugin_setAuthenticated(t *testing.T) {
	type args struct {
		kongAuth    *mockClientAuthenticator
		kongRequest *mockRequestHeaderSetter
		token       string
		result      *introspect.IntrospectResult
	}
	tests := []struct {
		name           string
		args           args
		upstream       UpstreamSettings
		keepAuthHeader bool
		headers        map[string][]string
		credentialId   string
		errMsg         string
	}{
		{
			"ok entra",
			args{
				&mockClientAuthenticator{},
				&mockRequestHeaderSetter{headers: map[string][]string{"Authorization": {"some value"}}},
				"token_abc",
				&introspect.IntrospectResult{OID: "myOID", Kind: introspect.EntraKind},
			},
			UpstreamSettings{
				AuthTokenHeader:     "Auth-Token",
				AuthTokenKindHeader: "Auth-Token-Kind",
				EntraOidHeader:      "Entra-User-Identifier",
			},
			false,
			map[string][]string{
				"Entra-User-Identifier": {"myOID"},
				"Auth-Token":            {"token_abc"},
				"Auth-Token-Kind":       {introspect.EntraKind},
			},
			"myOID",
			"",
		},
		{
			"ok entra, keep auth header",
			args{
				&mockClientAuthenticator{},
				&mockRequestHeaderSetter{headers: map[string][]string{"Authorization": {"Bearer token_abc"}}},
				"token_abc",
				&introspect.IntrospectResult{OID: "myOID", UUID: "myUUID", Kind: introspect.EntraKind},
			},
			UpstreamSettings{
				AuthTokenHeader:     "Auth-Token",
				AuthTokenKindHeader: "Auth-Token-Kind",
				EntraOidHeader:      "Entra-User-Identifier",
			},
			true,
			map[string][]string{
				"Entra-User-Identifier": {"myOID"},
				"Auth-Token":            {"token_abc"},
				"Auth-Token-Kind":       {introspect.EntraKind},
				"Authorization":         {"Bearer token_abc"},
			},
			"myOID",
			"",
		},
		{
			"ok ping",
			args{
				&mockClientAuthenticator{},
				&mockRequestHeaderSetter{headers: map[string][]string{"Authorization": {"some value"}}},
				"token_abc",
				&introspect.IntrospectResult{UUID: "myUUID", Kind: introspect.PingKind, ClientID: "myClientID"},
			},
			UpstreamSettings{
				AuthTokenHeader:     "Auth-Token",
				AuthTokenKindHeader: "Auth-Token-Kind",
				UUIDHeader:          "User-Identifier",
			},
			false,
			map[string][]string{
				"User-Identifier": {"myUUID"},
				"Auth-Token":      {"token_abc"},
				"Auth-Token-Kind": {introspect.PingKind},
			},
			"myUUID",
			"",
		},
		{
			"ok sts with client id",
			args{
				&mockClientAuthenticator{},
				&mockRequestHeaderSetter{headers: map[string][]string{"Authorization": {"some value"}}},
				"token_abc",
				&introspect.IntrospectResult{UUID: "myUUID", Kind: introspect.STSKind, ClientID: "myClientID"},
			},
			UpstreamSettings{
				AuthTokenHeader:     "Auth-Token",
				AuthTokenKindHeader: "Auth-Token-Kind",
				UUIDHeader:          "User-Identifier",
				ClientIdHeader:      "Client-Id",
			},
			false,
			map[string][]string{
				"User-Identifier": {"myUUID"},
				"Auth-Token":      {"token_abc"},
				"Auth-Token-Kind": {introspect.STSKind},
				"Client-Id":       {"myClientID"},
			},
			"myUUID",
			"",
		},
		{
			"unknown token kind",
			args{
				&mockClientAuthenticator{},
				&mockRequestHeaderSetter{headers: map[string][]string{"Authorization": {"some value"}}},
				"token_abc",
				&introspect.IntrospectResult{OID: "myOID", UUID: "myUUID", Kind: "other"},
			},
			UpstreamSettings{},
			false,
			map[string][]string{},
			"",
			"unknown token kind other",
		},
		{
			"auth error",
			args{
				&mockClientAuthenticator{err: errors.New("some error")},
				&mockRequestHeaderSetter{},
				"token_abc",
				&introspect.IntrospectResult{OID: "myOID", UUID: "myUUID", Kind: introspect.PingKind},
			},
			UpstreamSettings{},
			false,
			map[string][]string{},
			"",
			"some error",
		},
		{
			"set error",
			args{
				&mockClientAuthenticator{},
				&mockRequestHeaderSetter{setErr: errors.New("some error")},
				"token_abc",
				&introspect.IntrospectResult{OID: "myOID", UUID: "myUUID", Kind: introspect.EntraKind},
			},
			UpstreamSettings{},
			false,
			map[string][]string{},
			"",
			"some error",
		},
		{
			"clear error",
			args{
				&mockClientAuthenticator{},
				&mockRequestHeaderSetter{clearErr: errors.New("some error")},
				"token_abc",
				&introspect.IntrospectResult{OID: "myOID", UUID: "myUUID", Kind: introspect.PingKind},
			},
			UpstreamSettings{},
			false,
			map[string][]string{},
			"",
			"some error",
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			p := &AuthNPlugin{
				KeepAuthHeader:   tt.keepAuthHeader,
				UpstreamSettings: tt.upstream,
			}
			err := p.setAuthenticated(tt.args.kongAuth, tt.args.kongRequest, tt.args.token, tt.args.result)
			if err != nil || tt.errMsg != "" {
				assert.EqualError(t, err, tt.errMsg)
				return
			}
			assert.NoError(t, err)
			assert.Equal(t, tt.headers, tt.args.kongRequest.headers)
			assert.Equal(t, tt.credentialId, tt.args.kongAuth.creds.Id)
			assert.Equal(t, "", tt.args.kongAuth.creds.ConsumerId)
			assert.Nil(t, tt.args.kongAuth.consumer)
		})
	}
}
