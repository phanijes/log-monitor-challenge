package auth

import (
	"authn/internal/introspect"
	"common/configuration"
	"common/log"
	"common/plugin"
	"common/response"
	"context"
	"errors"
	"fmt"
	"net/http"
	"net/url"
	"strings"
	"time"

	pdk "github.com/Kong/go-pdk"
	kongclient "github.com/Kong/go-pdk/client"
	kongentities "github.com/Kong/go-pdk/entities"
)

var client = &http.Client{Timeout: (requestTimeoutSeconds - 1) * time.Second}

// timeout for request processing to set in the context
// 6 seconds is more than enough
const requestTimeoutSeconds = 6

func (p *AuthNPlugin) Access(kong *pdk.PDK) {
	ctx, cancel := context.WithTimeout(context.Background(), time.Duration(time.Second*requestTimeoutSeconds))
	defer cancel()
	//init plugin on first call
	p.once.Do(p.Init)
	if p.introspector == nil {
		p.logger = log.NewSimpleLogger()
		p.logger.Fatal("plugin not initialized")
		p.reportAuthError(log.NewContext(ctx, p.logger), kong, response.NewErrorResponse(http.StatusInternalServerError, response.InternalServerError))
		return
	}
	ctx = plugin.AddCorrelationIdToLogger(ctx, p.logger, kong.Request)
	err := p.access(ctx, kong)
	if err != nil {
		p.reportAuthError(ctx, kong, err)
		return
	}
}

func (p *AuthNPlugin) Init() {
	p.logger = log.New(p.LogLevel)
	p.logger.Info("initializing plugin", "logLevel", p.LogLevel)

	p.vault = configuration.NewSimpleVault()
	p.cache = plugin.InitCache(p.vault, p.CacheSettings, p.logger)

	pingOpaque, err := p.createPingOpaqueIntrospector()
	if err != nil {
		p.logger.Fatal("failed to init PING introspector", "err", err)
		return
	}

	stsIntrospector, err := p.createSTSIntrospector()
	if err != nil {
		p.logger.Fatal("failed to init STS introspector", "err", err)
		return
	}

	factory := introspect.NewFactory(p.createFactoryCfg())
	p.introspector = introspect.NewTokenIntrospector(pingOpaque, stsIntrospector, p.STSSettings.Issuers, factory)
}

func (p *AuthNPlugin) createFactoryCfg() introspect.FactoryCfg {
	factoryCfg := introspect.FactoryCfg{}
	if p.PingSettings.Enabled {
		factoryCfg.PingIssuer = p.PingSettings.Issuer
	}
	if p.HeimdallSettings.Enabled {
		factoryCfg.HeimdallIssuer = p.HeimdallSettings.Issuer
		factoryCfg.HeimdallJWKSURL = p.HeimdallSettings.JWKSURL
	}
	if p.EntraSettings.Enabled {
		factoryCfg.EntraPrefix = p.EntraSettings.Prefix
		factoryCfg.EntraIssuers = p.EntraSettings.AllowedIssuers
		factoryCfg.EntraAudience = p.EntraSettings.AllowedAudience
	}
	return factoryCfg
}

func (p *AuthNPlugin) createPingOpaqueIntrospector() (*introspect.PingOpaqueIntrospector, error) {
	if !p.PingSettings.Enabled {
		return nil, nil
	}
	introspectUrl, err := url.JoinPath(p.PingSettings.Issuer, "as/introspect.oauth2")
	if err != nil {
		p.logger.Error("Bad Ping issuer URL format", "err", err, "issuer", p.PingSettings.Issuer)
		return nil, err
	}

	return introspect.NewPingOpaqueIntrospector(client, introspect.PingOpaqueConfig{
		CacheEnabled:           p.CacheSettings.Enabled,
		IntrospectURI:          introspectUrl,
		IntrospectClientID:     p.vault.TryParseReference(p.PingSettings.ClientID, p.logger),
		IntrospectClientSecret: p.vault.TryParseReference(p.PingSettings.ClientSecret, p.logger),
		IntrospectCacheTTL:     600,
	}, p.cache), nil
}

func (p *AuthNPlugin) createSTSIntrospector() (*introspect.STSIntrospector, error) {
	if !p.STSSettings.Enabled {
		return nil, nil
	}

	return introspect.NewSTSIntrospector(client, introspect.STSConfig{
		CacheEnabled:       p.CacheSettings.Enabled,
		IntrospectURI:      p.STSSettings.URL,
		UseJSON:            p.STSSettings.UseJSON,
		IntrospectCacheTTL: 300,
	}, p.cache), nil

}

func (p *AuthNPlugin) access(ctx context.Context, kong *pdk.PDK) error {
	logger := log.FromContext(ctx)
	timeTaken := time.Now()
	var getTokenTook, introspectTook, setAuthenticatedTook time.Duration
	var success bool
	var tokenKind string
	var tokenExp int64
	defer func() {
		logger.Info("Authentication result", "success", success, "kind", tokenKind, "exp", tokenExp,
			"took", time.Since(timeTaken)/time.Millisecond, "getTokenTook", getTokenTook, "introspectTook", introspectTook, "setAuthTook", setAuthenticatedTook)
	}()
	logger.Debug("configuration", "ping enabled", p.PingSettings.Enabled, "entra enabled", p.EntraSettings.Enabled)
	token, err := p.getToken(kong.Request)
	getTokenTook = time.Since(timeTaken) / time.Millisecond
	if err != nil {
		logger.Error("failed to extract token from request", "err", err)
		return p.UnauthorizedError("Bearer token required")
	}

	timeTakenIntrospect := time.Now()
	result, err := p.introspect(ctx, token)
	introspectTook = time.Since(timeTakenIntrospect) / time.Millisecond
	if err != nil {
		logger.Error("introspect failed", "err", err)
		return p.wrapErrorResponse(err)
	}

	tokenKind = result.Kind
	tokenExp = result.Expiration
	success = true

	//here error (if any) is always internal
	//TODO: do we need to return error for headers issue? just log it?
	timeTakenSetAuth := time.Now()
	err = p.setAuthenticated(kong.Client, kong.ServiceRequest, token, result)
	setAuthenticatedTook = time.Since(timeTakenSetAuth) / time.Millisecond
	if err != nil {
		logger.Error("setting Kong authentication failed", "err", err)
		return p.wrapErrorResponse(err)
	}

	return nil
}

func (p *AuthNPlugin) wrapErrorResponse(err error) error {
	var tokenErr *introspect.InvalidToken
	var communicationErr *introspect.CommunicationError
	switch {
	case errors.Is(err, context.Canceled):
		//timeout
		return response.NewErrorResponse(http.StatusGatewayTimeout, "authentication timeout")
	case errors.As(err, &tokenErr):
		//token issue
		return p.UnauthorizedError("token expired")
	case errors.As(err, &communicationErr):
		//communication issue
		return response.NewErrorResponse(http.StatusBadGateway, "authentication failed")
	}
	// internal issue
	return response.NewErrorResponse(http.StatusInternalServerError, response.InternalServerError)
}

func (p *AuthNPlugin) UnauthorizedError(msg string) error {
	if p.UnauthorizedErrorMessage != "" {
		msg = p.UnauthorizedErrorMessage
	}
	return response.NewErrorResponse(http.StatusUnauthorized, msg)
}

type clientAuthenticator interface {
	Authenticate(consumer *kongentities.Consumer, credential *kongclient.AuthenticatedCredential) error
}

type requestHeaderSetter interface {
	SetHeaders(headers map[string][]string) error
	ClearHeader(name string) error
}

func (p *AuthNPlugin) introspect(ctx context.Context, token string) (*introspect.IntrospectResult, error) {
	result, err := p.introspector.Introspect(ctx, token)
	if err != nil {
		return nil, err
	}
	if !p.isActive(result) {
		return nil, introspect.NewInvalidToken(errors.New("token inactive or expired"))
	}

	return result, nil
}

func (p *AuthNPlugin) setAuthenticated(kongAuth clientAuthenticator, kongRequest requestHeaderSetter, token string, result *introspect.IntrospectResult) error {
	headers := map[string][]string{}
	if p.UpstreamSettings.AuthTokenHeader != "" {
		headers[p.UpstreamSettings.AuthTokenHeader] = []string{token}
	}
	if p.UpstreamSettings.AuthTokenKindHeader != "" {
		headers[p.UpstreamSettings.AuthTokenKindHeader] = []string{result.Kind}
	}
	if p.UpstreamSettings.ClientIdHeader != "" {
		headers[p.UpstreamSettings.ClientIdHeader] = []string{result.ClientID}
	}
	var credential_id string
	switch result.Kind {
	case introspect.EntraKind:
		credential_id = result.OID
		if p.UpstreamSettings.EntraOidHeader != "" {
			headers[p.UpstreamSettings.EntraOidHeader] = []string{result.OID}
		}
	case introspect.PingKind, introspect.STSKind, introspect.HeimdallKind:
		credential_id = result.UUID
		if p.UpstreamSettings.UUIDHeader != "" {
			headers[p.UpstreamSettings.UUIDHeader] = []string{result.UUID}
		}
	default:
		//we control which token kind is set in IntrospectResult, so reaching here is a bug
		return fmt.Errorf("unknown token kind %s", result.Kind)
	}
	if err := kongRequest.SetHeaders(headers); err != nil {
		return err
	}
	if !p.KeepAuthHeader {
		if err := kongRequest.ClearHeader(introspect.AuthorizationHeaderName); err != nil {
			return err
		}
	}
	return kongAuth.Authenticate(nil, &kongclient.AuthenticatedCredential{Id: credential_id})
}

func (p *AuthNPlugin) isActive(result *introspect.IntrospectResult) bool {
	if result == nil || !result.Active {
		return false
	}
	if result.Expiration < time.Now().Unix() {
		return false
	}
	return true
}

type requestHeaderGetter interface {
	GetHeader(header string) (string, error)
}

func (p *AuthNPlugin) getToken(kongRequest requestHeaderGetter) (string, error) {
	if p.AuthorizationHeaderName != "" {
		token, err := p.getTokenFromHeader(kongRequest)
		if err == nil {
			return token, nil
		}
		//if there is an error and no cookie is configured, return the error
		if p.AuthorizationCookieName == "" {
			return token, err
		}
	}
	if p.AuthorizationCookieName != "" {
		return p.getTokenFromCookie(kongRequest)
	}
	return "", errors.New("no access token location configured")
}

func (p *AuthNPlugin) getTokenFromHeader(kongRequest requestHeaderGetter) (string, error) {
	authHeader, err := kongRequest.GetHeader(p.AuthorizationHeaderName)
	if err != nil {
		return "", fmt.Errorf("error reading '%s' header: %w", p.AuthorizationHeaderName, err)
	}
	if !strings.HasPrefix(authHeader, introspect.BearerTokenPrefix) {
		return "", errors.New("non-Bearer header value")
	}
	return strings.TrimPrefix(authHeader, introspect.BearerTokenPrefix), nil
}

func (p *AuthNPlugin) getTokenFromCookie(kongRequest requestHeaderGetter) (string, error) {
	cookie, err := kongRequest.GetHeader("Cookie")
	if err != nil {
		return "", fmt.Errorf("error reading cookie: %w", err)
	}
	header := http.Header{}
	header.Add("Cookie", cookie)
	req := http.Request{Header: header}
	req.Cookies()
	for _, c := range req.Cookies() {
		if c.Name == p.AuthorizationCookieName {
			return c.Value, nil
		}
	}
	return "", errors.New("no token cookie found")

}

func (p *AuthNPlugin) reportAuthError(ctx context.Context, kong *pdk.PDK, err error) {
	h := http.Header{}
	h.Set("WWW-Authenticate", "Bearer error=\"invalid_token\", error_description=\"The access token is invalid or has expired\"")
	response.KongExit(ctx, kong, err, h)
}
