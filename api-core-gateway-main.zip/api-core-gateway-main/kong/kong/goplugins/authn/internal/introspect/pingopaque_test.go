package introspect

import (
	"bytes"
	"common/cache/base"
	"common/log"
	"context"
	"fmt"
	"io"
	"net/http"
	"net/url"
	"reflect"
	"testing"

	"github.com/stretchr/testify/assert"
)

func urlMustParse(uStr string) *url.URL {
	u, err := url.Parse(uStr)
	if err != nil {
		panic(err)
	}
	return u
}

func Test_createPingIntrospectRequest(t *testing.T) {
	type args struct {
		ctx          context.Context
		uri          string
		token        string
		clientID     string
		clientSecret string
	}
	tests := []struct {
		name    string
		args    args
		headers http.Header
		url     *url.URL
		body    string
		errMsg  string
	}{
		{
			"ok",
			args{
				context.Background(),
				"http://example.com/test",
				"myToken",
				"myId",
				"mySecret",
			},
			http.Header{
				"Content-Type":  {"application/x-www-form-urlencoded"},
				"Accept":        {"application/json"},
				"Authorization": {"Basic bXlJZDpteVNlY3JldA=="},
			},
			urlMustParse("http://example.com/test"),
			"token=myToken",
			"",
		},
		{
			"bad url",
			args{
				context.Background(),
				"://example.com/test",
				"myToken",
				"myId",
				"mySecret",
			},
			http.Header{},
			nil,
			"",
			"creating introspect request: parse \"://example.com/test\": missing protocol scheme",
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			pi := &PingOpaqueIntrospector{}
			got, err := pi.createIntrospectRequest(tt.args.ctx, tt.args.uri, tt.args.token, tt.args.clientID, tt.args.clientSecret)
			if err != nil || tt.errMsg != "" {
				assert.EqualError(t, err, tt.errMsg)
				return
			}
			assert.NoError(t, err)
			assert.Equal(t, http.MethodPost, got.Method)
			assert.Equal(t, tt.headers, got.Header)
			assert.Equal(t, tt.url, got.URL)
			bt, err := io.ReadAll(got.Body)
			assert.NoError(t, err)
			assert.Equal(t, tt.body, string(bt))
		})
	}
}

func Test_getPingRequestContent(t *testing.T) {
	tests := []struct {
		name string
		req  *http.Request
		want string
	}{
		{
			"ok",
			&http.Request{
				URL:              urlMustParse("http://example.com/test"),
				Body:             io.NopCloser(bytes.NewBuffer([]byte("token=mytoken"))),
				Header:           http.Header{"Authorization": {"Basic bXlJZDpteVNlY3JldA=="}, "Content-length": {"20"}},
				TransferEncoding: []string{"identity"},
			},
			"GET /test HTTP/1.1\r\nHost: example.com\r\nUser-Agent: Go-http-client/1.1\r\nAuthorization: Basic KnJlZGFjdGVkKjoqcmVkYWN0ZWQq\r\nContent-length: 20\r\n\r\ntoken=%2Aredacted%2A",
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {

			pi := &PingOpaqueIntrospector{}
			got := pi.getRequestContent(tt.req)
			assert.Equal(t, tt.want, got)
		})
	}
}

func Test_parsePingResponse(t *testing.T) {
	tests := []struct {
		name     string
		pingResp *http.Response
		want     *PingIntrospectResponse
		errMsg   string
	}{
		{
			"ok",
			&http.Response{
				Header: http.Header{"Content-Type": {"application/json"}},
				Body:   io.NopCloser(bytes.NewBuffer([]byte(`{"active":true}`))),
			},
			&PingIntrospectResponse{Active: true},
			"",
		},
		{
			"bad content-type",
			&http.Response{
				Header: http.Header{"Content-Type": {"plain/text"}},
				Body:   io.NopCloser(bytes.NewBuffer([]byte(`text`))),
			},
			nil,
			"decoding introspect response: unexpected content-type 'plain/text', expected 'application/json', response: HTTP/0.0 000 status code 0\r\nContent-Type: plain/text\r\n\r\ntext",
		},
		{
			"no content-type",
			&http.Response{
				Header: http.Header{},
				Body:   io.NopCloser(bytes.NewBuffer([]byte(`text`))),
			},
			nil,
			"decoding introspect response: failed to parse response media type: mime: no media type",
		},
		{
			"bad json",
			&http.Response{
				Header: http.Header{"Content-Type": {"application/json"}},
				Body:   io.NopCloser(bytes.NewBuffer([]byte(`{"active":123}`))),
			},
			nil,
			"decoding introspect response: json: cannot unmarshal number into Go struct field PingIntrospectResponse.active of type bool",
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			pi := &PingOpaqueIntrospector{}
			got, err := pi.parseResponse(tt.pingResp)
			if err != nil || tt.errMsg != "" {
				assert.EqualError(t, err, tt.errMsg)
				return
			}
			assert.NoError(t, err)
			assert.Equal(t, tt.want, got)
		})
	}
}
func Test_makeIntrospectRequest(t *testing.T) {
	tests := []struct {
		name    string
		client  httpClient
		pingReq *http.Request
		want    *PingIntrospectResponse
		errMsg  string
	}{
		{
			"ok",
			&mockHttpClient{
				resp: &http.Response{
					StatusCode: http.StatusOK,
					Header:     http.Header{"Content-Type": {"application/json"}},
					Body:       io.NopCloser(bytes.NewBuffer([]byte(`{"active":true}`))),
				},
			},
			&http.Request{
				Method: http.MethodPost,
				URL:    urlMustParse("http://example.com/test"),
				Body:   io.NopCloser(bytes.NewBuffer([]byte("token=myToken"))),
			},
			&PingIntrospectResponse{Active: true, PingOpaqueIntrospectError: PingOpaqueIntrospectError{StatusCode: http.StatusOK}},
			"",
		},
		{
			"client error",
			&mockHttpClient{
				err: fmt.Errorf("client error"),
			},
			&http.Request{
				Method: http.MethodPost,
				URL:    urlMustParse("http://example.com/test"),
				Body:   io.NopCloser(bytes.NewBuffer([]byte("token=myToken"))),
			},
			nil,
			"sending introspect request: client error",
		},
		{
			"parse response error",
			&mockHttpClient{
				resp: &http.Response{
					StatusCode: http.StatusOK,
					Header:     http.Header{"Content-Type": {"application/json"}},
					Body:       io.NopCloser(bytes.NewBuffer([]byte(`{"active":123}`))),
				},
			},
			&http.Request{
				Method: http.MethodPost,
				URL:    urlMustParse("http://example.com/test"),
				Body:   io.NopCloser(bytes.NewBuffer([]byte("token=myToken"))),
				Header: http.Header{},
			},
			nil,
			"cannot unmarshal",
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			pi := &PingOpaqueIntrospector{}
			got, err := pi.makeIntrospectRequest(tt.client, tt.pingReq)
			if err != nil || tt.errMsg != "" {
				assert.ErrorContains(t, err, tt.errMsg)
				return
			}
			assert.NoError(t, err)
			assert.Equal(t, tt.want, got)
		})
	}
}

func Test_Introspect(t *testing.T) {
	tests := []struct {
		name    string
		client  httpClient
		cache   base.Cache
		cfg     PingOpaqueConfig
		token   string
		want    *IntrospectResult
		errMsg  string
		errType reflect.Type
	}{
		{
			"ok from cache",
			nil,
			&mockCache{
				data: map[string][]byte{"ping_token\x00myToken": []byte(`{"statusCode":200,"uuid":"uuid","active":true}`)},
			},
			PingOpaqueConfig{CacheEnabled: true},
			"myToken",
			&IntrospectResult{
				StatusCode: http.StatusOK,
				UUID:       "uuid",
				Active:     true,
			},
			"",
			nil,
		},
		{
			"ok from introspect",
			&mockHttpClient{
				resp: &http.Response{
					StatusCode: http.StatusOK,
					Header:     http.Header{"Content-Type": {"application/json"}},
					Body:       io.NopCloser(bytes.NewBuffer([]byte(`{"active":true,"uuid":"uuid"}`))),
				},
			},
			&mockCache{},
			PingOpaqueConfig{
				IntrospectURI:          "http://example.com/test",
				IntrospectClientID:     "myId",
				IntrospectClientSecret: "mySecret",
				CacheEnabled:           true,
				IntrospectCacheTTL:     60,
			},
			"myToken",
			&IntrospectResult{
				StatusCode: http.StatusOK,
				UUID:       "uuid",
				Active:     true,
				Kind:       PingKind,
			},
			"",
			nil,
		},
		{
			"client error",
			&mockHttpClient{
				err: fmt.Errorf("client error"),
			},
			&mockCache{},
			PingOpaqueConfig{
				IntrospectURI:          "http://example.com/test",
				IntrospectClientID:     "myId",
				IntrospectClientSecret: "mySecret",
			},
			"myToken",
			nil,
			"client error",
			reflect.TypeOf(&CommunicationError{}),
		},
		{
			"bad status code",
			&mockHttpClient{
				resp: &http.Response{
					StatusCode: http.StatusBadRequest,
					Header:     http.Header{"Content-Type": {"application/json"}},
					Body:       io.NopCloser(bytes.NewBuffer([]byte(`{"error":"invalid_request"}`))),
				},
			},
			&mockCache{},
			PingOpaqueConfig{
				IntrospectURI:          "http://example.com/test",
				IntrospectClientID:     "myId",
				IntrospectClientSecret: "mySecret",
			},
			"myToken",
			nil,
			"request failed: Status code: 400. Error: invalid_request, ErrorDescription: ",
			reflect.TypeOf(&CommunicationError{}),
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			pi := &PingOpaqueIntrospector{
				client: tt.client,
				cfg:    tt.cfg,
				cache:  tt.cache,
			}
			ctx := log.NewContext(context.Background(), log.NewSimpleLogger())
			got, err := pi.Introspect(ctx, tt.token)
			if err != nil || tt.errMsg != "" {
				assert.ErrorContains(t, err, tt.errMsg)
				assert.Equal(t, tt.errType, reflect.TypeOf(err))
				return
			}
			assert.NoError(t, err)
			assert.Equal(t, tt.want, got)
		})
	}
}

func TestNewPingOpaqueIntrospector(t *testing.T) {
	tests := []struct {
		name   string
		client *http.Client
		cfg    PingOpaqueConfig
		cache  base.Cache
		want   *PingOpaqueIntrospector
	}{
		{
			"ok",
			&http.Client{},
			PingOpaqueConfig{
				IntrospectURI:          "http://example.com/test",
				IntrospectClientID:     "myId",
				IntrospectClientSecret: "mySecret",
				IntrospectCacheTTL:     60,
				CacheEnabled:           true,
			},
			&mockCache{},
			&PingOpaqueIntrospector{
				client: &http.Client{},
				cfg: PingOpaqueConfig{
					IntrospectURI:          "http://example.com/test",
					IntrospectClientID:     "myId",
					IntrospectClientSecret: "mySecret",
					IntrospectCacheTTL:     60,
					CacheEnabled:           true,
				},
				cache: &mockCache{},
			},
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			got := NewPingOpaqueIntrospector(tt.client, tt.cfg, tt.cache)
			assert.Equal(t, tt.want, got)
		})
	}
}

type mockCache struct {
	data map[string][]byte
}

func (m *mockCache) Get(ctx context.Context, key string) ([]byte, error) {
	if m.data != nil {
		if val, ok := m.data[key]; ok {
			return val, nil
		}
	}
	return nil, fmt.Errorf("cache miss")
}

func (m *mockCache) Set(ctx context.Context, key string, value []byte, ttl int) error {
	if m.data != nil {
		m.data[key] = value
	}
	return nil
}

type mockHttpClient struct {
	resp *http.Response
	err  error
}

func (m *mockHttpClient) Do(req *http.Request) (*http.Response, error) {
	return m.resp, m.err
}
