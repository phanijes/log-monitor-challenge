package introspect

import (
	"common/cache"
	"common/cache/base"
	"context"
	"encoding/json"
	"fmt"
	"io"
	"mime"
	"net/http"
	"net/url"
	"strings"
)

type PingOpaqueIntrospectError struct {
	StatusCode       int    `json:"-"`
	Err              string `json:"error"`
	ErrorDescription string `json:"error_description"`
}

func (e PingOpaqueIntrospectError) Error() string {
	return fmt.Sprintf("Status code: %d. Error: %s, ErrorDescription: %s", e.StatusCode, e.Err, e.ErrorDescription)
}

type PingIntrospectResponse struct {
	Entitlements pingSlice `json:"entitlements"`
	Active       bool      `json:"active"`
	TokenType    string    `json:"token_type"`
	Exp          int64     `json:"exp"`
	UUID         string    `json:"uuid"`
	ClientID     string    `json:"client_id"`
	PingOpaqueIntrospectError
}

// PingOpaqueIntrospector is used for introspecting Ping Reference Tokens
type PingOpaqueIntrospector struct {
	client httpClient
	cfg    PingOpaqueConfig
	cache  base.Cache
}

type PingOpaqueConfig struct {
	IntrospectURI          string
	IntrospectClientID     string
	IntrospectClientSecret string // Ping reference/opaque token introspection
	IntrospectCacheTTL     int
	CacheEnabled           bool
}

func NewPingOpaqueIntrospector(client *http.Client, cfg PingOpaqueConfig, cache base.Cache) *PingOpaqueIntrospector {
	return &PingOpaqueIntrospector{client: client, cfg: cfg, cache: cache}
}

// Introspect makes request to PING to introspect reference or opaque token. Request can be cached
func (pi *PingOpaqueIntrospector) Introspect(ctx context.Context, token string) (*IntrospectResult, error) {
	//trying to get introspect result from cache
	cacheKey := buildCacheKey("ping_token", token)
	if pi.cfg.CacheEnabled {
		if result := cache.GetFromCache[IntrospectResult](ctx, pi.cache, cacheKey); result != nil {
			return result, nil
		}
	}
	//create ping introspect request
	pingReq, err := pi.createIntrospectRequest(ctx, pi.cfg.IntrospectURI, token, pi.cfg.IntrospectClientID, pi.cfg.IntrospectClientSecret)
	if err != nil {
		return nil, err
	}

	//make ping introspect request
	resp, err := pi.makeIntrospectRequest(pi.client, pingReq)
	if err != nil {
		return nil, NewCommunicationError(err)
	}

	//verifying status code
	if resp.StatusCode != http.StatusOK {
		return nil, NewCommunicationError(fmt.Errorf("request failed: %w", resp.PingOpaqueIntrospectError))
	}

	result := &IntrospectResult{
		StatusCode:   resp.StatusCode,
		UUID:         resp.UUID,
		Entitlements: []string(resp.Entitlements),
		ClientID:     resp.ClientID,
		Expiration:   resp.Exp,
		Active:       resp.Active,
		Kind:         PingKind,
	}

	if pi.cfg.CacheEnabled && result.Active {
		cache.UpdateInCache(ctx, pi.cache, cacheKey, result, pi.cfg.IntrospectCacheTTL)
	}
	return result, nil
}

type httpClient interface {
	Do(*http.Request) (*http.Response, error)
}

func (pi *PingOpaqueIntrospector) makeIntrospectRequest(
	client httpClient,
	pingReq *http.Request,
) (*PingIntrospectResponse, error) {
	pingResp, err := client.Do(pingReq)
	if err != nil {
		return nil, fmt.Errorf("sending introspect request: %w", err)
	}
	defer pingResp.Body.Close()

	resp, err := pi.parseResponse(pingResp)
	if err != nil {
		return nil, fmt.Errorf("introspect error, request: %s, message: %w", pi.getRequestContent(pingReq), err)
	}

	return resp, nil
}

const placeholderValue = "*redacted*"

// getPingRequestContent returns string representation of request
// and replaces credentials with placeholders
func (pi *PingOpaqueIntrospector) getRequestContent(pingReq *http.Request) string {
	reqCopy := pingReq.Clone(context.Background())

	reqCopy.SetBasicAuth(placeholderValue, placeholderValue)
	reqCopy.Body = io.NopCloser(
		strings.NewReader(url.Values{"token": []string{placeholderValue}}.Encode()))

	var buf strings.Builder

	_ = reqCopy.Write(&buf)

	return buf.String()
}

func (pi *PingOpaqueIntrospector) parseResponse(pingResp *http.Response) (*PingIntrospectResponse, error) {
	mediaType, _, mtErr := mime.ParseMediaType(pingResp.Header.Get(ContentTypeHeaderName))

	var (
		introspectResp PingIntrospectResponse
		err            error
	)

	switch mediaType {
	case ContentTypeJson:
		//try to unmarshal on any status code as the json response from Ping might contain error details
		err = json.NewDecoder(pingResp.Body).Decode(&introspectResp)
	case "":
		err = fmt.Errorf("failed to parse response media type: %w", mtErr)
	default:
		var sb strings.Builder

		wErr := pingResp.Write(&sb)

		err = fmt.Errorf("unexpected content-type '%s', expected '%s', response: %s",
			mediaType, ContentTypeJson, sb.String())

		if wErr != nil {
			err = fmt.Errorf("%s: reading body: %w", err, wErr)
		}
	}

	//response is invalid (non-json or bad json)
	if err != nil {
		return nil, fmt.Errorf("decoding introspect response: %w", err)
	}

	introspectResp.StatusCode = pingResp.StatusCode
	return &introspectResp, nil
}

func (pi *PingOpaqueIntrospector) createIntrospectRequest(
	ctx context.Context,
	uri, token, clientID, clientSecret string,
) (*http.Request, error) {
	reqData := url.Values{"token": []string{token}}

	pingReq, err := http.NewRequestWithContext(
		ctx, http.MethodPost, uri, strings.NewReader(reqData.Encode()))
	if err != nil {
		return nil, fmt.Errorf("creating introspect request: %w", err)
	}

	pingReq.Header.Set(ContentTypeHeaderName, contentTypeFormEncode)
	pingReq.Header.Set(acceptHeaderName, ContentTypeJson)
	if clientID != "" && clientSecret != "" {
		pingReq.SetBasicAuth(clientID, clientSecret)
	}

	return pingReq, nil
}
