package introspect

import (
	"context"
	"fmt"

	oidc "github.com/coreos/go-oidc/v3/oidc"
)

type entraClaims struct {
	OID string `json:"oid"`
}

// EntraIntrospector is the struct which is used for validating Entra JWT token
type EntraIntrospector struct {
	provider OIDCProvider
	verifier OIDCTokenVerifier
	audience map[string]struct{}
}

func NewEntraIntrospector(ctx context.Context, issuerURL string, audience map[string]struct{}, config *oidc.Config) (*EntraIntrospector, error) {
	prov, err := oidc.NewProvider(oidc.ClientContext(ctx, client), issuerURL)
	if err != nil {
		return nil, err
	}
	return &EntraIntrospector{provider: prov, verifier: prov.Verifier(config), audience: audience}, nil
}

// Introspect is used for validating a Entra JWT token
func (ei EntraIntrospector) Introspect(ctx context.Context, token string) (*IntrospectResult, error) {
	return doIntrospect(ctx, ei.verifier, ei.validateClaims, token)
}

func (ei EntraIntrospector) validateClaims(c entraClaims, idToken *oidc.IDToken) (*IntrospectResult, error) {
	var audience string
	for _, v := range idToken.Audience {
		if _, ok := ei.audience[v]; ok {
			audience = v
			break
		}
	}
	if audience == "" {
		return nil, NewInvalidToken(fmt.Errorf("unexpected audience: %v", idToken.Audience))
	}

	return &IntrospectResult{
		StatusCode: 200,
		Audience:   audience,
		Subject:    idToken.Subject,
		OID:        c.OID,
		Expiration: idToken.Expiry.Unix(),
		Active:     true,
		Kind:       EntraKind,
	}, nil
}
