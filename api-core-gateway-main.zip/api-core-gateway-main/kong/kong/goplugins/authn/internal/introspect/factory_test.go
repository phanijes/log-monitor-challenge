package introspect

import (
	"fmt"
	"net/http"
	"net/http/httptest"
	"testing"

	"github.com/stretchr/testify/assert"
)

var wellKnown = `{
  "issuer": "%s",
  "authorization_endpoint": "https://login.dev.ciam.refinitiv.com/as/authorization.oauth2",
  "token_endpoint": "https://login.dev.ciam.refinitiv.com/as/token.oauth2",
  "revocation_endpoint": "https://login.dev.ciam.refinitiv.com/as/revoke_token.oauth2",
  "userinfo_endpoint": "https://login.dev.ciam.refinitiv.com/idp/userinfo.openid",
  "introspection_endpoint": "https://login.dev.ciam.refinitiv.com/as/introspect.oauth2",
  "jwks_uri": "https://login.dev.ciam.refinitiv.com/pf/JWKS",
  "registration_endpoint": "https://login.dev.ciam.refinitiv.com/as/clients.oauth2",
  "ping_revoked_sris_endpoint": "https://login.dev.ciam.refinitiv.com/pf-ws/rest/sessionMgmt/revokedSris",
  "ping_end_session_endpoint": "https://login.dev.ciam.refinitiv.com/idp/startSLO.ping",
  "device_authorization_endpoint": "https://login.dev.ciam.refinitiv.com/as/device_authz.oauth2",
  "scopes_supported": [ "ciam.rsm.application.readonly", "ciam.rsm.resource.readonly", "ciam.rsm.resource-session", "ciam.rsm.resource-session.readonly", "trapi.platform.rsm.session", "ciam.rsm.definition", "rsmapi1", "trapi.platform.rsm.resource", "trapi.platform.rsm.policy", "ciam.rsm.policy.readonly", "email", "rsmapi", "ciam.rsm.policy", "address", "ciam.rsm.definition.readonly", "openid", "profile", "ciam.rsm.application", "trapi.platform.rsm.application", "phone", "rsm:resource", "trapi.platform.rsm.definition", "ciam.rsm.resource" ],
  "claims_supported": [ "email", "family_name", "given_name", "home_site", "name", "pi.sri", "preferred_username", "private_line", "sid", "sub" ],
  "response_types_supported": [ "code", "token", "id_token", "code token", "code id_token", "token id_token", "code token id_token" ],
  "response_modes_supported": [ "fragment", "fragment.jwt", "query", "query.jwt", "form_post", "form_post.jwt", "jwt" ],
  "grant_types_supported": [ "implicit", "authorization_code", "refresh_token", "password", "client_credentials", "urn:pingidentity.com:oauth2:grant_type:validate_bearer", "urn:ietf:params:oauth:grant-type:jwt-bearer", "urn:ietf:params:oauth:grant-type:saml2-bearer", "urn:ietf:params:oauth:grant-type:device_code", "urn:ietf:params:oauth:grant-type:token-exchange", "urn:openid:params:grant-type:ciba" ],
  "subject_types_supported": [ "public", "pairwise" ],
  "id_token_signing_alg_values_supported": [ "none", "HS256", "HS384", "HS512", "RS256", "RS384", "RS512", "ES256", "ES384", "ES512", "PS256", "PS384", "PS512" ],
  "token_endpoint_auth_methods_supported": [ "client_secret_basic", "client_secret_post", "client_secret_jwt", "private_key_jwt", "tls_client_auth" ],
  "token_endpoint_auth_signing_alg_values_supported":  [ "RS256", "RS384", "RS512", "ES256", "ES384", "ES512", "PS256", "PS384", "PS512", "HS256", "HS384", "HS512" ],
  "claim_types_supported": [ "normal" ],
  "claims_parameter_supported": false,
  "request_parameter_supported": true,
  "request_uri_parameter_supported": false,
  "request_object_signing_alg_values_supported": [ "RS256", "RS384", "RS512", "ES256", "ES384", "ES512", "PS256", "PS384", "PS512" ],
  "id_token_encryption_alg_values_supported": [ "dir", "A128KW", "A192KW", "A256KW", "A128GCMKW", "A192GCMKW", "A256GCMKW", "ECDH-ES", "ECDH-ES+A128KW", "ECDH-ES+A192KW", "ECDH-ES+A256KW", "RSA-OAEP", "RSA-OAEP-256" ],
  "id_token_encryption_enc_values_supported": [ "A128CBC-HS256", "A192CBC-HS384", "A256CBC-HS512", "A128GCM", "A192GCM", "A256GCM" ]
}`

func TestFactory_New(t *testing.T) {
	tests := []struct {
		name         string
		cfgGen       func(mockUrl string) FactoryCfg
		introspector TokenIntrospector
		noIssuer     bool
		errMsg       string
	}{
		{
			name: "PingJWTIntrospector",
			cfgGen: func(mockUrl string) FactoryCfg {
				return FactoryCfg{
					PingIssuer:      mockUrl,
					HeimdallIssuer:  "http://heimdall.example.com",
					HeimdallJWKSURL: "http://heimdall.example.com/jwks",
					EntraPrefix:     "prefix",
					EntraIssuers:    []string{"http://entra.example.com/issuer1", "http://entra.example.com/issuer2"},
					EntraAudience:   []string{"aud1", "aud2"},
				}
			},
			introspector: &PingJWTIntrospector{},
			errMsg:       "",
		},
		{
			name: "HeimdallTokenIntrospector",
			cfgGen: func(mockUrl string) FactoryCfg {
				return FactoryCfg{
					PingIssuer:      "http://ping.example.com",
					HeimdallIssuer:  mockUrl,
					HeimdallJWKSURL: mockUrl + "/jwks",
					EntraPrefix:     "prefix",
					EntraIssuers:    []string{"http://entra.example.com/issuer1", "http://entra.example.com/issuer2"},
					EntraAudience:   []string{"aud1", "aud2"},
				}
			},
			introspector: &HeimdallTokenIntrospector{},
			errMsg:       "",
		},
		{
			name: "EntraIntrospector by issuer",
			cfgGen: func(mockUrl string) FactoryCfg {
				return FactoryCfg{
					PingIssuer:      "http://ping.example.com",
					HeimdallIssuer:  "http://heimdall.example.com",
					HeimdallJWKSURL: "http://heimdall.example.com/jwks",
					EntraPrefix:     "",
					EntraIssuers:    []string{mockUrl, "http://entra.example.com/issuer2"},
					EntraAudience:   []string{"aud1", "aud2"},
				}
			},
			introspector: &EntraIntrospector{},
			errMsg:       "",
		},
		{
			name: "EntraIntrospector by prefix",
			cfgGen: func(mockUrl string) FactoryCfg {
				return FactoryCfg{
					PingIssuer:      "http://ping.example.com",
					HeimdallIssuer:  "http://heimdall.example.com",
					HeimdallJWKSURL: "http://heimdall.example.com/jwks",
					EntraPrefix:     mockUrl,
					EntraIssuers:    []string{},
					EntraAudience:   []string{"aud1", "aud2"},
				}
			},
			introspector: &EntraIntrospector{},
			errMsg:       "",
		},
		{
			name: "UnknownIssuer",
			cfgGen: func(mockUrl string) FactoryCfg {
				return FactoryCfg{
					PingIssuer:      "http://ping.example.com",
					HeimdallIssuer:  "http://heimdall.example.com",
					HeimdallJWKSURL: "http://heimdall.example.com/jwks",
					EntraPrefix:     "prefix",
					EntraIssuers:    []string{"http://entra.example.com/issuer2"},
					EntraAudience:   []string{"aud1", "aud2"},
				}
			},
			errMsg: "unknown issuer",
		},
		{
			name: "EmptyIssuer",
			cfgGen: func(mockUrl string) FactoryCfg {
				return FactoryCfg{
					PingIssuer:      "http://ping.example.com",
					HeimdallIssuer:  "http://heimdall.example.com",
					HeimdallJWKSURL: "http://heimdall.example.com/jwks",
					EntraPrefix:     "prefix",
					EntraIssuers:    []string{"http://entra.example.com/issuer2"},
					EntraAudience:   []string{"aud1", "aud2"},
				}
			},
			noIssuer: true,
			errMsg:   "issuer is empty",
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			mockserver := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
				w.Header().Add("Content-Type", "application/json")
				w.Write([]byte(fmt.Sprintf(wellKnown, "http://"+r.Host)))
			}))
			defer mockserver.Close()
			factory := NewFactory(tt.cfgGen(mockserver.URL))
			u := mockserver.URL
			if tt.noIssuer {
				u = ""
			}
			inrospector, err := factory.New(u)
			if tt.errMsg != "" || err != nil {
				assert.ErrorContains(t, err, tt.errMsg)
				return
			}
			assert.NoError(t, err)
			assert.IsType(t, tt.introspector, inrospector)
		})
	}
}
