package introspect

import (
	"context"
	"encoding/json"
	"fmt"
	"net/http"
	"net/http/httptest"
	"testing"
	"time"

	oidc "github.com/coreos/go-oidc/v3/oidc"
	"github.com/stretchr/testify/assert"
)

func TestPingJWTIntrospector_validateClaims(t *testing.T) {
	type args struct {
		c     pingClaims
		token *oidc.IDToken
	}
	tests := []struct {
		name   string
		args   args
		want   *IntrospectResult
		errMsg string
	}{
		{
			"ok",
			args{
				pingClaims{Subject: "subj", UUID: "uuid1", Entitlements: pingSlice{"abc", "def"}, ClientID: "cli"},
				&oidc.IDToken{Expiry: time.Date(2000, time.January, 1, 1, 1, 1, 1, time.UTC)},
			},
			&IntrospectResult{
				Expiration:   time.Date(2000, time.January, 1, 1, 1, 1, 1, time.UTC).Unix(),
				StatusCode:   200,
				Subject:      "subj",
				UUID:         "uuid1",
				Entitlements: []string{"abc", "def"},
				ClientID:     "cli",
				Active:       true,
				Kind:         PingKind,
			},
			"",
		},
		{
			"no uuid",
			args{
				pingClaims{Subject: "subj", Entitlements: pingSlice{"abc", "def"}, ClientID: "cli"},
				&oidc.IDToken{Expiry: time.Date(2000, time.January, 1, 1, 1, 1, 1, time.UTC)},
			},
			nil,
			"token payload does not contain uuid",
		},
		{
			"no client id",
			args{
				pingClaims{Subject: "subj", UUID: "uuid1", Entitlements: pingSlice{"abc", "def"}},
				&oidc.IDToken{Expiry: time.Date(2000, time.January, 1, 1, 1, 1, 1, time.UTC)},
			},
			nil,
			"token payload does not contain client_id",
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			pi := PingJWTIntrospector{}
			got, err := pi.validateClaims(tt.args.c, tt.args.token)
			if err != nil || tt.errMsg != "" {
				assert.EqualError(t, err, tt.errMsg)
				return
			}
			assert.NoError(t, err)
			assert.Equal(t, tt.want, got)
		})
	}
}

func Test_pingSlice_UnmarshalJSON(t *testing.T) {
	tests := []struct {
		name   string
		text   string
		s      *pingSlice
		errMsg string
	}{
		{
			"ok slice",
			`["abc","def"]`,
			&pingSlice{"abc", "def"},
			"",
		},
		{
			"ok string",
			`"abc"`,
			&pingSlice{"abc"},
			"",
		},
		{
			"bad json",
			`[abc]`,
			&pingSlice{},
			"invalid character 'a' looking for beginning of value",
		},
		{
			"bad json 2",
			`{"abc":123}`,
			&pingSlice{},
			"json: cannot unmarshal object into Go value of type string",
		},
		{
			"bad json 3",
			`[123]`,
			&pingSlice{},
			"json: cannot unmarshal number into Go value of type string",
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			s := &pingSlice{}
			err := json.Unmarshal([]byte(tt.text), s)
			if err != nil || tt.errMsg != "" {
				assert.EqualError(t, err, tt.errMsg)
				return
			}
			assert.NoError(t, err)
			assert.Equal(t, tt.s, s)
		})
	}
}

func TestNewPingJWTIntrospector(t *testing.T) {
	tests := []struct {
		name        string
		validIssuer bool
		config      *oidc.Config
		errMsg      string
	}{
		{
			name:        "valid issuer URL",
			validIssuer: true,
			config:      &oidc.Config{ClientID: "client-id"},
			errMsg:      "",
		},
		{
			name:        "invalid issuer URL",
			validIssuer: false,
			config:      &oidc.Config{ClientID: "client-id"},
			errMsg:      `Get "badurl/.well-known/openid-configuration": unsupported protocol scheme ""`,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			mockserver := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
				w.Header().Add("Content-Type", "application/json")
				w.Write([]byte(fmt.Sprintf(wellKnown, "http://"+r.Host)))
			}))
			defer mockserver.Close()
			issuerUrl := "badurl"
			if tt.validIssuer {
				issuerUrl = mockserver.URL
			}
			got, err := NewPingJWTIntrospector(context.Background(), issuerUrl, tt.config)
			if tt.errMsg != "" || err != nil {
				assert.EqualError(t, err, tt.errMsg)
				return
			}
			assert.NoError(t, err)
			assert.NotNil(t, got)
			assert.NotNil(t, got.provider)
			assert.NotNil(t, got.verifier)
		})
	}
}

func TestPingJWTIntrospector_Introspect(t *testing.T) {
	tests := []struct {
		name   string
		token  string
		want   *IntrospectResult
		errMsg string
	}{
		{
			name:  "valid token",
			token: makeToken(`{"sub":"subj","uuid":"uuid","iat":1516239022,"exp":4102448461,"client_id":"cli"}`),
			want: &IntrospectResult{
				StatusCode: 200,
				Subject:    "subj",
				UUID:       "uuid",
				ClientID:   "cli",
				Expiration: time.Date(2100, time.January, 1, 1, 1, 1, 1, time.UTC).Unix(),
				Active:     true,
				Kind:       PingKind,
			},
			errMsg: "",
		},
		{
			name:   "invalid token",
			token:  "a.a.a",
			want:   nil,
			errMsg: "token validation: oidc: malformed jwt: oidc: malformed jwt payload: illegal base64 data at input byte 0",
		},
		{
			name:   "no client id",
			token:  makeToken("{}"),
			want:   nil,
			errMsg: "token claims validation: token payload does not contain client_id",
		},
		{
			name:   "no uuid",
			token:  makeToken(`{"client_id":"cli"}`),
			want:   nil,
			errMsg: "token claims validation: token payload does not contain uuid",
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			verifier := oidc.NewVerifier("", nil, &oidc.Config{SkipClientIDCheck: true, SkipIssuerCheck: true, InsecureSkipSignatureCheck: true, SkipExpiryCheck: true})
			pi := PingJWTIntrospector{
				verifier: verifier,
			}
			got, err := pi.Introspect(context.Background(), tt.token)
			if err != nil || tt.errMsg != "" {
				assert.EqualError(t, err, tt.errMsg)
				return
			}
			assert.NoError(t, err)
			assert.Equal(t, tt.want, got)
		})
	}
}
