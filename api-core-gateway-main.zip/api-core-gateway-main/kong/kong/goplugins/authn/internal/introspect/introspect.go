package introspect

import (
	"common/log"
	"context"
	"encoding/base64"
	"encoding/json"
	"errors"
	"strings"
)

type tokenIntrospector struct {
	pool       *Pool
	factory    *Factory
	pingOpaque TokenIntrospector
	sts        TokenIntrospector
	//looks like a hack. Any better way to do this?
	stsIssuers []string
}

func NewTokenIntrospector(pingOpaque, sts TokenIntrospector, stsIssuers []string, f *Factory) *tokenIntrospector {
	return &tokenIntrospector{pool: NewPool(), factory: f, pingOpaque: pingOpaque, sts: sts, stsIssuers: stsIssuers}
}

var nonJWTTokenError = InvalidToken{errors.New("non-JWT token")}

func (ti tokenIntrospector) Introspect(ctx context.Context, token string) (*IntrospectResult, error) {
	//try to parse jwt and get issuer.
	ok, issuer := ti.getIssuer(token)
	//on failure - introspect with PING (if enabled)
	if !ok {
		if ti.pingOpaque != nil {
			log.FromContext(ctx).Debug("non-JWT token. trying PING opaque introspection")
			return ti.pingOpaque.Introspect(ctx, token)
		}
		log.FromContext(ctx).Debug("failed to get issuer from token and PING disabled")
		return nil, nonJWTTokenError
	}
	log.FromContext(ctx).Debug("JWT token", "issuer", issuer)
	if sliceContains(issuer, ti.stsIssuers) {
		return ti.sts.Introspect(ctx, token)
	}

	//token is jwt - using jwt introspection
	introspector := ti.pool.Get(issuer)
	if introspector == nil {
		var err error
		introspector, err = ti.factory.New(issuer)
		if err != nil {
			log.FromContext(ctx).Debug("failed to get introspector", "err", err, "issuer", issuer)
			//reporting bad token even if misconfigured - we cannot know which issuers are really expected
			return nil, NewInvalidToken(err)
		}
		ti.pool.Add(issuer, introspector)
	}
	return introspector.Introspect(ctx, token)
}

func (ti tokenIntrospector) getIssuer(token string) (bool, string) {
	parts := strings.Split(token, ".")
	if len(parts) != 3 || parts[1] == "" {
		// not JWT
		return false, ""
	}
	data, err := base64.RawURLEncoding.DecodeString(parts[1])
	if err != nil {
		return false, ""
	}
	var claims struct {
		Iss string
	}
	err = json.Unmarshal(data, &claims)
	if err != nil || claims.Iss == "" {
		return false, ""
	}
	return true, claims.Iss
}

func sliceContains(val string, slice []string) bool {
	for _, v := range slice {
		if v == val {
			return true
		}
	}
	return false
}
