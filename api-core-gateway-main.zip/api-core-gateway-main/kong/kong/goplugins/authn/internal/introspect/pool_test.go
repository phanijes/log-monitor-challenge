package introspect

import (
	"context"
	"testing"

	"github.com/stretchr/testify/assert"
)

func TestNewPool(t *testing.T) {
	pool := NewPool()
	assert.NotNil(t, pool)
	assert.NotNil(t, pool.pool)
	assert.NotNil(t, pool.mt)
}

type mockEmptyIntrospector struct{}

func (m mockEmptyIntrospector) Introspect(context.Context, string) (*IntrospectResult, error) {
	return nil, nil
}

func TestPoolAddGet(t *testing.T) {
	pool := NewPool()
	pool.Add("test-issuer", &mockEmptyIntrospector{})
	tests := []struct {
		name         string
		issuer       string
		introspector TokenIntrospector
	}{
		{
			"existing",
			"test-issuer",
			&mockEmptyIntrospector{},
		},
		{
			"non-existing",
			"non-existing",
			nil,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			got := pool.Get(tt.issuer)
			assert.Equal(t, tt.introspector, got)
		})
	}
}
