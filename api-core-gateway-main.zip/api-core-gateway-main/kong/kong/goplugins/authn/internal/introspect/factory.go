package introspect

import (
	"context"
	"fmt"
	"strings"

	oidc "github.com/coreos/go-oidc/v3/oidc"
)

type Factory struct {
	pingIssuer      string
	heimdallIssuer  string
	heimdallJWKSURL string
	entraPrefix     string
	entraIssuers    map[string]struct{}
	entraAudience   map[string]struct{}
}

type FactoryCfg struct {
	PingIssuer      string
	HeimdallIssuer  string
	HeimdallJWKSURL string
	EntraPrefix     string
	EntraIssuers    []string
	EntraAudience   []string
}

func NewFactory(cfg FactoryCfg) *Factory {
	return &Factory{
		pingIssuer:      cfg.PingIssuer,
		heimdallIssuer:  cfg.HeimdallIssuer,
		heimdallJWKSURL: cfg.HeimdallJWKSURL,
		entraPrefix:     cfg.EntraPrefix,
		entraIssuers:    stringSliceToMap(cfg.EntraIssuers),
		entraAudience:   stringSliceToMap(cfg.EntraAudience),
	}
}

func (f *Factory) New(issuer string) (TokenIntrospector, error) {
	cfg := &oidc.Config{
		SkipClientIDCheck: true,
	}
	if issuer == "" {
		return nil, fmt.Errorf("issuer is empty")
	}
	//need detach/background context
	backgroundCtx := context.Background()
	if issuer == f.pingIssuer {
		return NewPingJWTIntrospector(backgroundCtx, f.pingIssuer, cfg)
	}
	if issuer == f.heimdallIssuer {
		return NewHeimdallTokenIntrospector(backgroundCtx, f.heimdallIssuer, f.heimdallJWKSURL, &oidc.Config{SkipClientIDCheck: true, SupportedSigningAlgs: []string{"RS256", "EdDSA"}})
	}
	if _, ok := f.entraIssuers[issuer]; ok || (len(f.entraIssuers) == 0 && f.entraPrefix != "" && strings.HasPrefix(issuer, f.entraPrefix)) {
		return NewEntraIntrospector(backgroundCtx, issuer, f.entraAudience, cfg)
	}
	return nil, fmt.Errorf("unknown issuer %s", issuer)
}

func stringSliceToMap(s []string) map[string]struct{} {
	m := make(map[string]struct{})
	for _, v := range s {
		m[v] = struct{}{}
	}
	return m
}
