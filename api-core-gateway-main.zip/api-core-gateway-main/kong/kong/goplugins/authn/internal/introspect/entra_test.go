package introspect

import (
	"context"
	"fmt"
	"net/http"
	"net/http/httptest"
	"testing"
	"time"

	oidc "github.com/coreos/go-oidc/v3/oidc"
	"github.com/stretchr/testify/assert"
)

func TestEntraIntrospector_validateClaims(t *testing.T) {
	type args struct {
		c     entraClaims
		token *oidc.IDToken
	}
	tests := []struct {
		name   string
		args   args
		want   *IntrospectResult
		errMsg string
	}{
		{
			"ok",
			args{
				entraClaims{OID: "oid"},
				&oidc.IDToken{Expiry: time.Date(2000, time.January, 1, 1, 1, 1, 1, time.UTC), Audience: []string{"http://good.com"}, Subject: "subj"},
			},
			&IntrospectResult{
				Expiration: time.Date(2000, time.January, 1, 1, 1, 1, 1, time.UTC).Unix(),
				StatusCode: 200,
				Audience:   "http://good.com",
				Subject:    "subj",
				OID:        "oid",
				Active:     true,
				Kind:       EntraKind,
			},
			"",
		},
		{
			"bad audience",
			args{
				entraClaims{OID: "oid"},
				&oidc.IDToken{Expiry: time.Date(2000, time.January, 1, 1, 1, 1, 1, time.UTC), Audience: []string{"http://bad.com"}},
			},
			nil,
			"unexpected audience: [http://bad.com]",
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			ei := EntraIntrospector{audience: map[string]struct{}{"http://example.com": {}, "http://good.com": {}, "http://other.com": {}}}
			got, err := ei.validateClaims(tt.args.c, tt.args.token)
			if err != nil || tt.errMsg != "" {
				assert.EqualError(t, err, tt.errMsg)
				return
			}
			assert.NoError(t, err)
			assert.Equal(t, tt.want, got)
		})
	}
}
func TestNewEntraIntrospector(t *testing.T) {
	tests := []struct {
		name        string
		validIssuer bool
		audience    map[string]struct{}
		config      *oidc.Config
		errMsg      string
	}{
		{
			name:        "valid issuer URL",
			validIssuer: true,
			audience:    map[string]struct{}{"http://example.com": {}},
			config:      &oidc.Config{ClientID: "client-id"},
			errMsg:      "",
		},
		{
			name:        "invalid issuer URL",
			validIssuer: false,
			audience:    map[string]struct{}{"http://example.com": {}},
			config:      &oidc.Config{ClientID: "client-id"},
			errMsg:      `Get "badurl/.well-known/openid-configuration": unsupported protocol scheme ""`,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			mockserver := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
				w.Header().Add("Content-Type", "application/json")
				w.Write([]byte(fmt.Sprintf(wellKnown, "http://"+r.Host)))
			}))
			defer mockserver.Close()
			issuerUrl := "badurl"
			if tt.validIssuer {
				issuerUrl = mockserver.URL
			}
			got, err := NewEntraIntrospector(context.Background(), issuerUrl, tt.audience, tt.config)
			if tt.errMsg != "" || err != nil {
				assert.EqualError(t, err, tt.errMsg)
				return
			}
			assert.NoError(t, err)
			assert.NotNil(t, got)
			assert.NotNil(t, got.provider)
			assert.NotNil(t, got.verifier)
			assert.Equal(t, tt.audience, got.audience)
		})
	}
}
func TestEntraIntrospector_Introspect(t *testing.T) {
	tests := []struct {
		name   string
		token  string
		want   *IntrospectResult
		errMsg string
	}{
		{
			name:  "valid token",
			token: makeToken(`{"sub":"subj","oid":"oid","iat":1516239022,"exp":4102448461,"aud":"http://good.com"}`),
			want: &IntrospectResult{
				StatusCode: 200,
				Audience:   "http://good.com",
				Subject:    "subj",
				OID:        "oid",
				Expiration: time.Date(2100, time.January, 1, 1, 1, 1, 1, time.UTC).Unix(),
				Active:     true,
				Kind:       EntraKind,
			},
			errMsg: "",
		},
		{
			name:   "invalid token",
			token:  "a.a.a",
			want:   nil,
			errMsg: "token validation: oidc: malformed jwt: oidc: malformed jwt payload: illegal base64 data at input byte 0",
		},
		{
			name:   "bad audience",
			token:  makeToken("{}"),
			want:   nil,
			errMsg: "token claims validation: unexpected audience: []",
		},
		{
			name:   "bad audience",
			token:  makeToken(`{"aud":"abc"}`),
			want:   nil,
			errMsg: "token claims validation: unexpected audience: [abc]",
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			verifier := oidc.NewVerifier("", nil, &oidc.Config{SkipClientIDCheck: true, SkipIssuerCheck: true, InsecureSkipSignatureCheck: true, SkipExpiryCheck: true})
			ei := EntraIntrospector{
				audience: map[string]struct{}{"http://example.com": {}, "http://good.com": {}, "http://other.com": {}},
				verifier: verifier,
			}
			got, err := ei.Introspect(context.Background(), tt.token)
			if err != nil || tt.errMsg != "" {
				assert.EqualError(t, err, tt.errMsg)
				return
			}
			assert.NoError(t, err)
			assert.Equal(t, tt.want, got)
		})
	}
}
