package introspect

import (
	"context"
	"fmt"
	"net/http"
	"strings"
	"time"

	oidc "github.com/coreos/go-oidc/v3/oidc"
)

const (
	EntraKind    = "entra"
	PingKind     = "ping"
	STSKind      = "sts"
	HeimdallKind = "heimdall"
)

const (
	AuthorizationHeaderName = "Authorization"
	BearerTokenPrefix       = "Bearer "
	ContentTypeJson         = "application/json"
	contentTypeFormEncode   = "application/x-www-form-urlencoded"
	ContentTypeHeaderName   = "Content-Type"
	acceptHeaderName        = "Accept"
)

type IntrospectResult struct {
	StatusCode   int
	Subject      string
	UUID         string
	OID          string
	Audience     string
	Entitlements []string
	Expiration   int64
	ClientID     string
	Active       bool
	Kind         string
}

var client = &http.Client{Timeout: 5 * time.Second}

type InvalidToken struct {
	error
}

func NewInvalidToken(err error) *InvalidToken {
	return &InvalidToken{err}
}

func (e *InvalidToken) Unwrap() error {
	return e.error
}

type OIDCTokenVerifier interface {
	Verify(ctx context.Context, rawIDToken string) (*oidc.IDToken, error)
}

type OIDCProvider interface {
	Verifier(config *oidc.Config) *oidc.IDTokenVerifier
}

type TokenIntrospector interface {
	Introspect(ctx context.Context, token string) (*IntrospectResult, error)
}

type CommunicationError struct {
	error
}

func NewCommunicationError(err error) *CommunicationError {
	return &CommunicationError{err}
}

func (e *CommunicationError) Unwrap() error {
	return e.error
}

const separator = "\x00"

func buildCacheKey(prefix, token string) string {
	var sb strings.Builder
	sb.WriteString(prefix)
	sb.WriteString(separator)
	sb.WriteString(token)
	return sb.String()
}

type claimValidatorFunc[T any] func(claims T, idToken *oidc.IDToken) (*IntrospectResult, error)

func doIntrospect[T any](ctx context.Context, verifier OIDCTokenVerifier, validatorFunc claimValidatorFunc[T], token string) (*IntrospectResult, error) {
	idToken, err := verifier.Verify(ctx, token)
	if err != nil {
		return nil, NewInvalidToken(fmt.Errorf("token validation: %w", err))
	}

	c := new(T)
	if err := idToken.Claims(c); err != nil {
		return nil, NewInvalidToken(fmt.Errorf("extracting claims: %w", err))
	}

	ir, err := validatorFunc(*c, idToken)
	if err != nil {
		return nil, NewInvalidToken(fmt.Errorf("token claims validation: %w", err))
	}

	return ir, nil
}
