package introspect

import (
	"context"
	"errors"
	"testing"
	"time"

	oidc "github.com/coreos/go-oidc/v3/oidc"
	"github.com/stretchr/testify/assert"
)

func TestHeimdallTokenIntrospector_ValidateClaims(t *testing.T) {
	tests := []struct {
		name    string
		claims  heimdallClaims
		idToken *oidc.IDToken
		want    *IntrospectResult
		wantErr error
	}{
		{
			name: "valid claims",
			claims: heimdallClaims{
				EntraId: "test-entra-id",
				Client:  "test-client",
			},
			idToken: &oidc.IDToken{
				Subject: "test-subject",
				Expiry:  time.Now().Add(time.Hour),
			},
			want: &IntrospectResult{
				StatusCode: 200,
				Subject:    "test-subject",
				OID:        "test-entra-id",
				UUID:       "test-subject",
				Expiration: time.Now().Add(time.Hour).Unix(),
				ClientID:   "test-client",
				Active:     true,
				Kind:       HeimdallKind,
			},
			wantErr: nil,
		},
		{
			name: "missing subject",
			claims: heimdallClaims{
				EntraId: "test-entra-id",
				Client:  "test-client",
			},
			idToken: &oidc.IDToken{
				Subject: "",
				Expiry:  time.Now().Add(time.Hour),
			},
			want:    nil,
			wantErr: errors.New("token payload does not contain uuid"),
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			hti := HeimdallTokenIntrospector{}
			got, err := hti.validateClaims(tt.claims, tt.idToken)
			if tt.wantErr != nil {
				assert.EqualError(t, err, tt.wantErr.Error())
			} else {
				assert.NoError(t, err)
				assert.Equal(t, tt.want, got)
			}
		})
	}
}

func TestHeimdallTokenIntrospector_Introspect(t *testing.T) {
	tests := []struct {
		name   string
		token  string
		want   *IntrospectResult
		errMsg string
	}{
		{
			name:  "valid token",
			token: makeToken(`{"sub":"subj","oid":"oid","iat":1516239022,"exp":4102448461}`),
			want: &IntrospectResult{
				StatusCode: 200,
				Subject:    "subj",
				UUID:       "subj",
				OID:        "oid",
				Expiration: time.Date(2100, time.January, 1, 1, 1, 1, 1, time.UTC).Unix(),
				Active:     true,
				Kind:       HeimdallKind,
			},
			errMsg: "",
		},
		{
			name:   "invalid token",
			token:  "a.a.a",
			want:   nil,
			errMsg: "token validation: oidc: malformed jwt: oidc: malformed jwt payload: illegal base64 data at input byte 0",
		},
		{
			name:   "no subject",
			token:  makeToken("{}"),
			want:   nil,
			errMsg: "token claims validation: token payload does not contain uuid",
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			verifier := oidc.NewVerifier("", nil, &oidc.Config{SkipClientIDCheck: true, SkipIssuerCheck: true, InsecureSkipSignatureCheck: true, SkipExpiryCheck: true})
			hti := HeimdallTokenIntrospector{
				verifier: verifier,
			}
			got, err := hti.Introspect(context.Background(), tt.token)
			if err != nil || tt.errMsg != "" {
				assert.EqualError(t, err, tt.errMsg)
				return
			}
			assert.NoError(t, err)
			assert.Equal(t, tt.want, got)
		})
	}
}
