package introspect

import (
	"context"
	"encoding/base64"
	"errors"
	"testing"

	oidc "github.com/coreos/go-oidc/v3/oidc"
	"github.com/stretchr/testify/assert"
)

type mockClaims struct {
	Custom int
}

func makeToken(payload string) string {
	return "a." + base64.RawURLEncoding.EncodeToString([]byte(payload)) + ".a"
}

func TestDoIntrospect(t *testing.T) {
	tests := []struct {
		name           string
		token          string
		validatorFunc  claimValidatorFunc[mockClaims]
		errMsg         string
		expectedResult *IntrospectResult
	}{
		{
			name:  "valid token",
			token: makeToken(`{"sub":"1234567890","name":"John Doe","iat":1516239022}`),
			validatorFunc: func(claims mockClaims, idToken *oidc.IDToken) (*IntrospectResult, error) {
				return &IntrospectResult{Subject: idToken.Subject}, nil
			},
			errMsg:         "",
			expectedResult: &IntrospectResult{Subject: "1234567890"},
		},
		{
			name:  "invalid token",
			token: "token",
			validatorFunc: func(claims mockClaims, idToken *oidc.IDToken) (*IntrospectResult, error) {
				return &IntrospectResult{}, nil
			},
			errMsg:         "token validation: oidc: malformed jwt: oidc: malformed jwt, expected 3 parts got 1",
			expectedResult: nil,
		},
		{
			name:  "claims extraction error",
			token: makeToken(`{"sub":"1234567890","name":"John Doe","iat":1516239022, "Custom": "abc"}`),
			validatorFunc: func(claims mockClaims, idToken *oidc.IDToken) (*IntrospectResult, error) {
				return &IntrospectResult{}, nil
			},
			errMsg:         "extracting claims: json: cannot unmarshal string into Go struct field mockClaims.Custom of type int",
			expectedResult: nil,
		},
		{
			name:  "claims validation error",
			token: makeToken(`{"sub":"1234567890","name":"John Doe","iat":1516239022}`),
			validatorFunc: func(claims mockClaims, idToken *oidc.IDToken) (*IntrospectResult, error) {
				return nil, errors.New("claims validation error")
			},
			errMsg:         "token claims validation: claims validation error",
			expectedResult: nil,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			verifier := oidc.NewVerifier("", nil, &oidc.Config{SkipClientIDCheck: true, SkipIssuerCheck: true, InsecureSkipSignatureCheck: true, SkipExpiryCheck: true})
			result, err := doIntrospect(context.Background(), verifier, tt.validatorFunc, tt.token)

			if tt.errMsg != "" || err != nil {
				assert.EqualError(t, err, tt.errMsg)
				return
			}
			assert.NoError(t, err)

			assert.Equal(t, tt.expectedResult, result)
		})
	}
}
func TestBuildCacheKey(t *testing.T) {
	tests := []struct {
		name     string
		prefix   string
		token    string
		expected string
	}{
		{
			name:     "valid prefix and token",
			prefix:   "prefix",
			token:    "token",
			expected: "prefix\x00token",
		},
		{
			name:     "empty prefix",
			prefix:   "",
			token:    "token",
			expected: "\x00token",
		},
		{
			name:     "empty token",
			prefix:   "prefix",
			token:    "",
			expected: "prefix\x00",
		},
		{
			name:     "empty prefix and token",
			prefix:   "",
			token:    "",
			expected: "\x00",
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			result := buildCacheKey(tt.prefix, tt.token)
			assert.Equal(t, tt.expected, result)
		})
	}
}
func TestInvalidToken_Unwrap(t *testing.T) {
	tests := []struct {
		name      string
		wrapped   error
		wantError error
	}{
		{
			name:      "unwraps error correctly",
			wrapped:   errors.New("wrapped error"),
			wantError: errors.New("wrapped error"),
		},
		{
			name:      "unwraps nil error",
			wrapped:   nil,
			wantError: nil,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			invalidToken := NewInvalidToken(tt.wrapped)
			assert.Equal(t, tt.wantError, invalidToken.Unwrap())
		})
	}
}
func TestCommunicationError_Unwrap(t *testing.T) {
	tests := []struct {
		name      string
		wrapped   error
		wantError error
	}{
		{
			name:      "unwraps error correctly",
			wrapped:   errors.New("wrapped error"),
			wantError: errors.New("wrapped error"),
		},
		{
			name:      "unwraps nil error",
			wrapped:   nil,
			wantError: nil,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			communicationError := NewCommunicationError(tt.wrapped)
			assert.Equal(t, tt.wantError, communicationError.Unwrap())
		})
	}
}
