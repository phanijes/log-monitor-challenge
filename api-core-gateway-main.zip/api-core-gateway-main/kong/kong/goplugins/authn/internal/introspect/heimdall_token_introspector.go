package introspect

import (
	"context"
	"errors"

	oidc "github.com/coreos/go-oidc/v3/oidc"
)

const ()

type heimdallClaims struct {
	EntraId string `json:"oid"`
	//there is no client id field in Heimdall token, client is probably the closest option
	//but its values are highly limited at the moment
	Client string `json:"client"`
}

// HeimdallTokenIntrospector is the struct which is used for validating Heimdall JWT token
type HeimdallTokenIntrospector struct {
	verifier OIDCTokenVerifier
}

func NewHeimdallTokenIntrospector(ctx context.Context, issuerURL string, jwksURL string, config *oidc.Config) (*HeimdallTokenIntrospector, error) {
	keySet := oidc.NewRemoteKeySet(oidc.ClientContext(ctx, client), jwksURL)
	return &HeimdallTokenIntrospector{verifier: oidc.NewVerifier(issuerURL, keySet, config)}, nil
}

// Introspect is used for validating a Heimdall JWT token
func (hti HeimdallTokenIntrospector) Introspect(ctx context.Context, token string) (*IntrospectResult, error) {
	return doIntrospect(ctx, hti.verifier, hti.validateClaims, token)
}

func (pi HeimdallTokenIntrospector) validateClaims(c heimdallClaims, idToken *oidc.IDToken) (*IntrospectResult, error) {
	if idToken.Subject == "" {
		return nil, errors.New("token payload does not contain uuid")
	}

	return &IntrospectResult{
		StatusCode: 200,
		Subject:    idToken.Subject,
		OID:        c.EntraId,
		UUID:       idToken.Subject,
		Expiration: idToken.Expiry.Unix(),
		ClientID:   c.Client,
		Active:     true,
		Kind:       HeimdallKind,
	}, nil
}
