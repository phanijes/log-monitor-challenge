package introspect

import (
	"context"
	"encoding/json"
	"errors"

	oidc "github.com/coreos/go-oidc/v3/oidc"
)

type pingClaims struct {
	Subject      string    `json:"sub"`
	Scope        string    `json:"scope"`
	ClientID     string    `json:"client_id"`
	UUID         string    `json:"uuid"`
	Entitlements pingSlice `json:"entitlements"`
}

type pingSlice []string

func (s *pingSlice) UnmarshalJSON(data []byte) error {
	switch data[0] {
	case '[':
		var slice []string
		err := json.Unmarshal(data, &slice)
		if err != nil {
			return err
		}
		*s = slice
	default:
		var str string
		err := json.Unmarshal(data, &str)
		if err != nil {
			return err
		}
		*s = []string{str}
	}
	return nil
}

// PingJWTIntrospector is the struct which is used for validating Ping JWT token
type PingJWTIntrospector struct {
	provider OIDCProvider
	verifier OIDCTokenVerifier
}

func NewPingJWTIntrospector(ctx context.Context, issuerURL string, config *oidc.Config) (*PingJWTIntrospector, error) {
	prov, err := oidc.NewProvider(oidc.ClientContext(ctx, client), issuerURL)
	if err != nil {
		return nil, err
	}
	return &PingJWTIntrospector{provider: prov, verifier: prov.Verifier(config)}, nil
}

// Introspect is used for validating a Entra JWT token
func (pi PingJWTIntrospector) Introspect(ctx context.Context, token string) (*IntrospectResult, error) {
	return doIntrospect(ctx, pi.verifier, pi.validateClaims, token)
}

func (pi PingJWTIntrospector) validateClaims(c pingClaims, idToken *oidc.IDToken) (*IntrospectResult, error) {
	if c.ClientID == "" {
		return nil, errors.New("token payload does not contain client_id")
	}
	if c.UUID == "" {
		return nil, errors.New("token payload does not contain uuid")
	}

	return &IntrospectResult{
		StatusCode:   200,
		Subject:      c.Subject,
		UUID:         c.UUID,
		Entitlements: []string(c.Entitlements),
		ClientID:     c.ClientID,
		Expiration:   idToken.Expiry.Unix(),
		Active:       true,
		Kind:         PingKind,
	}, nil
}
