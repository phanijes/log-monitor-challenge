package introspect

import (
	"common/log"
	"context"
	"testing"

	"github.com/stretchr/testify/assert"
)

func Test_tokenIntrospector_getIssuer(t *testing.T) {
	tests := []struct {
		name   string
		token  string
		ok     bool
		issuer string
	}{
		{
			"ok",
			//not a real JWT but works for our purpose
			"eyJpc3MiOiJodHRwczovL2V4YW1wbGUuY29tIn0K.eyJpc3MiOiJodHRwczovL2V4YW1wbGUuY29tIn0K.eyJpc3MiOiJodHRwczovL2V4YW1wbGUuY29tIn0K",
			true,
			"https://example.com",
		},
		{
			"2 parts",
			"eyJpc3MiOiJodHRwczovL2V4YW1wbGUuY29tIn0K.eyJpc3MiOiJodHRwczovL2V4YW1wbGUuY29tIn0K",
			false,
			"",
		},
		{
			"4 parts",
			"eyJpc3MiOiJodHRwczovL2V4YW1wbGUuY29tIn0K.eyJpc3MiOiJodHRwczovL2V4YW1wbGUuY29tIn0K.eyJpc3MiOiJodHRwczovL2V4YW1wbGUuY29tIn0K.eyJpc3MiOiJodHRwczovL2V4YW1wbGUuY29tIn0K",
			false,
			"",
		},
		{
			"empty 2nd part",
			"eyJpc3MiOiJodHRwczovL2V4YW1wbGUuY29tIn0K..eyJpc3MiOiJodHRwczovL2V4YW1wbGUuY29tIn0K",
			false,
			"",
		},
		{
			"no issuer",
			"eyJpc3MiOiJodHRwczovL2V4YW1wbGUuY29tIn0K.eyJpc3NzIjoiaHR0cHM6Ly9leGFtcGxlLmNvbSJ9Cg==.eyJpc3MiOiJodHRwczovL2V4YW1wbGUuY29tIn0K",
			false,
			"",
		},
		{
			"issuer not a string",
			"eyJpc3MiOiJodHRwczovL2V4YW1wbGUuY29tIn0K.eyJpc3MiOjExMX0K.eyJpc3MiOiJodHRwczovL2V4YW1wbGUuY29tIn0K",
			false,
			"",
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			ti := tokenIntrospector{}
			ok, issuer := ti.getIssuer(tt.token)
			assert.Equal(t, tt.ok, ok)
			assert.Equal(t, tt.issuer, issuer)
		})
	}
}
func Test_sliceContains(t *testing.T) {
	tests := []struct {
		name  string
		val   string
		slice []string
		want  bool
	}{
		{
			"contains",
			"example",
			[]string{"test", "example", "sample"},
			true,
		},
		{
			"does not contain",
			"missing",
			[]string{"test", "example", "sample"},
			false,
		},
		{
			"empty slice",
			"example",
			[]string{},
			false,
		},
		{
			"single element match",
			"example",
			[]string{"example"},
			true,
		},
		{
			"single element no match",
			"example",
			[]string{"test"},
			false,
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			got := sliceContains(tt.val, tt.slice)
			assert.Equal(t, tt.want, got)
		})
	}
}

func TestNewTokenIntrospector(t *testing.T) {
	mockPingOpaque := &mockEmptyIntrospector{}
	mockSts := &mockEmptyIntrospector{}
	mockFactory := &Factory{}
	stsIssuers := []string{"issuer1", "issuer2"}

	ti := NewTokenIntrospector(mockPingOpaque, mockSts, stsIssuers, mockFactory)

	assert.NotNil(t, ti)
	assert.Equal(t, mockPingOpaque, ti.pingOpaque)
	assert.Equal(t, mockSts, ti.sts)
	assert.Equal(t, stsIssuers, ti.stsIssuers)
	assert.NotNil(t, ti.pool)
	assert.Equal(t, mockFactory, ti.factory)
}
func TestTokenIntrospector_Introspect(t *testing.T) {
	tests := []struct {
		name       string
		token      string
		pingOpaque TokenIntrospector
		sts        TokenIntrospector
		stsIssuers []string
		factory    *Factory
		want       *IntrospectResult
		errMsg     string
	}{
		{
			name:       "non-JWT token with PING introspection",
			token:      "non.jwt.token",
			pingOpaque: &mockIntrospector{result: &IntrospectResult{Kind: PingKind}},
			want:       &IntrospectResult{Kind: "ping"},
			errMsg:     "",
		},
		{
			name:   "non-JWT token without PING introspection",
			token:  "non.jwt.token",
			errMsg: "non-JWT token",
		},
		{
			name:       "JWT token with STS issuer",
			token:      makeToken(`{"iss":"sts-issuer"}`),
			stsIssuers: []string{"sts-issuer", "other-sts-issuer"},
			sts:        &mockIntrospector{result: &IntrospectResult{Kind: STSKind}},
			want:       &IntrospectResult{Kind: "sts"},
			errMsg:     "",
		},
		{
			name:       "JWT token with factory issuer",
			token:      makeToken(`{"iss":"some-issuer","exp":4102448461}`),
			stsIssuers: []string{"sts-issuer", "other-sts-issuer"},
			factory:    &Factory{heimdallIssuer: "some-issuer"},
			want:       &IntrospectResult{Kind: "heimdall"},
			errMsg:     "",
		},
		{
			name:    "JWT token with unknown issuer and factory creation failure",
			token:   makeToken(`{"iss":"bad-issuer"}`),
			factory: &Factory{},
			errMsg:  "unknown issuer bad-issuer",
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			ti := NewTokenIntrospector(tt.pingOpaque, tt.sts, tt.stsIssuers, tt.factory)
			ti.pool.Add("some-issuer", &mockIntrospector{result: &IntrospectResult{Kind: HeimdallKind}})
			ctx := log.NewContext(context.Background(), log.NewSimpleLogger())
			got, err := ti.Introspect(ctx, tt.token)
			if tt.errMsg != "" || err != nil {
				assert.EqualError(t, err, tt.errMsg)
				return
			} else {
				assert.NoError(t, err)
				assert.Equal(t, tt.want, got)
			}
		})
	}
}

type mockIntrospector struct {
	result *IntrospectResult
	err    error
}

func (m *mockIntrospector) Introspect(ctx context.Context, token string) (*IntrospectResult, error) {
	return m.result, m.err
}
