package introspect

import (
	"sync"
)

type Pool struct {
	pool map[string]TokenIntrospector
	mt   *sync.RWMutex
}

func NewPool() *Pool {
	return &Pool{
		pool: make(map[string]TokenIntrospector),
		mt:   new(sync.RWMutex),
	}
}

func (p *Pool) Get(issuer string) TokenIntrospector {
	p.mt.RLock()
	introspector, ok := p.pool[issuer]
	p.mt.RUnlock()
	if !ok {
		return nil
	}
	return introspector
}

func (p *Pool) Add(issuer string, introspector TokenIntrospector) {
	p.mt.Lock()
	p.pool[issuer] = introspector
	p.mt.Unlock()
}
