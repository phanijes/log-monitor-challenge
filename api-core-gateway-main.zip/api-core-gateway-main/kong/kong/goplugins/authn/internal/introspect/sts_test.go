package introspect

import (
	"bytes"
	"common/cache/base"
	"common/log"
	"context"
	"io"
	"net/http"
	"net/http/httptest"
	"net/http/httputil"
	"testing"

	"github.com/stretchr/testify/assert"
)

var sampleResponse = `{"active": true, "iss": "https://financial.thomsonreuters.com/api/identity/sts_integration", "iat": 1539348019, "exp": 1539348319,
"aud": "d0d0006f0ba6438f9f620810a7ef45cd712d9ce9", "sub": "PAXTRA79381",
"session": "AQIC5wM2LY4Sfcx5Vz8AvcVdcgu1LGw89ZBnPdFqqp%2BocyA%3D%40AAJTSQACMTAAAlNLABMxODE0MDEyMDEyMzY5NzU1NDYzAAJTMQACMDc%3D%23",
"type": "users", "deviceId": "", "version": "1.0.0.0", "activeSite": "amers1", "sapVersion": "1538186659",
"username": "user@lseg.com",
"scope": "trapi.data.historical-pricing.events.read trapi.data.historical-pricing.summaries.read trapi.data.quantitative-analytics.read",
"token_type": "access_token"}`

func TestMakeSTSIntrospectRequest(t *testing.T) {
	tests := []struct {
		name     string
		status   int
		body     string
		token    string
		expected STSIntrospectResponse
		err      string
	}{
		{
			"active token",
			http.StatusOK,
			`{"active":true}`,
			"",
			STSIntrospectResponse{Active: true, STSIntrospectError: STSIntrospectError{StatusCode: http.StatusOK}},
			"",
		},
		{
			"expired token",
			http.StatusOK,
			`{"active":false}`,
			"",
			STSIntrospectResponse{Active: false, STSIntrospectError: STSIntrospectError{StatusCode: http.StatusOK}},
			"",
		},
		{
			"some response with non-200 status",
			http.StatusBadGateway,
			`{"active":true}`,
			"",
			STSIntrospectResponse{Active: true, STSIntrospectError: STSIntrospectError{StatusCode: http.StatusBadGateway}},
			"",
		},
		{
			"error, bad json",
			http.StatusInternalServerError,
			`{bad json}`,
			"",
			STSIntrospectResponse{Active: false, STSIntrospectError: STSIntrospectError{StatusCode: http.StatusInternalServerError}},
			"decoding introspect response: unmarshaling '{bad json}': invalid character 'b' looking for beginning of object key string",
		},
		{
			"ok, synthetic values",
			http.StatusOK,
			`{"active":true,"scope":"some scope","username":"some user","token_type":"some type",
			"id":"id1","type":"t","sub":"u","aud":"a","iss":"i","exp":123,
			"session":"abc","activeSite":"amers1","sapVersion":"sv1","version":"v1",
			"iat":321,"error":"err","error_description":"errd"}`,
			"",
			STSIntrospectResponse{Active: true, STSIntrospectError: STSIntrospectError{StatusCode: http.StatusOK, Err: "err", ErrorDescr: "errd"}, Scope: "some scope",
				Username: "some user", TokenType: "some type", Exp: 123, Iat: 321, UUID: "u", Aud: "a", Iss: "i", Type: "t", Session: "abc", ActiveSite: "amers1", SapVersion: "sv1", Version: "v1"},
			"",
		},
		{
			"ok, almost real response",
			http.StatusOK,
			sampleResponse,
			"",
			STSIntrospectResponse{Active: true, STSIntrospectError: STSIntrospectError{StatusCode: http.StatusOK}, Scope: "trapi.data.historical-pricing.events.read trapi.data.historical-pricing.summaries.read trapi.data.quantitative-analytics.read",
				Username: "user@lseg.com", TokenType: "access_token", Exp: 1539348319, Iat: 1539348019, UUID: "PAXTRA79381", Aud: "d0d0006f0ba6438f9f620810a7ef45cd712d9ce9", Iss: "https://financial.thomsonreuters.com/api/identity/sts_integration", Type: "users", Session: "AQIC5wM2LY4Sfcx5Vz8AvcVdcgu1LGw89ZBnPdFqqp%2BocyA%3D%40AAJTSQACMTAAAlNLABMxODE0MDEyMDEyMzY5NzU1NDYzAAJTMQACMDc%3D%23", ActiveSite: "amers1", SapVersion: "1538186659", Version: "1.0.0.0"},
			"",
		},
	}
	for _, test := range tests {
		t.Run(test.name, func(t *testing.T) {
			assert := assert.New(t)

			testServer := httptest.NewServer(http.HandlerFunc(func(res http.ResponseWriter, req *http.Request) {
				res.Header().Add("Content-Type", "application/json")
				res.WriteHeader(test.status)
				res.Write([]byte(test.body))
			}))
			defer func() { testServer.Close() }()
			sts := &STSIntrospector{}
			req, _ := sts.createIntrospectRequest(context.Background(), testServer.URL, test.token, false)
			introspectResult, err := sts.makeIntrospectRequest(context.Background(), http.DefaultClient, req)

			if test.err != "" || err != nil {
				assert.EqualError(err, test.err)
				return
			}
			assert.Equal(&test.expected, introspectResult)
		})
	}
}

func Test_parseSTSResponse(t *testing.T) {
	tests := []struct {
		name       string
		statuscode int
		body       string
		headers    http.Header
		expected   *STSIntrospectResponse
		err        string
	}{
		{
			"ok",
			200,
			`{"active":true}`,
			http.Header{"Content-Type": []string{"application/json"}},
			&STSIntrospectResponse{Active: true, STSIntrospectError: STSIntrospectError{StatusCode: 200}},
			"",
		},
		{
			"bad content type",
			200,
			`some text`,
			http.Header{"Content-Type": []string{"charset==:utf-8; qq "}},
			&STSIntrospectResponse{Active: true},
			"decoding introspect response: failed to parse response media type: mime: expected slash after first token",
		},
		{
			"non-json content type",
			200,
			`some text`,
			http.Header{"Content-Type": []string{"text/plain"}},
			&STSIntrospectResponse{Active: true},
			"decoding introspect response: unexpected content-type 'text/plain', expected 'application/json'. Response: HTTP/0.0 200 OK\r\nContent-Type: text/plain\r\n\r\nsome text",
		},
		{
			"invalid json",
			200,
			`some text`,
			http.Header{"Content-Type": []string{"application/json"}},
			&STSIntrospectResponse{Active: true},
			"decoding introspect response: unmarshaling 'some text': invalid character 's' looking for beginning of value",
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			br := io.NopCloser(bytes.NewReader([]byte(tt.body)))
			sts := &STSIntrospector{}
			got, err := sts.parseResponse(context.Background(), &http.Response{StatusCode: tt.statuscode, Header: tt.headers, Body: br})
			if tt.err != "" || err != nil {
				assert.EqualError(t, err, tt.err)
				return
			}
			assert.Equal(t, tt.expected, got)
		})
	}
}
func TestCreateIntrospectRequest(t *testing.T) {
	tests := []struct {
		description   string
		introspectURL string
		useJSON       bool
		token         string
		expectedError string
		expectedDump  string
	}{
		{
			description:   "Invalid URL",
			introspectURL: ":",
			useJSON:       false,
			token:         "invalid_token",
			expectedError: "creating introspect request: parse \":\": missing protocol scheme",
			expectedDump:  "",
		},
		{
			description:   "Valid URL with form encoding",
			introspectURL: "http://localhost:8080/introspect",
			useJSON:       false,
			token:         "valid_token",
			expectedError: "",
			expectedDump:  "POST /introspect HTTP/1.1\r\nHost: localhost:8080\r\nAccept: application/json\r\nAuthorization: Bearer valid_token\r\nContent-Type: application/x-www-form-urlencoded\r\n\r\ntoken=valid_token",
		},
		{
			description:   "Valid URL with JSON encoding",
			introspectURL: "http://localhost:8080/introspect",
			useJSON:       true,
			token:         "valid_token",
			expectedError: "",
			expectedDump:  "POST /introspect HTTP/1.1\r\nHost: localhost:8080\r\nAccept: application/json\r\nAuthorization: Bearer valid_token\r\nContent-Type: application/json\r\n\r\n{\"token\":\"valid_token\"}",
		},
	}

	for _, test := range tests {
		t.Run(test.description, func(t *testing.T) {
			sts := &STSIntrospector{}
			req, err := sts.createIntrospectRequest(context.Background(), test.introspectURL, test.token, test.useJSON)

			if test.expectedError != "" {
				assert.EqualError(t, err, test.expectedError)
			} else {
				assert.NoError(t, err)
				dump, err := httputil.DumpRequest(req, true)
				assert.NoError(t, err)
				assert.Equal(t, test.expectedDump, string(dump))
			}
		})
	}
}
func TestNewSTSIntrospector(t *testing.T) {
	tests := []struct {
		description string
		client      *http.Client
		cfg         STSConfig
		cache       base.Cache
	}{
		{
			description: "Valid inputs",
			client:      &http.Client{},
			cfg:         STSConfig{IntrospectURI: "http://localhost:8080/introspect", IntrospectCacheTTL: 60, UseJSON: true, CacheEnabled: true},
			cache:       &mockCache{},
		},
	}

	for _, test := range tests {
		t.Run(test.description, func(t *testing.T) {
			stsIntrospector := NewSTSIntrospector(test.client, test.cfg, test.cache)
			assert.NotNil(t, stsIntrospector)
			assert.Equal(t, test.client, stsIntrospector.client)
			assert.Equal(t, test.cfg, stsIntrospector.cfg)
			assert.Equal(t, test.cache, stsIntrospector.cache)
		})
	}
}
func TestIntrospect(t *testing.T) {
	cache := &mockCache{data: map[string][]byte{"sts_token\x00cached_token": []byte(`{"active":true,"uuid":"cached_uuid"}`)}}
	tests := []struct {
		name           string
		token          string
		cacheEnabled   bool
		cacheResult    *IntrospectResult
		httpStatusCode int
		httpResponse   string
		expectedResult *IntrospectResult
		expectedError  string
	}{
		{
			name:           "active token from cache",
			token:          "cached_token",
			cacheEnabled:   true,
			cacheResult:    &IntrospectResult{Active: true, UUID: "cached_uuid"},
			httpStatusCode: http.StatusOK,
			httpResponse:   `{"active":true}`,
			expectedResult: &IntrospectResult{Active: true, UUID: "cached_uuid"},
			expectedError:  "",
		},
		{
			name:           "active token from STS",
			token:          "active_token",
			cacheEnabled:   false,
			cacheResult:    nil,
			httpStatusCode: http.StatusOK,
			httpResponse:   sampleResponse,
			expectedResult: &IntrospectResult{StatusCode: http.StatusOK, UUID: "PAXTRA79381", Entitlements: []string{"trapi.data.historical-pricing.events.read", "trapi.data.historical-pricing.summaries.read", "trapi.data.quantitative-analytics.read"}, ClientID: "d0d0006f0ba6438f9f620810a7ef45cd712d9ce9", Expiration: 1539348319, Active: true, Kind: STSKind},
			expectedError:  "",
		},
		{
			name:           "expired token from STS",
			token:          "expired_token",
			cacheEnabled:   false,
			cacheResult:    nil,
			httpStatusCode: http.StatusOK,
			httpResponse:   `{"active":false}`,
			expectedResult: &IntrospectResult{StatusCode: http.StatusOK, Active: false, Kind: STSKind, Entitlements: []string{""}},
			expectedError:  "",
		},
		{
			name:           "STS request failure",
			token:          "error_token",
			cacheEnabled:   false,
			cacheResult:    nil,
			httpStatusCode: http.StatusInternalServerError,
			httpResponse:   `{"active":false}`,
			expectedResult: nil,
			expectedError:  "request failed: Status code: 500. Error: , ErrorDescr: ",
		},
	}

	for _, test := range tests {
		t.Run(test.name, func(t *testing.T) {
			assert := assert.New(t)

			testServer := httptest.NewServer(http.HandlerFunc(func(res http.ResponseWriter, req *http.Request) {
				res.Header().Add("Content-Type", "application/json")
				res.WriteHeader(test.httpStatusCode)
				res.Write([]byte(test.httpResponse))
			}))
			defer testServer.Close()

			sts := &STSIntrospector{
				client: http.DefaultClient,
				cfg: STSConfig{
					IntrospectURI:      testServer.URL,
					IntrospectCacheTTL: 60,
					UseJSON:            true,
					CacheEnabled:       test.cacheEnabled,
				},
				cache: cache,
			}
			ctx := log.NewContext(context.Background(), log.NewSimpleLogger())
			result, err := sts.Introspect(ctx, test.token)

			if test.expectedError != "" {
				assert.EqualError(err, test.expectedError)
			} else {
				assert.NoError(err)
				assert.Equal(test.expectedResult, result)
			}
		})
	}
}
