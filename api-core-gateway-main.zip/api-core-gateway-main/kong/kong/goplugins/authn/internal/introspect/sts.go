package introspect

import (
	"bytes"
	"common/cache"
	"common/cache/base"
	"context"
	"encoding/json"
	"fmt"
	"io"
	"mime"
	"net/http"
	"net/url"
	"strings"
)

// IntrospectResponse according to STS contract
// The STS swagger is here https://git.sami.int.thomsonreuters.com/eds-auth/oauth-server/blob/master/docs/swagger.yaml
type STSIntrospectResponse struct {
	Active     bool   `json:"active"`
	Scope      string `json:"scope"`
	Username   string `json:"username"`
	TokenType  string `json:"token_type"`
	Exp        int64  `json:"exp"`
	Iat        int64  `json:"iat"`
	UUID       string `json:"sub"`
	Aud        string `json:"aud"`
	Iss        string `json:"iss"`
	Type       string `json:"type"`
	Session    string `json:"session"`
	ActiveSite string `json:"activeSite"`
	SapVersion string `json:"sapVersion"`
	Version    string `json:"version"`
	STSIntrospectError
}

type STSIntrospectError struct {
	StatusCode int    `json:"-"`
	Err        string `json:"error"`
	ErrorDescr string `json:"error_description"`
}

func (e STSIntrospectError) Error() string {
	return fmt.Sprintf("Status code: %d. Error: %s, ErrorDescr: %s", e.StatusCode, e.Err, e.ErrorDescr)
}

type STSConfig struct {
	IntrospectURI      string
	IntrospectCacheTTL int
	UseJSON            bool
	CacheEnabled       bool
}

type STSIntrospector struct {
	client *http.Client
	cfg    STSConfig
	cache  base.Cache
}

func NewSTSIntrospector(client *http.Client, cfg STSConfig, cache base.Cache) *STSIntrospector {
	return &STSIntrospector{client, cfg, cache}
}

func (sts *STSIntrospector) Introspect(ctx context.Context, token string) (*IntrospectResult, error) {
	//trying to get introspect result from cache
	cacheKey := buildCacheKey("sts_token", token)
	if sts.cfg.CacheEnabled {
		if result := cache.GetFromCache[IntrospectResult](ctx, sts.cache, cacheKey); result != nil {
			return result, nil
		}
	}
	//create sts introspect request
	stsReq, err := sts.createIntrospectRequest(ctx, sts.cfg.IntrospectURI, token, sts.cfg.UseJSON)
	if err != nil {
		return nil, err
	}

	//make sts introspect request
	resp, err := sts.makeIntrospectRequest(ctx, sts.client, stsReq)
	if err != nil {
		return nil, NewCommunicationError(err)
	}

	//verifying status code. STS do not return 4XX for introspect (https://git.sami.int.thomsonreuters.com/eds-auth/oauth-server/blob/master/docs/swagger.yaml)
	if resp.StatusCode != http.StatusOK {
		return nil, NewCommunicationError(fmt.Errorf("request failed: %w", resp.STSIntrospectError))
	}

	result := &IntrospectResult{
		StatusCode:   resp.StatusCode,
		UUID:         resp.UUID,
		Entitlements: strings.Split(resp.Scope, " "),
		ClientID:     resp.Aud,
		Expiration:   resp.Exp,
		Active:       resp.Active,
		Kind:         STSKind,
	}

	if sts.cfg.CacheEnabled && result.Active {
		cache.UpdateInCache(ctx, sts.cache, cacheKey, result, sts.cfg.IntrospectCacheTTL)
	}
	return result, nil
}

func (sts *STSIntrospector) makeIntrospectRequest(ctx context.Context, client *http.Client, stsReq *http.Request) (*STSIntrospectResponse, error) {
	stsResp, err := client.Do(stsReq)
	if err != nil {
		return nil, fmt.Errorf("sending introspect request: %w", err)
	}
	defer stsResp.Body.Close()
	return sts.parseResponse(ctx, stsResp)
}

func (sts *STSIntrospector) parseResponse(ctx context.Context, stsResp *http.Response) (*STSIntrospectResponse, error) {
	data, err := io.ReadAll(stsResp.Body)
	if err != nil {
		return nil, fmt.Errorf("reading introspect response: %w", err)
	}

	mediaType, _, mtErr := mime.ParseMediaType(stsResp.Header.Get(ContentTypeHeaderName))

	var introspectResp STSIntrospectResponse
	switch mediaType {
	case ContentTypeJson:
		//try to unmarshal on any status code as the json response might be from STS and contain error details
		err = json.Unmarshal(data, &introspectResp)
		if len(data) > 1024 {
			data = data[:1024]
		}
		if err != nil {
			err = fmt.Errorf("unmarshaling '%s': %w", string(data), err)
		}
	case "":
		err = fmt.Errorf("failed to parse response media type: %w", mtErr)
	default:
		stsResp.Body = io.NopCloser(bytes.NewBuffer(data))
		var b bytes.Buffer
		stsResp.Write(&b)
		err = fmt.Errorf("unexpected content-type '%s', expected '%s'. Response: %s", mediaType, ContentTypeJson, b.String())
	}

	//response is invalid (non-json or bad json)
	if err != nil {
		return nil, fmt.Errorf("decoding introspect response: %w", err)
	}

	introspectResp.StatusCode = stsResp.StatusCode
	return &introspectResp, nil
}

func (sts *STSIntrospector) createIntrospectRequest(ctx context.Context, uri, token string, useJSON bool) (*http.Request, error) {
	var reqBody io.Reader

	if useJSON {
		b, err := json.Marshal(map[string]string{"token": token})
		if err != nil {
			return nil, err
		}

		reqBody = bytes.NewReader(b)
	} else {
		reqBody = strings.NewReader(url.Values{"token": []string{token}}.Encode())
	}

	stsReq, err := http.NewRequestWithContext(ctx, http.MethodPost, uri, reqBody)
	if err != nil {
		return nil, fmt.Errorf("creating introspect request: %w", err)
	}

	if useJSON {
		stsReq.Header.Set(ContentTypeHeaderName, ContentTypeJson)
	} else {
		stsReq.Header.Set(ContentTypeHeaderName, contentTypeFormEncode)
	}
	stsReq.Header.Set(acceptHeaderName, ContentTypeJson)
	stsReq.Header.Add(AuthorizationHeaderName, "Bearer "+token)

	return stsReq, nil
}
