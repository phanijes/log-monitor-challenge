package odps

import (
	"bytes"
	"context"
	"fmt"
	"io"
	"net/http"
	"net/http/httptest"
	"net/url"
	"strings"
	"testing"
	"time"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

type testServer struct {
	*httptest.Server
	response []byte
}

func (s *testServer) Set(resp []byte) {
	s.response = resp
}

type testStruct struct {
	service string
	polist  []string
	expect  []PoResult
	resp    []byte
	isFail  bool
	errMsg  string
}

func (s testStruct) expectErr(t *testing.T, err error) {
	if s.isFail {
		assert.EqualError(t, err, s.errMsg)
	}
}

func TestAllow(t *testing.T) {
	tests := []testStruct{
		{ // send blank perms, receive a bad response
			// http://127.0.0.1:50325/command=poCheck&user=User&position=127.0.0.1/net&application=9999&poset=SERVICE,
			"SERVICE",
			[]string{},
			nil,
			[]byte(`SUCCESS:
SERVICE,`),
			true,
			`invalid poCheck result at position 0: SUCCESS:
SERVICE,`,
		},
		{ // send nul perms, receive a bad response
			// http://127.0.0.1:50733/command=poCheck&user=User&position=127.0.0.1/net&application=9999&poset=SERVICE
			"SERVICE",
			nil,
			nil,
			[]byte(`SUCCESS:
SERVICE`),
			true,
			`no permissions returned in the response SUCCESS:
SERVICE`,
		},
		{ // Single good response
			// http://127.0.0.1:50735/command=poCheck&user=User&position=127.0.0.1/net&application=9999&poset=SERVICE,one
			"SERVICE",
			[]string{"HSBC_LUSID,"},
			[]PoResult{1},
			[]byte(`SUCCESS:
SERVICE,1`),
			false,
			"",
		},
		{ // good fresponse, has two permissions out of three
			"SERVICE",
			[]string{"HSBC_LUSID", "REFINITIV_LUSID", "LLOYDS_LUSID"},
			[]PoResult{1, 1, 0},
			[]byte(`SUCCESS:
SERVICE,1,1,0`),
			false,
			"",
		},
		{ // good response, has two permissions out of three, one unknown
			"SERVICE",
			[]string{"HSBC_LUSID", "REFINITIV_LUSID", "LLOYDS_LUSID"},
			[]PoResult{-1, 1, 0},
			[]byte(`SUCCESS:
SERVICE,?,1,0`),
			false,
			"",
		},
		{ // Good esponse, has no permissions out of three
			"SERVICE",
			[]string{"HSBC_LUSID", "REFINITIV_LUSID", "LLOYDS_LUSID"},
			[]PoResult{0, 0, 0},
			[]byte(`SUCCESS:
SERVICE,0,0,0`),
			false,
			"",
		},
		{ // good response, has unknown permissions
			"SERVICE",
			[]string{"HSBC_LUSID", "REFINITIV_LUSID", "LLOYDS_LUSID"},
			[]PoResult{-1, -1, -1},
			[]byte(`SUCCESS:
SERVICE,?,?,?`),
			false,
			"",
		},
		{ // good response, has full permissions, however it is a mismatch, this needs to be tested outside of this
			"SERVICE",
			[]string{"HSBC_LUSID", "REFINITIV_LUSID", "LLOYDS_LUSID"},
			[]PoResult{1, 1, 1, 1},
			[]byte(`SUCCESS:
SERVICE,1,1,1,1`),
			false,
			"",
		},
		{ // bad response, has unexpected crap
			"SERVICE",
			[]string{"HSBC_LUSID", "REFINITIV_LUSID", "LLOYDS_LUSID"},
			[]PoResult{},
			[]byte(`SUCCESS:
SERVICE,G,H,I,J`),
			true,
			`invalid poCheck result at position 0: SUCCESS:
SERVICE,G,H,I,J`,
		},
		{ // bad response, has unexpected crap
			"SERVICE",
			[]string{"HSBC_LUSID", "REFINITIV_LUSID", "LLOYDS_LUSID"},
			[]PoResult{1, 1, 1, 1},
			[]byte(`SUCCESS:
SERVICE,GARBAGE`),
			true,
			`invalid poCheck result at position 0: SUCCESS:
SERVICE,GARBAGE`,
		},
		{ // no service specified
			"",
			[]string{"HSBC_LUSID", "REFINITIV_LUSID", "LLOYDS_LUSID"},
			[]PoResult{},
			[]byte(`SUCCESS:
,1,2,3`),
			true,
			`invalid poCheck result at position 1: SUCCESS:
,1,2,3`,
		},
	}

	ts := &testServer{}
	ts.Server = httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, _ *http.Request) { w.Write(ts.response) }))
	defer ts.Close()

	odps := NewClient(ts.Client(), ts.URL, "127.0.0.1/net", "9999")
	ctx := context.Background()
	uuid := "User"

	for testCase, test := range tests {
		ts.Set(test.resp)
		perms, err := odps.GetUsrSvcPOs(ctx, test.service, uuid, test.polist)

		if test.isFail {
			assert.EqualError(t, err, test.errMsg, "Test number %d", testCase)
		} else {
			assert.Equal(t, test.expect, perms, "Test number %d", testCase)
		}
	}
}

func TestExtractPermsSimple(t *testing.T) {
	tests := []struct {
		name      string
		service   string
		body      []byte
		expectRes []PoResult
		expectErr string
	}{
		{
			name:    "unknown",
			service: "ESTIMATES",
			body: []byte(`SUCCESS:
ESTIMATES,?,?`),
			expectRes: []PoResult{-1, -1},
		},
		{
			name:    "Wrong service",
			service: "SERVICE",
			body: []byte(`SUCCESS:
ESTIMATES,?,?`),
			expectErr: "incorrect service in a response, expect SERVICE",
		},
		{
			name:    "zero one",
			service: "ESTIMATES",
			body: []byte(`SUCCESS:
ESTIMATES,0,1`),
			expectRes: []PoResult{0, 1},
		},
		{
			name:    "wrong format",
			service: "SERVICE",
			body: []byte(`SUCCESS:
'1013=EST_FREE'`),
			expectErr: `incorrect service in a response, expect SERVICE, got '1013=EST_FREE': SUCCESS:
'1013=EST_FREE`,
		},
		{
			name:    "no perms",
			service: "SERVICE",
			body: []byte(`SUCCESS:
SERVICE`),
			expectErr: `no permissions returned in the response SUCCESS:
SERVICE`,
		},
		{
			name:    "no perms 2",
			service: "SERVICE",
			body: []byte(`SUCCESS:
SERVICE,`),
			expectErr: `invalid poCheck result at position 0: SUCCESS:
SERVICE,`,
		},
		{
			name:    "not finished ",
			service: "SERVICE",
			body: []byte(`SUCCESS:
SERVICE,1,`),
			expectErr: `invalid poCheck result at position 1: SUCCESS:
SERVICE,`,
		},
		{
			name:      "empty body",
			service:   "SERVICE",
			body:      []byte(``),
			expectErr: `SUCCESS marker not found, got `,
		},
		{
			name:      "denied",
			service:   "SERVICE",
			body:      []byte(`DENIED:GENTC-208443, unknown to system.%`),
			expectErr: "SUCCESS marker not found, got DENIED:GENTC-208443, unknown to system.%",
		},
	}

	for _, test := range tests {
		t.Run(test.name, func(t *testing.T) {
			res, err := extractPermsSimple(test.service, test.body)
			if test.expectErr == "" {
				require.NoError(t, err)
			}
			errstr := fmt.Sprintf("%v", err)
			require.Contains(t, errstr, test.expectErr)
			require.Equal(t, test.expectRes, res)
		})
	}
}

func TestParseODPSResponse(t *testing.T) {
	tests := []struct {
		id           string
		odpsresponse string
		expected     map[string]struct{}
		err          string
	}{
		{
			"ok",
			`SUCCESS:
			'10=API_ESG_SCORES_FULL_READ'
			'11=API_ESG_MEASURES_STANDARD_READ'
			'12=API_ESG_MEASURES_FULL_READ'
			'2=API_ESG_STANDARD'
			'48=API_ACCOUNTS_GROUPS'`,
			map[string]struct{}{
				"API_ESG_SCORES_FULL_READ": {}, "API_ESG_MEASURES_STANDARD_READ": {},
				"API_ESG_MEASURES_FULL_READ": {}, "API_ESG_STANDARD": {}, "API_ACCOUNTS_GROUPS": {},
			},
			"",
		},
		{
			"ok",
			`SUCCESS:
			'10=API_ESG_SCORES_FULL_READ'`,
			map[string]struct{}{"API_ESG_SCORES_FULL_READ": {}},
			"",
		},
		{
			"fail",
			`FAIL`,
			map[string]struct{}{},
			"unexpected result of ODSP call: FAIL",
		},
		{
			"empty",
			`SUCCESS:`,
			map[string]struct{}{},
			"unexpected result of ODSP call: SUCCESS:",
		},
		{
			"bad po",
			`SUCCESS:
			'10:API_ESG_SCORES_FULL_READ'`,
			map[string]struct{}{},
			"unexpected PO: \t\t\t'10:API_ESG_SCORES_FULL_READ'",
		},
	}

	for _, test := range tests {
		assert := assert.New(t)
		result, err := parseODPSResponse(test.odpsresponse)
		if test.err != "" {
			assert.EqualError(err, test.err, "id %s", test.id)
			continue
		}
		assert.NoError(err, "id %s", test.id)
		assert.Equal(test.expected, result, "id %s", test.id)
	}
}

func TestCmdGetUsrSvcPOsRawURL(t *testing.T) {
	expect := "http://example.com/command=poCheck&user=myUser&position=127.0.0.1/myPosiotion&application=myAppID&poset=myService,po-One,po-two"
	p := urlCommandParams{
		Type:     commandCheck,
		POList:   []string{"po-One", "po-two"},
		Service:  "myService",
		User:     "myUser",
		AppID:    "myAppID",
		Position: "127.0.0.1/myPosiotion",
		URI:      "http://example.com",
		Version:  odpsLegacy,
	}

	s, err := p.buildRaw()
	require.NoError(t, err)
	assert.Equal(t, expect, s)
}

func TestCmdGetUsrSvcPOsEncodedURL(t *testing.T) {
	p := urlCommandParams{
		Type:     commandCheck,
		POList:   []string{"po-One", "po-two"},
		Service:  "myService",
		User:     "myUser",
		AppID:    "myAppID",
		Position: "127.0.0.1/myPosiotion",
		URI:      "https://example.com",
		Version:  odpsV3,
	}

	s, err := p.Build()
	require.NoError(t, err)
	fmt.Println(s)
	s = strings.Replace(s, "/command", "?command", 1)
	u, err := url.Parse(s)
	require.NoError(t, err)
	assert.Equal(t, p.User, u.Query().Get("user"))
	assert.Equal(t, p.Position, u.Query().Get("position"))
	assert.Equal(t, p.AppID, u.Query().Get("application"))
	assert.Equal(t, commandCheck.String(), u.Query().Get("command"))
	for _, p := range p.POList {
		assert.Contains(t, u.Query().Get("poset"), p)
	}
	assert.Equal(t, "https", u.Scheme)
}

func TestCmdGetAllPOsRawURL(t *testing.T) {
	expect := "http://example.com/command=subscriptionList&user=myUser&position=127.0.0.1/myPosiotion&application=myAppID&service=myService"
	p := urlCommandParams{
		Type:     commandAll,
		Service:  "myService",
		User:     "myUser",
		AppID:    "myAppID",
		Position: "127.0.0.1/myPosiotion",
		URI:      "http://example.com",
		Version:  odpsLegacy,
	}

	s, err := p.Build()
	require.NoError(t, err)
	assert.Equal(t, expect, s)
}

func TestCmdGetAllPOsEncodedURL(t *testing.T) {
	p := urlCommandParams{
		Type:     commandAll,
		Service:  "myService",
		User:     "myUser",
		AppID:    "myAppID",
		Position: "127.0.0.1/myPosiotion",
		URI:      "https://example.com",
		Version:  odpsV3,
	}

	s, err := p.Build()
	require.NoError(t, err)
	fmt.Println(s)
	s = strings.Replace(s, "/command", "?command", 1)
	u, err := url.Parse(s)
	require.NoError(t, err)
	assert.Equal(t, p.User, u.Query().Get("user"))
	assert.Equal(t, p.Position, u.Query().Get("position"))
	assert.Equal(t, p.AppID, u.Query().Get("application"))
	assert.Equal(t, commandAll.String(), u.Query().Get("command"))
	assert.Equal(t, "https", u.Scheme)
}

func TestNew(t *testing.T) {
	cases := []struct {
		Version     string
		ErrExpected bool
	}{
		{Version: "Unsuppoterd version", ErrExpected: true},
		{Version: ODPSVersion3, ErrExpected: false},
	}
	for _, v := range cases {
		c, err := New(http.DefaultClient, v.Version, "uri", "position", "appID")
		if v.ErrExpected {
			assert.Error(t, err)
			continue
		}
		assert.NoError(t, err)
		assert.Equal(t, "uri", c.uri)
		assert.Equal(t, "position", c.position)
		assert.Equal(t, "appID", c.application)
	}
}

func TestClientGetAllPOs(t *testing.T) {
	httpResult := []byte(`SUCCESS:
	'10=API_ESG_SCORES_FULL_READ'
	'11=API_ESG_MEASURES_STANDARD_READ'
	'12=API_ESG_MEASURES_FULL_READ'
	'2=API_ESG_STANDARD'
	'48=API_ACCOUNTS_GROUPS'`)
	parsed := map[string]struct{}{
		"API_ESG_SCORES_FULL_READ": {}, "API_ESG_MEASURES_STANDARD_READ": {},
		"API_ESG_MEASURES_FULL_READ": {}, "API_ESG_STANDARD": {}, "API_ACCOUNTS_GROUPS": {},
	}
	c, err := New(createMockClient(httpResult, http.StatusOK), ODPSVersion3, "https://example.com", "position", "appID")
	require.NoError(t, err)
	d, err := c.GetAllPOs(context.TODO(), "serv", "usr")
	assert.NoError(t, err)
	assert.Equal(t, len(d), len(parsed))
	for k, v := range parsed {
		assert.Contains(t, d, k)
		assert.Equal(t, v, d[k])
	}
}

func createMockClient(result []byte, code int) *http.Client {
	t := &mockedTransport{
		code: code,
		ret:  result,
	}
	return &http.Client{Transport: t}
}

func (m *mockedTransport) RoundTrip(req *http.Request) (*http.Response, error) {
	resp := &http.Response{
		Header:     make(http.Header),
		Request:    req,
		StatusCode: m.code,
	}
	resp.Body = io.NopCloser(bytes.NewReader(m.ret))
	return resp, nil
}

type mockedTransport struct {
	ret  []byte
	code int
}

func Test_preparePagedPOSets(t *testing.T) {
	type args struct {
		poMap   servicePOMapping
		svcList []string
		limit   int
	}
	tests := []struct {
		name  string
		args  args
		wantM []servicePOMapping
		wantQ []string
	}{
		{
			"empty",
			args{},
			[]servicePOMapping{},
			[]string{},
		},
		{
			"single service, single request",
			args{
				servicePOMapping{"aaa": []string{"123", "345"}},
				[]string{"aaa"},
				5000,
			},
			[]servicePOMapping{servicePOMapping{"aaa": []string{"123", "345"}}},
			[]string{"aaa,123,345"},
		},
		{
			"single service, split request",
			args{
				servicePOMapping{"aaa": []string{"123000000", "345000000", "567000000", "8910000000"}},
				[]string{"aaa"},
				25,
			},
			[]servicePOMapping{servicePOMapping{"aaa": []string{"123000000", "345000000", "567000000"}}, servicePOMapping{"aaa": []string{"8910000000"}}},
			[]string{"aaa,123000000,345000000,567000000", "aaa,8910000000"},
		},
		{
			"multi service, single request",
			args{
				servicePOMapping{"aaa": []string{"123", "345"}, "bbb": []string{"qwe", "rty"}},
				[]string{"aaa", "bbb"},
				5000,
			},
			[]servicePOMapping{servicePOMapping{"aaa": []string{"123", "345"}, "bbb": []string{"qwe", "rty"}}},
			[]string{"aaa,123,345:bbb,qwe,rty"},
		},
		{
			"multi service, split request",
			args{
				servicePOMapping{"aaa": []string{"123000000", "345000000"}, "bbb": []string{"567000000", "8910000000"}},
				[]string{"aaa", "bbb"},
				25,
			},
			[]servicePOMapping{servicePOMapping{"aaa": []string{"123000000", "345000000"}, "bbb": []string{"567000000"}}, servicePOMapping{"bbb": []string{"8910000000"}}},
			[]string{"aaa,123000000,345000000:bbb,567000000", "bbb,8910000000"},
		},
		{
			"multi service, split request, last item",
			args{
				servicePOMapping{"aaa": []string{"123000000", "345000000"}, "bbb": []string{"567000000", "8910000000"}},
				[]string{"aaa", "bbb"},
				20,
			},
			[]servicePOMapping{servicePOMapping{"aaa": []string{"123000000", "345000000"}}, servicePOMapping{"bbb": []string{"567000000", "8910000000"}}},
			[]string{"aaa,123000000,345000000", "bbb,567000000,8910000000"},
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			gotM, gotQ := preparePagedPOSets(tt.args.poMap, tt.args.svcList, tt.args.limit)
			assert.Equal(t, tt.wantQ, gotQ)
			assert.Equal(t, tt.wantM, gotM)
		})
	}
}

func Test_groupByService(t *testing.T) {
	tests := []struct {
		name   string
		poList []PermissionObject
		wantM  servicePOMapping
	}{
		{
			"empty",
			nil,
			servicePOMapping{},
		},
		{
			"single service",
			[]PermissionObject{{Service: "aaa", Name: "111"}, {Service: "aaa", Name: "123"}, {Service: "aaa", Name: "234"}, {Service: "aaa", Name: "321"}},
			servicePOMapping{"aaa": []string{"111", "123", "234", "321"}},
		},
		{
			"multi service",
			[]PermissionObject{{Service: "ccc", Name: "111"}, {Service: "aaa", Name: "123"}, {Service: "bbb", Name: "234"}, {Service: "aaa", Name: "321"}},
			servicePOMapping{"aaa": []string{"123", "321"}, "ccc": []string{"111"}, "bbb": []string{"234"}},
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			gotM := groupByService(tt.poList)
			assert.Equal(t, tt.wantM, gotM)
		})
	}
}

func Test_listService(t *testing.T) {
	tests := []struct {
		name  string
		poMap servicePOMapping
		wantL []string
	}{
		{
			"empty",
			nil,
			[]string{},
		},
		{
			"single service",
			servicePOMapping{"aaa": []string{"111", "123", "234", "321"}},
			[]string{"aaa"},
		},
		{
			"multi service",
			servicePOMapping{"aaa": []string{"123", "321"}, "ccc": []string{"111"}, "bbb": []string{"234"}},
			[]string{"aaa", "bbb", "ccc"},
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			gotL := listServices(tt.poMap)
			assert.Equal(t, tt.wantL, gotL)
		})
	}
}

func TestClient_buildPoSetQuery(t *testing.T) {
	type args struct {
		poSet string
		user  string
	}
	tests := []struct {
		name string
		o    Client
		args args
		want string
	}{
		{
			"no version",
			Client{application: "123", position: "pos1", uri: "http://abc.com"},
			args{
				poSet: "svc1,1,2,3:svc2,a,b",
				user:  "uuid123",
			},
			"unknown odps version",
		},
		{
			"legacy ODPS",
			Client{version: odpsLegacy, application: "123", position: "pos1", uri: "http://abc.com"},
			args{
				poSet: "svc1,1,2,3:svc2,a,b",
				user:  "uuid123",
			},
			"http://abc.com/command=poCheck&application=123&poset=svc1,1,2,3:svc2,a,b&position=pos1&user=uuid123",
		},
		{
			"ODPS3.0",
			Client{version: odpsV3, application: "123", position: "pos1", uri: "http://abc.com"},
			args{
				poSet: "svc1,1,2,3:svc2,a,b",
				user:  "uuid123",
			},
			"http://abc.com/command=poCheck&application=123&poset=svc1%2C1%2C2%2C3%3Asvc2%2Ca%2Cb&position=pos1&user=uuid123",
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			got := tt.o.buildPoSetQuery(tt.args.poSet, tt.args.user)
			assert.Equal(t, tt.want, got)
		})
	}
}

func Test_extractPermsMulti(t *testing.T) {
	type args struct {
		poMap servicePOMapping
		body  []byte
	}
	tests := []struct {
		name string
		args args
		want []PermissionCheckResult
		err  string
	}{
		{
			"empty",
			args{},
			nil,
			"SUCCESS marker not found, got: ",
		},
		{
			"bad result",
			args{
				servicePOMapping{},
				[]byte("DENIED:abcd, unknown to system."),
			},
			nil,
			"SUCCESS marker not found, got: DENIED:abcd, unknown to system.",
		},
		{
			"unknown service",
			args{
				servicePOMapping{"svc2": []string{}, "svc1": []string{}},
				[]byte("SUCCESS:\nAPI_ACCESS_CONTROL,1,0\nNEWS,0"),
			},
			nil,
			"incorrect service in a response, expect one of [svc1 svc2], got API_ACCESS_CONTROL: SUCCESS:\nAPI_ACCESS_CONTROL,1,0\nNEWS,0",
		},
		{
			"count mismatch",
			args{
				servicePOMapping{"svc1": []string{"123", "qwerty", "321"}},
				[]byte("SUCCESS:\nsvc1,1,0,1,?"),
			},
			nil,
			"incorrect number of PO in a response for service svc1, expect 3, got 4: svc1,1,0,1,?",
		},
		{
			"single service",
			args{
				servicePOMapping{"svc1": []string{"123", "qwerty", "321", "bbb"}},
				[]byte("SUCCESS:\nsvc1,1,0,1,?"),
			},
			[]PermissionCheckResult{
				PermissionCheckResult{PermissionObject: PermissionObject{Name: "123", Service: "svc1"}, Result: 1},
				PermissionCheckResult{PermissionObject: PermissionObject{Name: "qwerty", Service: "svc1"}, Result: 0},
				PermissionCheckResult{PermissionObject: PermissionObject{Name: "321", Service: "svc1"}, Result: 1},
				PermissionCheckResult{PermissionObject: PermissionObject{Name: "bbb", Service: "svc1"}, Result: -1},
			},
			"",
		},
		{
			"two services",
			args{
				servicePOMapping{"svc1": []string{"123", "qwerty", "321", "bbb"}, "svc2": []string{"123", "aaa"}},
				[]byte("SUCCESS:\nsvc1,1,0,1,?\nsvc2,0,1"),
			},
			[]PermissionCheckResult{
				PermissionCheckResult{PermissionObject: PermissionObject{Name: "123", Service: "svc1"}, Result: 1},
				PermissionCheckResult{PermissionObject: PermissionObject{Name: "qwerty", Service: "svc1"}, Result: 0},
				PermissionCheckResult{PermissionObject: PermissionObject{Name: "321", Service: "svc1"}, Result: 1},
				PermissionCheckResult{PermissionObject: PermissionObject{Name: "bbb", Service: "svc1"}, Result: -1},
				PermissionCheckResult{PermissionObject: PermissionObject{Name: "123", Service: "svc2"}, Result: 0},
				PermissionCheckResult{PermissionObject: PermissionObject{Name: "aaa", Service: "svc2"}, Result: 1},
			},
			"",
		},
		{
			"three services",
			args{
				servicePOMapping{"svc1": []string{"123", "qwerty", "321", "bbb"}, "svc2": []string{"123", "aaa"}, "svc3": []string{"qqq"}},
				[]byte("SUCCESS:\nsvc3,1\nsvc1,1,0,1,?\nsvc2,0,1"),
			},
			[]PermissionCheckResult{
				PermissionCheckResult{PermissionObject: PermissionObject{Name: "qqq", Service: "svc3"}, Result: 1},
				PermissionCheckResult{PermissionObject: PermissionObject{Name: "123", Service: "svc1"}, Result: 1},
				PermissionCheckResult{PermissionObject: PermissionObject{Name: "qwerty", Service: "svc1"}, Result: 0},
				PermissionCheckResult{PermissionObject: PermissionObject{Name: "321", Service: "svc1"}, Result: 1},
				PermissionCheckResult{PermissionObject: PermissionObject{Name: "bbb", Service: "svc1"}, Result: -1},
				PermissionCheckResult{PermissionObject: PermissionObject{Name: "123", Service: "svc2"}, Result: 0},
				PermissionCheckResult{PermissionObject: PermissionObject{Name: "aaa", Service: "svc2"}, Result: 1},
			},
			"",
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			got, err := extractPermsMulti(tt.args.poMap, tt.args.body)
			if err != nil || tt.err != "" {
				assert.EqualError(t, err, tt.err)
				return
			}
			assert.Equal(t, tt.want, got)
		})
	}
}

func Test_parseSingleServiceLine(t *testing.T) {
	type args struct {
		service  string
		poList   []string
		permLine [][]byte
	}
	tests := []struct {
		name string
		args args
		want []PermissionCheckResult
		err  string
	}{
		{
			"empty",
			args{},
			nil,
			"no permissions returned in the response for service ",
		},
		{
			"mismatch count",
			args{
				"svc1",
				[]string{"123", "234"},
				[][]byte{[]byte("1")},
			},
			nil,
			"incorrect number of PO in a response for service svc1, expect 2, got 1",
		},
		{
			"unexpected value",
			args{
				"svc1",
				[]string{"123", "234", "qwerty", "111"},
				[][]byte{[]byte("1"), []byte("q"), []byte("?"), []byte("0")},
			},
			nil,
			"invalid poCheck result for service svc1 at position 1, got q",
		},
		{
			"ok",
			args{
				"svc1",
				[]string{"123", "234", "qwerty", "111"},
				[][]byte{[]byte("1"), []byte("1"), []byte("?"), []byte("0")},
			},
			[]PermissionCheckResult{
				PermissionCheckResult{PermissionObject: PermissionObject{Name: "123", Service: "svc1"}, Result: 1},
				PermissionCheckResult{PermissionObject: PermissionObject{Name: "234", Service: "svc1"}, Result: 1},
				PermissionCheckResult{PermissionObject: PermissionObject{Name: "qwerty", Service: "svc1"}, Result: -1},
				PermissionCheckResult{PermissionObject: PermissionObject{Name: "111", Service: "svc1"}, Result: 0},
			},
			"",
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			got, err := parseSingleServiceLine(tt.args.service, tt.args.poList, tt.args.permLine)
			if err != nil || tt.err != "" {
				assert.EqualError(t, err, tt.err)
				return
			}
			assert.Equal(t, tt.want, got)
		})
	}
}

func TestClient_GetUsrMultiSvcPOs(t *testing.T) {
	type args struct {
		user   string
		poList []PermissionObject
	}
	tests := []struct {
		name    string
		version string
		args    args
		f       func(w http.ResponseWriter, r *http.Request)
		want    []PermissionCheckResult
		err     error
		errStr  string
	}{
		{
			"empty",
			"v3",
			args{},
			func(w http.ResponseWriter, r *http.Request) {},
			[]PermissionCheckResult{},
			nil,
			"",
		},
		{
			"ok v3",
			"v3",
			args{
				"user1",
				[]PermissionObject{
					{Service: "svc1", Name: "aaa"},
					{Service: "svc2", Name: "aaa"},
					{Service: "svc1", Name: "bbb"},
				},
			},
			func(w http.ResponseWriter, r *http.Request) {
				if !strings.HasSuffix(r.URL.RawPath, "/command=poCheck&application=256&poset=svc1%2Caaa%2Cbbb%3Asvc2%2Caaa&position=pos1&user=user1") {
					w.WriteHeader(http.StatusBadRequest)
					w.Write([]byte("bad request"))
					return
				}
				w.Write([]byte("SUCCESS:\nsvc1,1,0\nsvc2,1"))
			},
			[]PermissionCheckResult{
				{PermissionObject: PermissionObject{Service: "svc1", Name: "aaa"}, Result: 1},
				{PermissionObject: PermissionObject{Service: "svc1", Name: "bbb"}, Result: 0},
				{PermissionObject: PermissionObject{Service: "svc2", Name: "aaa"}, Result: 1},
			},
			nil,
			"",
		},
		{
			"ok v2",
			"v2",
			args{
				"user1",
				[]PermissionObject{
					{Service: "svc1", Name: "aaa"},
					{Service: "svc2", Name: "aaa"},
					{Service: "svc1", Name: "bbb"},
				},
			},
			func(w http.ResponseWriter, r *http.Request) {
				if !strings.HasSuffix(r.URL.Path, "/command=poCheck&application=256&poset=svc1,aaa,bbb:svc2,aaa&position=pos1&user=user1") {
					w.WriteHeader(http.StatusBadRequest)
					w.Write([]byte(r.URL.Path))
					return
				}
				w.Write([]byte("SUCCESS:\nsvc1,1,0\nsvc2,1"))
			},
			[]PermissionCheckResult{
				{PermissionObject: PermissionObject{Service: "svc1", Name: "aaa"}, Result: 1},
				{PermissionObject: PermissionObject{Service: "svc1", Name: "bbb"}, Result: 0},
				{PermissionObject: PermissionObject{Service: "svc2", Name: "aaa"}, Result: 1},
			},
			nil,
			"",
		},
		{
			"data error",
			"v3",
			args{
				"user1",
				[]PermissionObject{
					{Service: "svc1", Name: "aaa"},
				},
			},
			func(w http.ResponseWriter, r *http.Request) {
				w.Write([]byte("SUCCESS:\nsvc1,1,0"))
			},
			[]PermissionCheckResult{},
			ErrorData,
			"data error:incorrect number of PO in a response for service svc1, expect 1, got 2: svc1,1,0",
		},
		{
			"communication error",
			"v3",
			args{
				"user1",
				[]PermissionObject{
					{Service: "svc1", Name: "aaa"},
				},
			},
			func(w http.ResponseWriter, r *http.Request) {
				time.Sleep(time.Millisecond * 50)
				w.Write([]byte("SUCCESS:\nsvc1,1"))
			},
			[]PermissionCheckResult{},
			ErrorCommunication,
			"(Client.Timeout exceeded while awaiting headers)",
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			svc := httptest.NewServer(http.HandlerFunc(tt.f))
			defer svc.Close()
			cli, err := New(&http.Client{Timeout: time.Millisecond * 10}, tt.version, svc.URL, "pos1", "256")
			assert.NoError(t, err)
			got, err := cli.GetUsrMultiSvcPOs(context.Background(), tt.args.user, tt.args.poList)
			if err != nil || tt.err != nil {
				assert.ErrorIs(t, err, tt.err)
				assert.ErrorContains(t, err, tt.errStr)
				return
			}
			assert.Equal(t, tt.want, got)
		})
	}
}
