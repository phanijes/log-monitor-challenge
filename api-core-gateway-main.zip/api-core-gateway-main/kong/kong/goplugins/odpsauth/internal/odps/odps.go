// This package was copied from RDP API Gateway code base
// It contains some backward compatibility features and calls we don't need in Kong at the moment.
// TODO: clean-up and refactor unneeded features once we are more familiar with Kong AuthN requirements.
package odps

import (
	"bytes"
	"context"
	"errors"
	"fmt"
	"io"
	"net/http"
	"net/url"
	"sort"
	"strings"
)

// ODPS struct handle call to ODPS
type Client struct {
	// Basic structure to handle calls to ODPS
	httpclient    *http.Client
	uri           string
	position      string
	application   string
	version       odpsEndpointVersion
	multiSvcLimit int
}

// PoResult - Used to hold the response from ODPS
type (
	PoResult            int
	command             int32
	odpsEndpointVersion int32
)

const (
	// PoUnknown - Response from ODPS returns unknown PO code
	PoUnknown = iota - 1
	// PoNone - Response from ODPS is no entitlement for this client and PO
	PoNone
	// PoExists - Response from ODPS has entitlement for this client and PO
	PoExists
)

const (
	commandCheck command = iota + 1
	commandAll
)

const (
	odpsUnknown odpsEndpointVersion = iota
	odpsLegacy
	odpsV3
	odpsAuto
)

const (
	ODPSVersionAuto = "auto"
	ODPSVersion2    = "v2"
	ODPSVersion3    = "v3"
)

const defaulODPSVersion = odpsLegacy

type urlCommandParams struct {
	Service  string
	User     string
	Position string
	AppID    string
	URI      string
	POList   []string
	Type     command
	Version  odpsEndpointVersion
}

func (c command) String() string {
	knownCommands := map[command]string{
		commandAll:   "subscriptionList",
		commandCheck: "poCheck",
	}
	w := knownCommands[c] // if not found retrun ""
	return w
}

func trimCR(b []byte) []byte {
	return bytes.TrimSuffix(b, []byte("\r"))
}

func extractPermsSimple(service string, body []byte) ([]PoResult, error) {
	lines := bytes.Split(body, []byte("\n"))
	if len(lines) < 2 {
		return nil, fmt.Errorf("SUCCESS marker not found, got %s", lines[0])
	}
	if !bytes.Equal(trimCR(lines[0]), []byte("SUCCESS:")) {
		return nil, fmt.Errorf("SUCCESS marker not found, got %s", body)
	}
	permLine := bytes.Split(trimCR(lines[1]), []byte(","))
	if !bytes.Equal(permLine[0], []byte(service)) {
		return nil, fmt.Errorf("incorrect service in a response, expect %s, got %s: %s", service, permLine[0], body)
	}
	if len(permLine) == 1 {
		return nil, fmt.Errorf("no permissions returned in the response %s", body)
	}
	perms := make([]PoResult, len(permLine)-1)
	for i, v := range permLine[1:] {
		switch {
		case len(v) == 1 && v[0] == '1':
			perms[i] = PoExists
		case len(v) == 1 && v[0] == '?':
			perms[i] = PoUnknown
		case len(v) == 1 && v[0] == '0':
			perms[i] = PoNone
		default:
			return nil, fmt.Errorf("invalid poCheck result at position %d: %s", i, body)
		}
	}
	return perms, nil
}

func New(httpclient *http.Client, version, uri, position, appID string) (Client, error) {
	versions := map[string]odpsEndpointVersion{
		ODPSVersion2:    odpsLegacy,
		ODPSVersion3:    odpsV3,
		ODPSVersionAuto: defaulODPSVersion,
		"":              defaulODPSVersion,
	}
	v, ok := versions[version]
	if !ok {
		return Client{}, errors.New("unsuported version " + version)
	}
	return Client{
		httpclient:    httpclient,
		uri:           uri,
		position:      position,
		application:   appID,
		version:       v,
		multiSvcLimit: queryLenLimit,
	}, nil
}

// Deprecated: use New() constructor with versioning support.
func NewClient(httpclient *http.Client, uri string, position string, application string) Client {
	return Client{httpclient, uri, position, application, defaulODPSVersion, queryLenLimit}
}

func (o Client) WithLimit(limit int) Client {
	o.multiSvcLimit = limit
	return o
}

func callODPS(ctx context.Context, url string, httpclient *http.Client) ([]byte, error) {
	req, err := http.NewRequestWithContext(ctx, http.MethodGet, url, nil)
	if err != nil {
		return nil, err
	}
	response, err := httpclient.Do(req)
	if err != nil {
		return nil, err
	}
	defer response.Body.Close()
	responsebody, err := io.ReadAll(response.Body)
	if err != nil {
		return nil, err
	}
	return responsebody, nil
}

// BuildRaw replicates older behavior. May be safetly removed after confirmation on encoded approach
func (cmd urlCommandParams) buildRaw() (string, error) {
	cmdStr := cmd.Type.String()
	if cmdStr == "" {
		return "", fmt.Errorf("unknown command %d", int32(cmd.Type))
	}
	parts := make([]string, 0)
	addPart := func(k, v string) {
		parts = append(parts, fmt.Sprintf("%s=%s", k, v))
	}
	addPart("command", cmdStr)
	addPart("user", cmd.User)
	addPart("position", cmd.Position)
	addPart("application", cmd.AppID)
	switch cmd.Type {
	case commandCheck:
		addPart("poset", fmt.Sprintf("%s,%s", cmd.Service, strings.Join(cmd.POList, ",")))
	case commandAll:
		addPart("service", cmd.Service)
	}
	command := fmt.Sprintf("%s/%s", cmd.URI, strings.Join(parts, "&"))
	return command, nil
}

func (cmd urlCommandParams) buildEncoded() (string, error) {
	cmdStr := cmd.Type.String()
	if cmdStr == "" {
		return "", fmt.Errorf("unknown command %d", int32(cmd.Type))
	}
	u := url.Values{}
	switch cmd.Type {
	case commandCheck:
		u.Add("poset", fmt.Sprintf("%s,%s", cmd.Service, strings.Join(cmd.POList, ",")))
	case commandAll:
		u.Add("service", cmd.Service)
	}
	u.Add("application", cmd.AppID)
	u.Add("position", cmd.Position)
	u.Add("user", cmd.User)
	command := fmt.Sprintf("%s/command=%s&%s", cmd.URI, cmdStr, u.Encode())
	return command, nil
}

func (cmd urlCommandParams) Build() (string, error) {
	switch cmd.Version {
	case odpsLegacy:
		return cmd.buildRaw()
	case odpsV3:
		return cmd.buildEncoded()
	}
	return "", errors.New("unknown odps version")
}

// GetUsrSvcPOs - Get the POs associated with a user for a service
func (o Client) GetUsrSvcPOs(ctx context.Context, service, user string, polist []string) ([]PoResult, error) {
	command, err := urlCommandParams{
		Type:     commandCheck,
		POList:   polist,
		Service:  service,
		User:     user,
		Position: o.position,
		AppID:    o.application,
		URI:      o.uri,
		Version:  o.version,
	}.Build()
	if err != nil {
		return nil, err
	}
	responsebody, err := callODPS(ctx, command, o.httpclient)
	if err != nil {
		return nil, err
	}

	poResults, err := extractPermsSimple(service, responsebody)
	if err != nil {
		return nil, err
	}
	return poResults, nil
}

func (o Client) GetAllPOs(ctx context.Context, service, user string) (map[string]struct{}, error) {
	command, err := urlCommandParams{
		Type:     commandAll,
		User:     user,
		Service:  service,
		Position: o.position,
		AppID:    o.application,
		URI:      o.uri,
		Version:  o.version,
	}.Build()
	if err != nil {
		return nil, err
	}
	responsebody, err := callODPS(ctx, command, o.httpclient)
	if err != nil {
		return nil, err
	}

	result, err := parseODPSResponse(string(responsebody))
	if err != nil {
		return nil, err
	}
	return result, nil
}

func parseODPSResponse(odpsresult string) (map[string]struct{}, error) {
	rawList := strings.Split(odpsresult, "\n")
	if len(rawList) < 2 || !strings.Contains(rawList[0], "SUCCESS") {
		return nil, fmt.Errorf("unexpected result of ODSP call: %s", string(odpsresult))
	}
	result := make(map[string]struct{})
	for i := 1; i < len(rawList); i++ {
		if rawList[i] == "" {
			continue
		}
		parts := strings.Split(strings.Trim(strings.TrimSpace(rawList[i]), "'"), "=")
		if len(parts) != 2 {
			return nil, fmt.Errorf("unexpected PO: %s", rawList[i])
		}
		result[parts[1]] = struct{}{}
	}
	return result, nil
}

type servicePOMapping map[string][]string

type PermissionObject struct {
	Service string `json:"s"`
	Name    string `json:"n"`
}

type PermissionCheckResult struct {
	PermissionObject `json:"po"`
	Result           int `json:"r"`
}

var (
	ErrorCommunication = errors.New("communication error")
	ErrorData          = errors.New("data error")
)

// GetUsrSvcPOs - Get the POs associated with a user for a service
func (o Client) GetUsrMultiSvcPOs(ctx context.Context, user string, poList []PermissionObject) ([]PermissionCheckResult, error) {
	poMap := groupByService(poList)
	svcList := listServices(poMap)
	subMaps, poSets := preparePagedPOSets(poMap, svcList, o.multiSvcLimit)
	results := make([]PermissionCheckResult, 0, len(poList))
	for i := 0; i < len(poSets); i++ {
		req := o.buildPoSetQuery(poSets[i], user)
		responsebody, err := callODPS(ctx, req, o.httpclient)
		if err != nil {
			return nil, fmt.Errorf("%w:%w", ErrorCommunication, err)
		}
		poResults, err := extractPermsMulti(subMaps[i], responsebody)
		if err != nil {
			return nil, fmt.Errorf("%w:%w", ErrorData, err)
		}
		results = append(results, poResults...)
	}
	return results, nil
}

func (o Client) buildPoSetQuery(poSet, user string) string {
	switch o.version {
	case odpsLegacy:
		return o.buildPoSetRaw(poSet, user)
	case odpsV3:
		return o.buildPoSetEncoded(poSet, user)
	}
	return "unknown odps version"
}

func (o Client) buildPoSetEncoded(poSet, user string) string {
	u := url.Values{}
	u.Add("application", o.application)
	u.Add("poset", poSet)
	u.Add("position", o.position)
	u.Add("user", user)
	return fmt.Sprintf("%s/command=poCheck&%s", o.uri, u.Encode())
}

func (o Client) buildPoSetRaw(poSet, user string) string {
	parts := make([]string, 0)
	addPart := func(k, v string) {
		parts = append(parts, fmt.Sprintf("%s=%s", k, v))
	}
	addPart("application", o.application)
	addPart("poset", poSet)
	addPart("position", o.position)
	addPart("user", user)
	return fmt.Sprintf("%s/command=poCheck&%s", o.uri, strings.Join(parts, "&"))
}

func extractPermsMulti(poMap servicePOMapping, body []byte) ([]PermissionCheckResult, error) {
	lines := bytes.Split(body, []byte("\n"))
	if len(lines) < 2 || !bytes.Equal(trimCR(lines[0]), []byte("SUCCESS:")) {
		return nil, fmt.Errorf("SUCCESS marker not found, got: %s", body)
	}

	perms := []PermissionCheckResult{}
	for i := 1; i < len(lines); i++ {
		permLine := bytes.Split(trimCR(lines[i]), []byte(","))
		service := string(permLine[0])
		poList, ok := poMap[service]
		if !ok {
			return nil, fmt.Errorf("incorrect service in a response, expect one of [%s], got %s: %s", strings.Join(listServices(poMap), " "), service, body)
		}
		p, err := parseSingleServiceLine(service, poList, permLine[1:])
		if err != nil {
			return nil, fmt.Errorf("%s: %s", err, lines[i])
		}
		perms = append(perms, p...)
	}
	return perms, nil
}

func parseSingleServiceLine(service string, poList []string, permLine [][]byte) ([]PermissionCheckResult, error) {
	if len(permLine) == 0 {
		return nil, fmt.Errorf("no permissions returned in the response for service %s", service)
	}
	if len(poList) != len(permLine) {
		return nil, fmt.Errorf("incorrect number of PO in a response for service %s, expect %d, got %d", service, len(poList), len(permLine))
	}
	perms := make([]PermissionCheckResult, 0, len(poList))
	for j, v := range permLine {
		po := PermissionCheckResult{PermissionObject: PermissionObject{Service: service, Name: poList[j]}}
		switch {
		case len(v) == 1 && v[0] == '1':
			po.Result = PoExists
		case len(v) == 1 && v[0] == '?':
			po.Result = PoUnknown
		case len(v) == 1 && v[0] == '0':
			po.Result = PoNone
		default:
			return nil, fmt.Errorf("invalid poCheck result for service %s at position %d, got %s", service, j, v)
		}
		perms = append(perms, po)
	}
	return perms, nil
}

// groupByService groups PO per service
func groupByService(poList []PermissionObject) servicePOMapping {
	poMap := make(servicePOMapping)
	for _, po := range poList {
		if _, ok := poMap[po.Service]; !ok {
			poMap[po.Service] = []string{}
		}
		poMap[po.Service] = append(poMap[po.Service], po.Name)
	}
	return poMap
}

// listServices returns sorted list of all services in a map (keys)
func listServices(poMap servicePOMapping) []string {
	svcList := make([]string, 0, len(poMap))
	for k := range poMap {
		svcList = append(svcList, k)
	}
	sort.Strings(svcList)
	return svcList
}

const queryLenLimit = 7000

// preparePagedPOSets prepares 'poset' parameter by ensuring that it's length fits the limit.
// Note: the limit is approximate, the actual poset part length could be up to svc+single_po+1 longer
func preparePagedPOSets(poMap servicePOMapping, svcList []string, limit int) ([]servicePOMapping, []string) {
	subMaps := []servicePOMapping{}
	queries := []string{}
	counter := 0
	query := new(strings.Builder)
	subM := make(servicePOMapping)
	for _, svc := range svcList {
		poList := poMap[svc]
		if counter != 0 {
			query.WriteString(":")
			counter += 1
		}
		query.WriteString(svc)
		counter += len(svc)
		l := make([]string, 0, len(poList))
		for i, po := range poList {
			query.WriteString(",")
			query.WriteString(po)
			counter += len(po) + 1
			l = append(l, po)
			if limit < counter {
				subM[svc] = l
				subMaps = append(subMaps, subM)
				queries = append(queries, query.String())
				subM = make(servicePOMapping)
				counter = 0
				query.Reset()
				l = make([]string, 0, len(poList)-i)
				if len(poList) != i+1 {
					query.WriteString(svc)
					counter += len(svc)
				}
			}
		}
		if len(l) > 0 {
			subM[svc] = l
		}
	}
	if query.Len() > 0 {
		subMaps = append(subMaps, subM)
		queries = append(queries, query.String())
	}
	return subMaps, queries
}
