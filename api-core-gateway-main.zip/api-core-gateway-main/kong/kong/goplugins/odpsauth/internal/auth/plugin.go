package auth

import (
	"common/cache/base"
	"common/configuration"
	"common/log"
	"common/plugin"
	"sync"
)

const (
	position = "127.0.0.1/net"
)

type ODPSSettings struct {
	URL   string `json:"url" schema:"required"`
	AppId string `json:"appid" schema:"required"`
	// cannot use normal structure due to Kong UI limitations
	// array is OR, each string value is comma-separated AND list of service:po pairs
	// e.g. ["svc1:po1,svc1:po2","svc2:po1"] - (po1 AND po2 from svc1) OR (po1 from svc2)
	POList []string `json:"required_permissions"`
}

type UpstreamSettings struct {
	POHeader string `json:"po_header" schema:"default=ODPS-PO"`
}

type ODPSAuthPlugin struct {
	ODPSSettings          ODPSSettings         `json:"odps"`
	CacheSettings         plugin.CacheSettings `json:"cache"`
	UpstreamSettings      UpstreamSettings     `json:"upstream"`
	ForbiddenErrorMessage string               `json:"forbidden_error_message"`
	LogLevel              string               `json:"log_level" schema:"default=info"`
	//Non-configuration fields below
	once    *sync.Once
	logger  log.Logger
	cache   base.Cache
	odpsCli odpsClient
	vault   configuration.Vault
}

func New() interface{} {
	return &ODPSAuthPlugin{once: new(sync.Once)}
}

func init() {
	plugin.InitGlobalCache(plugin.GLOBAL_PLUGIN_SETTINGS)
}

func (p *ODPSAuthPlugin) GetSchemaFields() ([]map[string]interface{}, map[string]interface{}) {
	additionalFields := []map[string]interface{}{
		{"consumer": plugin.SchemaNoConsumer},
		{"protocols": plugin.SchemaProtocolsHttp},
	}
	checks := []map[string]interface{}{}
	checks = append(checks, plugin.SchemaCacheEntityChecks...)
	additionalConfigFields := map[string]interface{}{"entity_checks": checks}
	return additionalFields, additionalConfigFields
}
