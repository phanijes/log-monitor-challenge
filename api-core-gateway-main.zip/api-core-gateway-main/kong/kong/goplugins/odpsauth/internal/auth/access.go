package auth

import (
	"common/cache"
	"common/configuration"
	"common/log"
	"common/plugin"
	"common/response"
	"context"
	"errors"
	"fmt"
	"net/http"
	"odpsauth/internal/odps"
	"sort"
	"strings"
	"time"

	"github.com/Kong/go-pdk"
)

var client = &http.Client{Timeout: 5 * time.Second}

type odpsClient interface {
	GetUsrMultiSvcPOs(ctx context.Context, user string, poList []odps.PermissionObject) ([]odps.PermissionCheckResult, error)
}

func (p *ODPSAuthPlugin) Init() {
	p.logger = log.New(p.LogLevel)
	p.logger.Info("initializing plugin", "logLevel", p.LogLevel)

	p.vault = configuration.NewSimpleVault()
	p.cache = plugin.InitCache(p.vault, p.CacheSettings, p.logger)

	cli, err := odps.New(client, odps.ODPSVersion3, p.ODPSSettings.URL, position, p.ODPSSettings.AppId)
	if err != nil {
		p.logger.Fatal("failed to init ODPS client", "err", err)
		return
	}
	p.odpsCli = cli
}

// timeout for request processing to set in the context
// 5 seconds is more than enough
const requestTimeoutSeconds = 5

func (p *ODPSAuthPlugin) Access(kong *pdk.PDK) {
	p.once.Do(p.Init)
	ctx, cancel := context.WithTimeout(context.Background(), time.Duration(time.Second*requestTimeoutSeconds))
	defer cancel()
	ctx = plugin.AddCorrelationIdToLogger(ctx, p.logger, kong.Request)
	err := p.access(ctx, kong)
	if err != nil {
		p.reportAuthError(ctx, kong, err)
	}
}

func (p *ODPSAuthPlugin) access(ctx context.Context, kong *pdk.PDK) error {
	uuid, err := p.getUuid(ctx, kong)
	if err != nil {
		return err
	}
	perm, err := p.parsePermissions(ctx, p.ODPSSettings.POList)
	if err != nil {
		return err
	}
	result, err := p.getODPS(ctx, uuid, perm)
	if err != nil {
		return err
	}
	err = p.checkPoResult(ctx, perm, result, uuid)
	if err != nil {
		return err
	}

	if err := p.addHeaders(ctx, kong.ServiceRequest, result); err != nil {
		log.FromContext(ctx).Error("failed to set upstream headers", "err", err)
	}

	log.FromContext(ctx).Info("authorization success", "uuid", uuid)
	return nil
}

type requestHeaderSetter interface {
	SetHeaders(headers map[string][]string) error
	ClearHeader(name string) error
}

func (p *ODPSAuthPlugin) addHeaders(ctx context.Context, kongRequest requestHeaderSetter, userPOs []odps.PermissionCheckResult) error {
	headers := http.Header{}
	if p.UpstreamSettings.POHeader != "" {
		poList := strings.Builder{}
		for _, po := range userPOs {
			if po.Result == odps.PoExists {
				poList.WriteString(po.PermissionObject.Service + ":" + po.PermissionObject.Name + ",")
			}
		}
		poStr := poList.String()
		if poStr != "" {
			poStr = poStr[:len(poStr)-1]
		}
		headers.Add(p.UpstreamSettings.POHeader, poStr)
	}
	return kongRequest.SetHeaders(headers)
}

func (p *ODPSAuthPlugin) getUuid(ctx context.Context, kong *pdk.PDK) (string, error) {
	cred, err := kong.Client.GetCredential()
	if err != nil {
		log.FromContext(ctx).Error("error getting authenticated user credentials", "err", err)
		return "", response.NewErrorResponse(http.StatusInternalServerError, response.InternalServerError)
	}
	if cred.Id == "" {
		log.FromContext(ctx).Error("no authenticated user found")
		return "", p.ForbiddenError("Unauthorized")
	}
	return cred.Id, nil
}

func (p *ODPSAuthPlugin) checkPoResult(ctx context.Context, requiredPermissions ODPSPermissions, userPOs []odps.PermissionCheckResult, uuid string) error {
	poLookup := map[odps.PermissionObject]bool{}
	for _, po := range userPOs {
		if po.Result == odps.PoExists {
			poLookup[po.PermissionObject] = true
		}
	}

	if ok, missingPOs := p.hasPermissions(requiredPermissions, poLookup); !ok {
		log.FromContext(ctx).Info("authorization failure: missing PO", "uuid", uuid, "missingPo", missingPOs)
		//TODO: do we need to expose missing PO here? Better string representation?
		return p.ForbiddenError(fmt.Sprintf("Forbidden. Missing PO: %v", missingPOs))
	}

	return nil
}

func (p *ODPSAuthPlugin) hasPermissions(requiredPermissions ODPSPermissions, userPOs map[odps.PermissionObject]bool) (bool, []odps.PermissionObject) {
	//in case operation POs are empty - no access restriction
	if len(requiredPermissions.POs) == 0 {
		return true, nil
	}
	missingPOs := []odps.PermissionObject{}
	//outer slice is joined as OR, so any success is a go.
OUTER:
	for _, andBlock := range requiredPermissions.POs {
		//inner as AND, so any failure is stopper for current block.
		for _, po := range andBlock {
			if !userPOs[po] {
				missingPOs = append(missingPOs, po)
				continue OUTER
			}
		}
		//either no POs - everyone access, or all POs matched
		return true, nil
	}
	return false, missingPOs
}

type ODPSPermissions struct {
	//top-level slice is OR, internal one is AND
	//openapi security section compatible
	POs [][]odps.PermissionObject
}

func (perm *ODPSPermissions) Flatten() []odps.PermissionObject {
	result := []odps.PermissionObject{}
	for _, andBlock := range perm.POs {
		result = append(result, andBlock...)
	}
	result = deDuplicatePO(result)
	sort.Slice(result, func(i, j int) bool {
		if result[i].Service == result[j].Service {
			return result[i].Name < result[j].Name
		}
		return result[i].Service < result[j].Service
	})
	return result
}

func deDuplicatePO(perms []odps.PermissionObject) []odps.PermissionObject {
	m := map[odps.PermissionObject]struct{}{}
	for _, v := range perms {
		m[v] = struct{}{}
	}
	newPerms := []odps.PermissionObject{}
	for v := range m {
		newPerms = append(newPerms, v)
	}
	return newPerms
}

func (p *ODPSAuthPlugin) parsePermissions(ctx context.Context, cfg []string) (ODPSPermissions, error) {
	perm, err := p.doParsePermissions(cfg)
	if err != nil {
		log.FromContext(ctx).Error("failed to parse plugin PO configuration")
		return ODPSPermissions{}, response.NewErrorResponse(http.StatusInternalServerError, response.InternalServerError)
	}
	return perm, nil
}

func (p *ODPSAuthPlugin) doParsePermissions(cfg []string) (ODPSPermissions, error) {
	orPerms := [][]odps.PermissionObject{}
	for _, andBlock := range cfg {
		andPerms, err := p.parseAndBlockPermissions(strings.TrimSpace(andBlock))
		if err != nil {
			return ODPSPermissions{}, err
		}
		orPerms = append(orPerms, andPerms)
	}
	return ODPSPermissions{POs: orPerms}, nil
}

func (p *ODPSAuthPlugin) parseAndBlockPermissions(andBlock string) ([]odps.PermissionObject, error) {
	andPerms := []odps.PermissionObject{}
	andParts := strings.Split(andBlock, ",")
	for _, permStr := range andParts {
		po, err := p.parsePermissionString(strings.TrimSpace(permStr))
		if err != nil {
			return nil, err
		}
		andPerms = append(andPerms, po)
	}
	return andPerms, nil
}

func (p *ODPSAuthPlugin) parsePermissionString(permStr string) (odps.PermissionObject, error) {
	parts := strings.Split(permStr, ":")
	if len(parts) != 2 {
		return odps.PermissionObject{}, fmt.Errorf("unexpected format of PO, expected 'service:po', got %s", permStr)
	}
	return odps.PermissionObject{Service: parts[0], Name: parts[1]}, nil
}

func (p *ODPSAuthPlugin) getODPS(ctx context.Context, uuid string, permissions ODPSPermissions) ([]odps.PermissionCheckResult, error) {
	pos := permissions.Flatten()
	if p.CacheSettings.Enabled {
		result := cache.GetFromCache[[]odps.PermissionCheckResult](ctx, p.cache, makeCacheKey(uuid, pos))
		if result != nil {
			return *result, nil
		}
	}
	result, err := p.requestODPS(ctx, uuid, pos)
	if err != nil {
		return nil, err
	}
	if p.CacheSettings.Enabled {
		cache.UpdateInCache(ctx, p.cache, makeCacheKey(uuid, pos), result, cacheTTL)
	}
	return result, nil
}

const (
	cacheKeyPrefix    = "ODPS"
	cacheKeySeparator = "\x00"
	cacheTTL          = 3600
)

func makeCacheKey(uuid string, pos []odps.PermissionObject) string {
	poStr := ""
	for _, po := range pos {
		poStr += po.Service + ":" + po.Name + ","
	}
	return cacheKeyPrefix + cacheKeySeparator + uuid + cacheKeySeparator + poStr
}

func (p *ODPSAuthPlugin) requestODPS(ctx context.Context, uuid string, pos []odps.PermissionObject) ([]odps.PermissionCheckResult, error) {
	result, err := p.odpsCli.GetUsrMultiSvcPOs(context.Background(), uuid, pos)
	if err != nil {
		log.FromContext(ctx).Error("failed to check permissions via ODPS", "err", err)
		switch {
		case errors.Is(err, odps.ErrorData):
			return nil, p.ForbiddenError("forbidden")
		case errors.Is(err, odps.ErrorCommunication):
			return nil, response.NewErrorResponse(http.StatusBadGateway, "authorization failed")
		}
		return nil, response.NewErrorResponse(http.StatusInternalServerError, "authorization failed")
	}
	return result, nil
}

func (p *ODPSAuthPlugin) ForbiddenError(msg string) error {
	if p.ForbiddenErrorMessage != "" {
		msg = p.ForbiddenErrorMessage
	}
	return response.NewErrorResponse(http.StatusForbidden, msg)
}

func (p *ODPSAuthPlugin) reportAuthError(ctx context.Context, kong *pdk.PDK, err error) {
	//TODO: can we set PO here?
	h := http.Header{}
	h.Set("WWW-Authenticate", "Bearer error=\"invalid_token\", error_description=\"The access token is invalid or has expired\"")
	response.KongExit(ctx, kong, err, h)
}
