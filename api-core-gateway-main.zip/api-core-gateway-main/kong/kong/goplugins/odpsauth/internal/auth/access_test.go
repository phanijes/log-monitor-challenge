package auth

import (
	"common/log"
	"common/testutils"
	"context"
	"errors"
	"fmt"
	"odpsauth/internal/odps"
	"testing"

	"github.com/stretchr/testify/assert"
)

type mockRequestHeaderSetter struct {
	headers  map[string][]string
	setErr   error
	clearErr error
}

func (m *mockRequestHeaderSetter) SetHeaders(headers map[string][]string) error {
	if m.headers == nil {
		m.headers = headers
	} else {
		for k, v := range headers {
			m.headers[k] = v
		}
	}
	return m.setErr
}

func (m *mockRequestHeaderSetter) ClearHeader(name string) error {
	delete(m.headers, name)
	return m.clearErr
}

func TestODPSAuthPlugin_hasPermissions(t *testing.T) {
	type args struct {
		requiredPermissions ODPSPermissions
		userPOs             map[odps.PermissionObject]bool
	}
	tests := []struct {
		name       string
		args       args
		haveAccess bool
		missingPo  []odps.PermissionObject
	}{
		{
			"empty",
			args{
				ODPSPermissions{},
				map[odps.PermissionObject]bool{},
			},
			true,
			nil,
		},
		{
			"single, ok",
			args{
				ODPSPermissions{[][]odps.PermissionObject{
					{odps.PermissionObject{Service: "svc1", Name: "po1"}}},
				},
				map[odps.PermissionObject]bool{
					{Service: "svc1", Name: "po1"}: true,
				},
			},
			true,
			nil,
		},
		{
			"single, wrong service",
			args{
				ODPSPermissions{[][]odps.PermissionObject{
					{odps.PermissionObject{Service: "svc1", Name: "po1"}}},
				},
				map[odps.PermissionObject]bool{
					{Service: "svc2", Name: "po1"}: true,
				},
			},
			false,
			[]odps.PermissionObject{{Service: "svc1", Name: "po1"}},
		},
		{
			"single, wrong po",
			args{
				ODPSPermissions{[][]odps.PermissionObject{
					{odps.PermissionObject{Service: "svc1", Name: "po1"}}},
				},
				map[odps.PermissionObject]bool{
					{Service: "svc1", Name: "po2"}: true,
				},
			},
			false,
			[]odps.PermissionObject{{Service: "svc1", Name: "po1"}},
		},
		{
			"single, denied",
			args{
				ODPSPermissions{[][]odps.PermissionObject{
					{odps.PermissionObject{Service: "svc1", Name: "po1"}}},
				},
				map[odps.PermissionObject]bool{
					{Service: "svc1", Name: "po1"}: false,
				},
			},
			false,
			[]odps.PermissionObject{{Service: "svc1", Name: "po1"}},
		},
		{
			"and, ok",
			args{
				ODPSPermissions{[][]odps.PermissionObject{
					{odps.PermissionObject{Service: "svc1", Name: "po1"}, odps.PermissionObject{Service: "svc2", Name: "po2"}}},
				},
				map[odps.PermissionObject]bool{
					{Service: "svc1", Name: "po1"}: true,
					{Service: "svc2", Name: "po2"}: true,
					{Service: "svc1", Name: "po2"}: true,
				},
			},
			true,
			nil,
		},
		{
			"and, missing entry",
			args{
				ODPSPermissions{[][]odps.PermissionObject{
					{odps.PermissionObject{Service: "svc1", Name: "po1"}, odps.PermissionObject{Service: "svc2", Name: "po2"}}},
				},
				map[odps.PermissionObject]bool{
					{Service: "svc1", Name: "po2"}: true,
					{Service: "svc2", Name: "po2"}: true,
				},
			},
			false,
			[]odps.PermissionObject{{Service: "svc1", Name: "po1"}},
		},
		{
			"or, ok1",
			args{
				ODPSPermissions{[][]odps.PermissionObject{
					{odps.PermissionObject{Service: "svc1", Name: "po1"}, odps.PermissionObject{Service: "svc1", Name: "po2"}},
					{odps.PermissionObject{Service: "svc2", Name: "po2"}},
				},
				},
				map[odps.PermissionObject]bool{
					{Service: "svc1", Name: "po1"}: true,
					{Service: "svc1", Name: "po2"}: true,
					{Service: "svc2", Name: "po2"}: false,
				},
			},
			true,
			nil,
		},
		{
			"or, ok2",
			args{
				ODPSPermissions{[][]odps.PermissionObject{
					{odps.PermissionObject{Service: "svc1", Name: "po1"}, odps.PermissionObject{Service: "svc1", Name: "po2"}},
					{odps.PermissionObject{Service: "svc2", Name: "po2"}},
				},
				},
				map[odps.PermissionObject]bool{
					{Service: "svc1", Name: "po1"}: false,
					{Service: "svc1", Name: "po2"}: false,
					{Service: "svc2", Name: "po2"}: true,
				},
			},
			true,
			nil,
		},
		{
			"or, ok all",
			args{
				ODPSPermissions{[][]odps.PermissionObject{
					{odps.PermissionObject{Service: "svc1", Name: "po1"}, odps.PermissionObject{Service: "svc1", Name: "po2"}},
					{odps.PermissionObject{Service: "svc2", Name: "po2"}},
				},
				},
				map[odps.PermissionObject]bool{
					{Service: "svc1", Name: "po1"}: true,
					{Service: "svc1", Name: "po2"}: true,
					{Service: "svc2", Name: "po2"}: true,
				},
			},
			true,
			nil,
		},
		{
			"multi or, ok all",
			args{
				ODPSPermissions{[][]odps.PermissionObject{
					{odps.PermissionObject{Service: "svc1", Name: "po1"}},
					{odps.PermissionObject{Service: "svc2", Name: "po2"}},
					{odps.PermissionObject{Service: "svc1", Name: "po2"}},
				},
				},
				map[odps.PermissionObject]bool{
					{Service: "svc1", Name: "po1"}: true,
					{Service: "svc1", Name: "po2"}: true,
					{Service: "svc2", Name: "po2"}: true,
				},
			},
			true,
			nil,
		},
		{
			"or, no po",
			args{
				ODPSPermissions{[][]odps.PermissionObject{
					{odps.PermissionObject{Service: "svc1", Name: "po1"}, odps.PermissionObject{Service: "svc1", Name: "po2"}},
					{odps.PermissionObject{Service: "svc2", Name: "po2"}},
				},
				},
				map[odps.PermissionObject]bool{
					{Service: "svc1", Name: "po1"}: true,
					{Service: "svc1", Name: "po2"}: false,
				},
			},
			false,
			[]odps.PermissionObject{{Service: "svc1", Name: "po2"}, {Service: "svc2", Name: "po2"}},
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			p := &ODPSAuthPlugin{}
			haveAccess, missingPo := p.hasPermissions(tt.args.requiredPermissions, tt.args.userPOs)
			assert.Equal(t, tt.haveAccess, haveAccess)
			assert.Equal(t, tt.missingPo, missingPo)
		})
	}
}

func TestODPSPermissions_Flatten(t *testing.T) {
	tests := []struct {
		name string
		POs  [][]odps.PermissionObject
		want []odps.PermissionObject
	}{
		{
			"empty",
			[][]odps.PermissionObject{},
			[]odps.PermissionObject{},
		},
		{
			"and",
			[][]odps.PermissionObject{{{Service: "svc1", Name: "po1"}, {Service: "svc1", Name: "po2"}, {Service: "svc1", Name: "po3"}, {Service: "svc2", Name: "po1"}, {Service: "svc2", Name: "po3"}}},
			[]odps.PermissionObject{{Service: "svc1", Name: "po1"}, {Service: "svc1", Name: "po2"}, {Service: "svc1", Name: "po3"}, {Service: "svc2", Name: "po1"}, {Service: "svc2", Name: "po3"}},
		},
		{
			"or",
			[][]odps.PermissionObject{{{Service: "svc1", Name: "po1"}, {Service: "svc1", Name: "po2"}, {Service: "svc1", Name: "po3"}}, {{Service: "svc2", Name: "po1"}, {Service: "svc2", Name: "po3"}}},
			[]odps.PermissionObject{{Service: "svc1", Name: "po1"}, {Service: "svc1", Name: "po2"}, {Service: "svc1", Name: "po3"}, {Service: "svc2", Name: "po1"}, {Service: "svc2", Name: "po3"}},
		},
		{
			"with duplicates",
			[][]odps.PermissionObject{{{Service: "svc1", Name: "po1"}, {Service: "svc1", Name: "po2"}, {Service: "svc2", Name: "po3"}}, {{Service: "svc2", Name: "po1"}, {Service: "svc2", Name: "po3"}}},
			[]odps.PermissionObject{{Service: "svc1", Name: "po1"}, {Service: "svc1", Name: "po2"}, {Service: "svc2", Name: "po1"}, {Service: "svc2", Name: "po3"}},
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			perm := &ODPSPermissions{POs: tt.POs}
			got := perm.Flatten()
			assert.Equal(t, tt.want, got)
		})
	}
}

func TestODPSAuthPlugin_doParsePermissions(t *testing.T) {
	tests := []struct {
		name   string
		cfg    []string
		want   ODPSPermissions
		errMsg string
	}{
		{
			"empty",
			[]string{},
			ODPSPermissions{[][]odps.PermissionObject{}},
			"",
		},
		{
			"single",
			[]string{"svc1:po1"},
			ODPSPermissions{[][]odps.PermissionObject{
				{{Service: "svc1", Name: "po1"}},
			}},
			"",
		},
		{
			"and",
			[]string{"svc1:po1, svc1:po2,svc2:po1\n"},
			ODPSPermissions{[][]odps.PermissionObject{
				{{Service: "svc1", Name: "po1"}, {Service: "svc1", Name: "po2"}, {Service: "svc2", Name: "po1"}},
			}},
			"",
		},
		{
			"or",
			[]string{"svc1:po1, svc1:po2", "svc2:po1"},
			ODPSPermissions{[][]odps.PermissionObject{
				{{Service: "svc1", Name: "po1"}, {Service: "svc1", Name: "po2"}},
				{{Service: "svc2", Name: "po1"}},
			}},
			"",
		},
		{
			"bad syntax",
			[]string{"svc1:po1,svc1:po2", "svc2po1"},
			ODPSPermissions{[][]odps.PermissionObject{}},
			"unexpected format of PO, expected 'service:po', got svc2po1",
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			p := &ODPSAuthPlugin{}
			got, err := p.doParsePermissions(tt.cfg)
			if err != nil || tt.errMsg != "" {
				assert.EqualError(t, err, tt.errMsg)
				return
			}
			assert.NoError(t, err)
			assert.Equal(t, tt.want, got)
		})
	}
}

func TestODPSAuthPlugin_parsePermissions(t *testing.T) {
	tests := []struct {
		name   string
		cfg    []string
		want   ODPSPermissions
		errMsg string
	}{
		{
			"empty",
			[]string{},
			ODPSPermissions{[][]odps.PermissionObject{}},
			"",
		},
		{
			"ok",
			[]string{"svc1:po1,svc1:po2", "svc2:po1"},
			ODPSPermissions{[][]odps.PermissionObject{
				{{Service: "svc1", Name: "po1"}, {Service: "svc1", Name: "po2"}},
				{{Service: "svc2", Name: "po1"}},
			}},
			"",
		},
		{
			"bad syntax",
			[]string{"svc1:po1,svc1:po2", "svc2po1"},
			ODPSPermissions{[][]odps.PermissionObject{}},
			"status: 500, code: 500, message: internal server error",
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			logger := testutils.NewDummyLogger()
			p := &ODPSAuthPlugin{}
			got, err := p.parsePermissions(log.NewContext(context.Background(), logger), tt.cfg)
			if err != nil || tt.errMsg != "" {
				assert.EqualError(t, err, tt.errMsg)
				return
			}
			assert.NoError(t, err)
			assert.Equal(t, tt.want, got)
		})
	}
}

func Test_makeCacheKey(t *testing.T) {
	type args struct {
		uuid string
		pos  []odps.PermissionObject
	}
	tests := []struct {
		name string
		args args
		want string
	}{
		{
			"empty",
			args{},
			"ODPS\x00\x00",
		},
		{
			"single",
			args{
				"myUUid",
				[]odps.PermissionObject{{Service: "svc1", Name: "po1"}},
			},
			"ODPS\x00myUUid\x00svc1:po1,",
		},
		{
			"multi",
			args{
				"myUUid",
				[]odps.PermissionObject{{Service: "svc1", Name: "po1"}, {Service: "svc1", Name: "po2"}, {Service: "svc2", Name: "po1"}},
			},
			"ODPS\x00myUUid\x00svc1:po1,svc1:po2,svc2:po1,",
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			got := makeCacheKey(tt.args.uuid, tt.args.pos)
			assert.Equal(t, tt.want, got)
		})
	}
}

type mockODPSClient struct {
	po  []odps.PermissionCheckResult
	err error
}

func (cli *mockODPSClient) GetUsrMultiSvcPOs(ctx context.Context, user string, poList []odps.PermissionObject) ([]odps.PermissionCheckResult, error) {
	return cli.po, cli.err
}

func TestODPSAuthPlugin_requestODPS(t *testing.T) {
	type args struct {
		uuid string
		pos  []odps.PermissionObject
	}
	tests := []struct {
		name           string
		odpsCli        *mockODPSClient
		custom403Error string
		args           args
		want           []odps.PermissionCheckResult
		errMsg         string
	}{
		{
			"ok",
			&mockODPSClient{po: []odps.PermissionCheckResult{{Result: odps.PoExists, PermissionObject: odps.PermissionObject{Name: "po1", Service: "svc1"}}}},
			"",
			args{},
			[]odps.PermissionCheckResult{{Result: odps.PoExists, PermissionObject: odps.PermissionObject{Name: "po1", Service: "svc1"}}},
			"",
		},
		{
			"data error",
			&mockODPSClient{err: fmt.Errorf("%w:%w", odps.ErrorData, errors.New("bad data"))},
			"",
			args{},
			[]odps.PermissionCheckResult{},
			"status: 403, code: 403, message: forbidden",
		},
		{
			"data error custom",
			&mockODPSClient{err: fmt.Errorf("%w:%w", odps.ErrorData, errors.New("bad data"))},
			"custom error",
			args{},
			[]odps.PermissionCheckResult{},
			"status: 403, code: 403, message: custom error",
		},
		{
			"communication error",
			&mockODPSClient{err: fmt.Errorf("%w:%w", odps.ErrorCommunication, errors.New("bad request"))},
			"does not matter",
			args{},
			[]odps.PermissionCheckResult{},
			"status: 502, code: 502, message: authorization failed",
		},
		{
			"other error",
			&mockODPSClient{err: errors.New("some error")},
			"does not matter",
			args{},
			[]odps.PermissionCheckResult{},
			"status: 500, code: 500, message: authorization failed",
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			p := &ODPSAuthPlugin{
				odpsCli:               tt.odpsCli,
				ForbiddenErrorMessage: tt.custom403Error,
			}
			logger := testutils.NewDummyLogger()
			got, err := p.requestODPS(log.NewContext(context.Background(), logger), tt.args.uuid, tt.args.pos)
			if err != nil || tt.errMsg != "" {
				assert.EqualError(t, err, tt.errMsg)
				return
			}
			assert.NoError(t, err)
			assert.Equal(t, tt.want, got)
		})
	}
}

func TestODPSAuthPlugin_addHeaders(t *testing.T) {
	tests := []struct {
		name           string
		upstreamHeader string
		userPOs        []odps.PermissionCheckResult
		expectedHeader map[string][]string
		setErr         error
	}{
		{
			"no upstream header",
			"",
			[]odps.PermissionCheckResult{},
			map[string][]string{},
			nil,
		},
		{
			"no permission objects",
			"X-User-POs",
			[]odps.PermissionCheckResult{},
			map[string][]string{"X-User-Pos": {""}},
			nil,
		},
		{
			"single permission object",
			"X-User-POs",
			[]odps.PermissionCheckResult{
				{PermissionObject: odps.PermissionObject{Service: "service1", Name: "po1"}, Result: odps.PoExists},
			},
			map[string][]string{"X-User-Pos": {"service1:po1"}},
			nil,
		},
		{
			"multiple permission objects",
			"X-User-POs",
			[]odps.PermissionCheckResult{
				{PermissionObject: odps.PermissionObject{Service: "service1", Name: "po1"}, Result: odps.PoExists},
				{PermissionObject: odps.PermissionObject{Service: "service2", Name: "po2"}, Result: odps.PoExists},
			},
			map[string][]string{"X-User-Pos": {"service1:po1,service2:po2"}},
			nil,
		},
		{
			"permission object with non-existing result",
			"X-User-POs",
			[]odps.PermissionCheckResult{
				{PermissionObject: odps.PermissionObject{Service: "service1", Name: "po1"}, Result: odps.PoExists},
				{PermissionObject: odps.PermissionObject{Service: "service2", Name: "po2"}, Result: odps.PoNone},
				{PermissionObject: odps.PermissionObject{Service: "service3", Name: "po3"}, Result: odps.PoUnknown},
			},
			map[string][]string{"X-User-Pos": {"service1:po1"}},
			nil,
		},
		{
			"set headers error",
			"X-User-POs",
			[]odps.PermissionCheckResult{
				{PermissionObject: odps.PermissionObject{Service: "service1", Name: "po1"}, Result: odps.PoExists},
			},
			map[string][]string{"X-User-POs": {"service1:po1"}},
			errors.New("set headers error"),
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			p := &ODPSAuthPlugin{
				UpstreamSettings: UpstreamSettings{POHeader: tt.upstreamHeader},
			}
			mockRequest := &mockRequestHeaderSetter{setErr: tt.setErr}
			err := p.addHeaders(context.Background(), mockRequest, tt.userPOs)
			if tt.setErr != nil {
				assert.EqualError(t, err, tt.setErr.Error())
			} else {
				assert.NoError(t, err)
				assert.Equal(t, tt.expectedHeader, mockRequest.headers)
			}
		})
	}
}
