package main

import (
	"odpsauth/internal/auth"

	"github.com/Kong/go-pdk/server"
)

const (
	Version = "0.0.1"
	//openid-connect is 1050. This must be lower, unless using another source of UUID header.
	Priority = 1030
)

func main() {
	server.StartServer(auth.New, Version, Priority)
}
