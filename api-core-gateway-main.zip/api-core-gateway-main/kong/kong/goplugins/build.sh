#!/bin/bash

echo "Building Go plugins..."

for d in ./*/
do
    if [[ "$d" == *"common"* ]] || [[ "$d" == *"vendor"*  ]] || [[ "$d" == *"go-pdk-fork"*  ]]
    then
        continue;
    fi
    echo "$d"
    (cd "$d" && go install) || exit 1
done