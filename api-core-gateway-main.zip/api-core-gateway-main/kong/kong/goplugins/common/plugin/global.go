package plugin

import (
	"common/cache"
	"common/cache/redis"
	"common/configuration"
	"common/log"
	"context"
)

const GLOBAL_PLUGIN_SETTINGS = "GLOBAL_PLUGIN_SETTINGS"

type globalCacheContainer struct {
	CacheConfiguration globalCacheConfig `json:"cache_configuration"`
}

type globalCacheConfig struct {
	RedisEnabled     bool   `json:"redis_enabled"`
	RedisUrl         string `json:"redis_url"`
	RedisClusterMode bool   `json:"redis_is_cluster"`
	RedisTLSEnabled  bool   `json:"redis_is_tls"`
	RedisUsername    string `json:"redis_username"`
	RedisPassword    string `json:"redis_password"`
	InMemoryEnabled  bool   `json:"inmemory_enabled"`
}

func InitGlobalCache(configurationVariable string) {
	ctx := log.NewContext(context.Background(), log.NewSimpleLogger())
	if !configuration.EnvVarExists(configurationVariable) {
		log.FromContext(ctx).Info("global cache not configured", "configuration_variable", configurationVariable)
		return
	}

	cfgContainer := new(globalCacheContainer)
	if err := configuration.GetJsonDataEnvVar(configurationVariable, cfgContainer); err != nil {
		log.FromContext(ctx).Fatal("failed to load global cache configuration", "err", err)
		return
	}

	cfg := cfgContainer.CacheConfiguration
	var redisCfg *redis.RedisConfig
	if cfg.RedisEnabled {
		redisCfg = &redis.RedisConfig{
			URL:       cfg.RedisUrl,
			IsCluster: cfg.RedisClusterMode,
			IsTLS:     cfg.RedisTLSEnabled,
			Username:  cfg.RedisUsername,
			Password:  cfg.RedisPassword,
		}
	}

	log.FromContext(ctx).Info("initializing global cache configuration", "redis_enabled", cfg.RedisEnabled, "inmemory_enbled", cfg.InMemoryEnabled)
	cache.InitGlobal(ctx, redisCfg, cfg.InMemoryEnabled)
	log.FromContext(ctx).Info("global cache initialized")
}
