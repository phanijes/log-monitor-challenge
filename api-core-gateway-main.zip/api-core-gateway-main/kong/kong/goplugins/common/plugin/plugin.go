package plugin

import (
	"common/cache"
	"common/cache/base"
	"common/cache/redis"
	"common/configuration"
	"common/log"
	"context"
)

type CacheSettings struct {
	Enabled    bool             `json:"enabled" schema:"default=true"`
	UseGlobal  bool             `json:"use_global_cache"`
	DefaultTTL int              `json:"default_ttl" schema:"default=300"`
	Redis      RedisSettings    `json:"redis_settings"`
	InMemory   InMemorySettings `json:"inmemory_settings"`
}

type RedisSettings struct {
	Enabled        bool   `json:"enabled"`
	URL            string `json:"redis_url"`
	ClusterEnabled bool   `json:"cluster_enabled"`
	TLSEnabled     bool   `json:"tls_enabled"`
	Username       string `json:"username"`
	Password       string `json:"password"`
}

type InMemorySettings struct {
	Enabled bool `json:"enabled" schema:"default=true"`
}

func InitCache(vault configuration.Vault, settings CacheSettings, backgroundLogger log.Logger) base.Cache {
	backgroundLogger.Info("initializing cache", "enabled", settings.Enabled, "redis", settings.Redis.Enabled, "inmemory", settings.InMemory.Enabled, "defaultTTL", settings.DefaultTTL)
	if settings.Enabled {
		if settings.UseGlobal {
			backgroundLogger.Info("using global cache")
			return cache.GetGlobal(settings.Redis.Enabled, settings.InMemory.Enabled, settings.DefaultTTL)
		}
		backgroundLogger.Info("using per instance cache")
		var redisCfg *redis.RedisConfig
		if settings.Redis.Enabled {
			redisCfg = &redis.RedisConfig{
				URL:       settings.Redis.URL,
				IsCluster: settings.Redis.ClusterEnabled,
				IsTLS:     settings.Redis.TLSEnabled,
				Username:  vault.TryParseReference(settings.Redis.Username, backgroundLogger),
				Password:  vault.TryParseReference(settings.Redis.Password, backgroundLogger),
			}
		}
		return cache.NewLocal(log.NewContext(context.Background(), backgroundLogger), redisCfg, settings.InMemory.Enabled, settings.DefaultTTL)
	}
	backgroundLogger.Info("cache disabled")
	return &base.NoOpCache{}
}

// we can use constant, unless the header name changes from env to env or api.
const correlationIdHeaderName = "correlation-id"

type requestHeaderGetter interface {
	GetHeader(header string) (string, error)
}

func AddCorrelationIdToLogger(ctx context.Context, logger log.Logger, kongRequest requestHeaderGetter) context.Context {
	correlationId, err := kongRequest.GetHeader(correlationIdHeaderName)
	if err != nil || correlationId == "" {
		logger.Error("error reading 'correlation id' header", "header", correlationIdHeaderName, "err", err)
		return log.NewContext(ctx, logger)
	}
	return log.NewContext(ctx, logger.With("cid", correlationId))
}

var SchemaNoConsumer = map[string]interface{}{
	"type":        "foreign",
	"reference":   "consumers",
	"eq":          nil,
	"description": "Custom type for representing a foreign key with a null value allowed.",
}

var SchemaProtocolsHttp = map[string]interface{}{
	"type":        "set",
	"required":    true,
	"default":     SchemaHttpProtocols,
	"elements":    map[string]interface{}{"type": "string", "one_of": SchemaHttpProtocols},
	"description": "A set of strings representing HTTP protocols.",
}

var SchemaHttpProtocols = []string{"http", "https", "grpc", "grpcs"}

var SchemaCacheEntityChecks = []map[string]interface{}{
	{
		"conditional_at_least_one_of": map[string]interface{}{
			"if_field":             "cache.enabled",
			"if_match":             map[string]interface{}{"eq": true},
			"then_at_least_one_of": []string{"cache.inmemory_settings.enabled", "cache.redis_settings.enabled"},
			"then_err":             "must enable at least one of the cache types",
		},
	},
	//Redis URL is required if Redis is enabled only without global cache enabled. Too complex case, needs custom check.
	// {
	// 	"conditional": map[string]interface{}{
	// 		"if_field":   "cache.redis_settings.enabled",
	// 		"if_match":   map[string]interface{}{"eq": true},
	// 		"then_field": "cache.redis_settings.redis_url",
	// 		"then_match": map[string]interface{}{"required": true},
	// 	},
	// },
}
