package plugin

import (
	"common/configuration"
	"common/log"
	"common/testutils"
	"context"
	"errors"
	"os"
	"testing"

	"github.com/stretchr/testify/assert"
)

type mockKongRequest struct {
	headers map[string]string
	err     error
}

func (m *mockKongRequest) GetHeader(header string) (string, error) {
	return m.headers[header], m.err
}

func TestAddCorrelationIdToLogger(t *testing.T) {
	tests := []struct {
		name        string
		kongRequest requestHeaderGetter
		expected    *testutils.DummyLogger
	}{
		{
			name: "correlation id present",
			kongRequest: &mockKongRequest{
				headers: map[string]string{"correlation-id": "uid123"},
			},
			expected: &testutils.DummyLogger{
				Level:            []string{},
				Message:          []string{},
				KeyAndValues:     [][]interface{}{},
				WithKeyAndValues: []interface{}{"cid", "uid123"},
			},
		},
		{
			name: "correlation id empty",
			kongRequest: &mockKongRequest{
				headers: map[string]string{"correlation-id": ""},
			},
			expected: &testutils.DummyLogger{
				Level:            []string{"Error"},
				Message:          []string{"error reading 'correlation id' header"},
				KeyAndValues:     [][]interface{}{{"header", "correlation-id", "err", nil}},
				WithKeyAndValues: []interface{}{},
			},
		},
		{
			name: "correlation id header missing",
			kongRequest: &mockKongRequest{
				headers: map[string]string{},
			},
			expected: &testutils.DummyLogger{
				Level:            []string{"Error"},
				Message:          []string{"error reading 'correlation id' header"},
				KeyAndValues:     [][]interface{}{{"header", "correlation-id", "err", nil}},
				WithKeyAndValues: []interface{}{},
			},
		},
		{
			name: "error getting correlation id",
			kongRequest: &mockKongRequest{
				err: errors.New("some error"),
			},
			expected: &testutils.DummyLogger{
				Level:            []string{"Error"},
				Message:          []string{"error reading 'correlation id' header"},
				KeyAndValues:     [][]interface{}{{"header", "correlation-id", "err", errors.New("some error")}},
				WithKeyAndValues: []interface{}{},
			},
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			logger := testutils.NewDummyLogger()
			ctx := AddCorrelationIdToLogger(context.Background(), logger, tt.kongRequest)
			got := log.FromContext(ctx)
			assert.Equal(t, tt.expected, got)
		})
	}
}
func TestInitCache(t *testing.T) {
	logger := testutils.NewDummyLogger()
	tests := []struct {
		name     string
		settings CacheSettings
		envInit  func()
		envClear func()
		expected string
	}{
		{
			name: "cache disabled",
			settings: CacheSettings{
				Enabled: false,
			},
			envInit:  func() {},
			envClear: func() {},
			expected: "initializing cache,enabled,false,redis,false,inmemory,false,defaultTTL,0 cache disabled",
		},
		{
			name: "use global cache",
			settings: CacheSettings{
				Enabled:   true,
				UseGlobal: true,
				Redis: RedisSettings{
					Enabled: true,
				},
				InMemory: InMemorySettings{
					Enabled: true,
				},
				DefaultTTL: 60,
			},
			envInit:  func() {},
			envClear: func() {},
			expected: "initializing cache,enabled,true,redis,true,inmemory,true,defaultTTL,60 using global cache",
		},
		{
			name: "use per instance cache with redis",
			settings: CacheSettings{
				Enabled:   true,
				UseGlobal: false,
				Redis: RedisSettings{
					Enabled:        true,
					URL:            "https://example.com",
					ClusterEnabled: true,
					TLSEnabled:     true,
					Username:       "{vault://env/user}",
					Password:       "{vault://env/pwd}",
				},
				InMemory: InMemorySettings{
					Enabled: false,
				},
				DefaultTTL: 120,
			},
			envInit:  func() { os.Setenv("user", "abc"); os.Setenv("pwd", "123") },
			envClear: func() { os.Unsetenv("user"); os.Unsetenv("pwd") },
			expected: "initializing cache,enabled,true,redis,true,inmemory,false,defaultTTL,120 using per instance cache",
		},
		{
			name: "use per instance cache without redis",
			settings: CacheSettings{
				Enabled:   true,
				UseGlobal: false,
				Redis: RedisSettings{
					Enabled: false,
				},
				InMemory: InMemorySettings{
					Enabled: true,
				},
				DefaultTTL: 180,
			},
			envInit:  func() {},
			envClear: func() {},
			expected: "initializing cache,enabled,true,redis,false,inmemory,true,defaultTTL,180 using per instance cache",
		},
		{
			name: "use per instance cache with both redis and in-memory",
			settings: CacheSettings{
				Enabled:   true,
				UseGlobal: false,
				Redis: RedisSettings{
					Enabled:        true,
					URL:            "https://example.com",
					ClusterEnabled: true,
					TLSEnabled:     true,
					Username:       "{vault://env/user}",
					Password:       "{vault://env/pwd}",
				},
				InMemory: InMemorySettings{
					Enabled: true,
				},
				DefaultTTL: 120,
			},
			envInit:  func() { os.Setenv("user", "abc"); os.Setenv("pwd", "123") },
			envClear: func() { os.Unsetenv("user"); os.Unsetenv("pwd") },
			expected: "initializing cache,enabled,true,redis,true,inmemory,true,defaultTTL,120 using per instance cache",
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			logger.Clear()
			tt.envInit()
			defer tt.envClear()
			InitCache(configuration.NewSimpleVault(), tt.settings, logger)
			assert.Equal(t, tt.expected, logger.ToString())
		})
	}
}
