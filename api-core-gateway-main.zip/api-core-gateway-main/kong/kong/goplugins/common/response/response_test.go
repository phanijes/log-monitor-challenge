package response

import (
	"common/log"
	"common/testutils"
	"context"
	"errors"
	"testing"

	"github.com/stretchr/testify/assert"
)

func TestNewErrorResponse(t *testing.T) {
	type args struct {
		status  int
		message string
	}
	tests := []struct {
		name string
		args args
		want *ErrorResponse
	}{
		{
			"ok",
			args{
				123,
				"test",
			},
			&ErrorResponse{status: 123, message: "test", code: "123"},
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			got := NewErrorResponse(tt.args.status, tt.args.message)
			assert.Equal(t, tt.want, got)
		})
	}
}

func TestErrorResponse_Error(t *testing.T) {
	tests := []struct {
		name string
		err  *ErrorResponse
		want string
	}{
		{
			"ok",
			&ErrorResponse{
				status:  123,
				code:    "123",
				message: "test",
			},
			"status: 123, code: 123, message: test",
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			got := tt.err.Error()
			assert.Equal(t, tt.want, got)
		})
	}
}

func TestErrorResponse_ToJSON(t *testing.T) {
	tests := []struct {
		name   string
		err    *ErrorResponse
		want   []byte
		errMsg string
	}{
		{
			"ok",
			&ErrorResponse{
				status:  123,
				code:    "123",
				message: "test",
			},
			[]byte(`{"code":"123","message":"test"}`),
			"",
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			got, err := tt.err.ToJSON()
			if err != nil || tt.errMsg != "" {
				assert.EqualError(t, err, tt.errMsg)
				return
			}
			assert.NoError(t, err)
			assert.Equal(t, string(tt.want), string(got))
		})
	}
}

func TestGetStatusAndMessage(t *testing.T) {
	logger := testutils.NewDummyLogger()
	tests := []struct {
		name    string
		err     error
		status  int
		message []byte
		errMsg  string
	}{
		{
			"ok",
			&ErrorResponse{
				status:  123,
				code:    "123",
				message: "test",
			},
			123,
			[]byte(`{"code":"123","message":"test"}`),
			"",
		},
		{
			"any error",
			errors.New("some error"),
			500,
			[]byte(`{"code":"500", "message":"internal server error"}`),
			"unprepared error,err,some error",
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			ctx := log.NewContext(context.Background(), logger)
			status, message := GetStatusAndMessage(ctx, tt.err)
			assert.Equal(t, tt.status, status)
			assert.Equal(t, string(tt.message), string(message))
			assert.Equal(t, tt.errMsg, logger.Last())
			logger.Clear()
		})
	}
}
