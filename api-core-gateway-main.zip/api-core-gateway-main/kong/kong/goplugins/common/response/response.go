package response

import (
	"common/log"
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"net/http"
	"strconv"

	"github.com/Kong/go-pdk"
)

const (
	ContentTypeJson         = "application/json"
	ContentTypeFormEncode   = "application/x-www-form-urlencoded"
	ContentTypeHeaderName   = "Content-Type"
	InternalServerError     = "internal server error"
	InternalServerErrorJSON = `{"code":"500", "message":"internal server error"}`
)

type ErrorResponse struct {
	status  int
	code    string
	message string
}

func NewErrorResponse(status int, message string) *ErrorResponse {
	return &ErrorResponse{status: status, code: strconv.Itoa(status), message: message}
}

func (e *ErrorResponse) Error() string {
	return fmt.Sprintf("status: %d, code: %s, message: %s", e.status, e.code, e.message)
}

func (e *ErrorResponse) ToJSON() ([]byte, error) {
	//Note: using Kong error format (message), to align with other Kong errors
	return json.Marshal(struct {
		Code    string `json:"code"`
		Message string `json:"message"`
	}{Code: e.code, Message: e.message})
}

func GetStatusAndMessage(ctx context.Context, err error) (int, []byte) {
	var respErr *ErrorResponse
	if errors.As(err, &respErr) {
		m, err := respErr.ToJSON()
		if err != nil {
			log.FromContext(ctx).Error("failed to json marshal the error response", "err", err, "var", respErr)
			return http.StatusInternalServerError, []byte(InternalServerErrorJSON)
		}
		return respErr.status, m
	}
	log.FromContext(ctx).Error("unprepared error", "err", err)
	return http.StatusInternalServerError, []byte(InternalServerErrorJSON)
}

func KongExit(ctx context.Context, kong *pdk.PDK, err error, h http.Header) {
	status, message := GetStatusAndMessage(ctx, err)
	h.Set(ContentTypeHeaderName, ContentTypeJson)
	kong.Response.Exit(status, []byte(message), h)
}
