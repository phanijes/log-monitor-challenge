package testutils

import (
	"common/log"
	"fmt"
)

type DummyLogger struct {
	Level            []string
	Message          []string
	KeyAndValues     [][]interface{}
	WithKeyAndValues []interface{}
}

var _ log.Logger = &DummyLogger{}

func NewDummyLogger() *DummyLogger {
	l := &DummyLogger{}
	l.Clear()
	return l
}

func (l *DummyLogger) Info(message string, keyAndValues ...interface{}) {
	l.Level = append(l.Level, "Info")
	l.Message = append(l.Message, message)
	l.KeyAndValues = append(l.KeyAndValues, keyAndValues)
}

func (l *DummyLogger) Debug(message string, keyAndValues ...interface{}) {
	l.Level = append(l.Level, "Debug")
	l.Message = append(l.Message, message)
	l.KeyAndValues = append(l.KeyAndValues, keyAndValues)
}

func (l *DummyLogger) Warn(message string, keyAndValues ...interface{}) {
	l.Level = append(l.Level, "Warn")
	l.Message = append(l.Message, message)
	l.KeyAndValues = append(l.KeyAndValues, keyAndValues)
}

func (l *DummyLogger) Error(message string, keyAndValues ...interface{}) {
	l.Level = append(l.Level, "Error")
	l.Message = append(l.Message, message)
	l.KeyAndValues = append(l.KeyAndValues, keyAndValues)
}

func (l *DummyLogger) Fatal(message string, keyAndValues ...interface{}) {
	l.Level = append(l.Level, "Fatal")
	l.Message = append(l.Message, message)
	l.KeyAndValues = append(l.KeyAndValues, keyAndValues)
}

func (l *DummyLogger) With(keyAndValues ...interface{}) log.Logger {
	l.WithKeyAndValues = append(l.WithKeyAndValues, keyAndValues...)
	return l
}

func (l *DummyLogger) Clear() {
	l.Level = []string{}
	l.Message = []string{}
	l.KeyAndValues = [][]interface{}{}
	l.WithKeyAndValues = []interface{}{}
}

func (l *DummyLogger) ToString() string {
	msg := ""
	for i := range l.Message {
		msg += l.Message[i]
		for _, w := range l.WithKeyAndValues {
			msg += fmt.Sprintf(",%v", w)
		}
		for _, v := range l.KeyAndValues[i] {
			msg += fmt.Sprintf(",%v", v)
		}
		if i < len(l.Message)-1 {
			msg += " "
		}
	}
	return msg
}

func (l *DummyLogger) Last() string {
	if len(l.Message) == 0 {
		return ""
	}
	i := len(l.Message) - 1
	msg := l.Message[i]
	for _, w := range l.WithKeyAndValues {
		msg += fmt.Sprintf(",%v", w)
	}
	for _, v := range l.KeyAndValues[i] {
		msg += fmt.Sprintf(",%v", v)
	}
	return msg
}
