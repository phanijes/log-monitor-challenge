package konglog

import (
	"bytes"
	commonlog "common/log"
	"fmt"
	"io"
	"log"

	"github.com/Kong/go-pdk"
	konglogger "github.com/Kong/go-pdk/log"
)

func FromPDK(kong *pdk.PDK) commonlog.Logger {
	return &LogAdapter{log: kong.Log}
}

type LogAdapter struct {
	log    konglogger.Log
	params []interface{}
}

var _ io.Writer = (*LogAdapter)(nil)

func (l *LogAdapter) Info(message string, keyAndValues ...interface{}) {
	l.log.Info(l.getMessage(message, keyAndValues))
}

func (l *LogAdapter) Debug(message string, keyAndValues ...interface{}) {
	l.log.Debug(l.getMessage(message, keyAndValues))
}

func (l *LogAdapter) Warn(message string, keyAndValues ...interface{}) {
	l.log.Warn(l.getMessage(message, keyAndValues))
}

func (l *LogAdapter) Error(message string, keyAndValues ...interface{}) {
	l.log.Err(l.getMessage(message, keyAndValues))
}

func (l *LogAdapter) Fatal(message string, keyAndValues ...interface{}) {
	l.log.Crit(l.getMessage(message, keyAndValues))
}

func (l *LogAdapter) getMessage(msg string, fmtArgs []interface{}) string {
	args := append([]interface{}{msg}, l.params, fmtArgs)
	if msg != "" && len(args) == 1 {
		return msg
	}
	return fmt.Sprint(args...)
}

func (l *LogAdapter) With(keyAndValues ...interface{}) commonlog.Logger {
	return &LogAdapter{
		log:    l.log,
		params: append([]interface{}{}, l.params, keyAndValues),
	}
}

func (l *LogAdapter) Sync() error {
	return nil
}

func (l *LogAdapter) Write(p []byte) (n int, err error) {
	l.Error(string(bytes.TrimSpace(p)))
	return len(p), nil
}

func Default(msg string) {
	log.Println(msg)
}
