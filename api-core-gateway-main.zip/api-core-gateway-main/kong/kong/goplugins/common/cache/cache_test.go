package cache

import (
	"common/cache/base"
	"common/log"
	"context"
	"encoding/json"
	"errors"
	"testing"

	"github.com/stretchr/testify/assert"
)

type mockCache struct {
	data map[string][]byte
	ttl  map[string]int
	err  error
}

func (m *mockCache) Get(ctx context.Context, key string) ([]byte, error) {
	if m.err != nil {
		return nil, m.err
	}
	if val, ok := m.data[key]; ok {
		return val, nil
	}
	return nil, base.ErrCacheMiss
}

func (m *mockCache) Set(ctx context.Context, key string, value []byte, ttl int) error {
	if m.err != nil {
		return m.err
	}
	m.data[key] = value
	m.ttl[key] = ttl
	return nil
}

func TestUpdateInCache(t *testing.T) {
	tests := []struct {
		name        string
		cacheKey    string
		data        any
		ttl         int
		err         error
		expectedTTL int
		expectErr   bool
	}{
		{
			name:        "successful cache update",
			cacheKey:    "testKey",
			data:        map[string]string{"foo": "bar"},
			ttl:         100,
			expectedTTL: 100,
		},
		{
			name:        "invalid TTL value",
			cacheKey:    "testKeyInvalidTTL",
			data:        map[string]string{"foo": "bar"},
			ttl:         -1,
			expectedTTL: 1,
		},
		{
			name:      "encoding error",
			cacheKey:  "testKeyEncodingError",
			data:      make(chan int), // data that cannot be marshaled to JSON
			ttl:       100,
			expectErr: true,
		},
		{
			name:      "some error",
			cacheKey:  "testKeyNetworkError",
			data:      map[string]string{"foo": "bar"},
			ttl:       100,
			err:       errors.New("some error"),
			expectErr: true,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			cacheInstance := &mockCache{data: make(map[string][]byte), ttl: make(map[string]int)}
			ctx := log.NewContext(context.Background(), log.NewSimpleLogger())
			if tt.err != nil {
				cacheInstance.err = tt.err
			}

			UpdateInCache(ctx, cacheInstance, tt.cacheKey, tt.data, tt.ttl)
			if tt.err != nil {
				cacheInstance.err = nil
			}

			cachedData, err := cacheInstance.Get(ctx, tt.cacheKey)
			if tt.expectErr || err != nil {
				assert.Error(t, err)
				assert.Equal(t, base.ErrCacheMiss, err)
				return
			}

			assert.NoError(t, err)

			var result map[string]string
			err = json.Unmarshal(cachedData, &result)
			assert.NoError(t, err)
			assert.Equal(t, tt.data, result)
			assert.Equal(t, tt.expectedTTL, cacheInstance.ttl[tt.cacheKey])
		})
	}
}
func TestGetFromCache(t *testing.T) {
	tests := []struct {
		name     string
		cacheKey string
		data     any
		err      error
		expected map[string]string
	}{
		{
			name:     "successful cache retrieval",
			cacheKey: "testKey",
			data:     map[string]string{"foo": "bar"},
			expected: map[string]string{"foo": "bar"},
		},
		{
			name:     "cache miss",
			cacheKey: "testKeyCacheMiss",
			expected: nil,
		},
		{
			name:     "decoding error",
			cacheKey: "testKeyDecodingError",
			data:     []byte("invalid json"),
			expected: nil,
		},
		{
			name:     "some error",
			cacheKey: "testKeyNetworkError",
			data:     map[string]string{"foo": "bar"},
			err:      errors.New("some error"),
			expected: nil,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			cacheInstance := &mockCache{data: make(map[string][]byte), ttl: make(map[string]int)}
			ctx := log.NewContext(context.Background(), log.NewSimpleLogger())
			if tt.data != nil {
				data, err := json.Marshal(tt.data)
				assert.NoError(t, err)
				cacheInstance.data[tt.cacheKey] = data
			}
			if tt.err != nil {
				cacheInstance.err = tt.err
			}

			res := GetFromCache[map[string]string](ctx, cacheInstance, tt.cacheKey)
			if tt.expected == nil {
				assert.Nil(t, res)
			} else {
				assert.Equal(t, tt.expected, *res)
			}
		})
	}
}
