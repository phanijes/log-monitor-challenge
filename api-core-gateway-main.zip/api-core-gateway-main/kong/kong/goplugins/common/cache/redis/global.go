package redis

import (
	"common/cache/base"
	"common/log"
	"context"
	"sync"
)

// set to no-op cache by default
var instance base.Cache = new(base.NoOpCache)

func SetCache(cache base.Cache) {
	instance = cache
}

var mt = &sync.RWMutex{}
var currentCfg RedisConfig

func InitGlobal(ctx context.Context, cfg RedisConfig) {
	mt.Lock()
	defer mt.Unlock()
	if cfg != currentCfg {
		currentCfg = cfg
		log.FromContext(ctx).Info("initializing redis", "URL", cfg.URL, "cluster", cfg.IsCluster, "TLS", cfg.IsTLS, "user", cfg.Username)
		SetCache(New(cfg))
	}
}

func Global() base.Cache {
	return &redisGlobal{}
}

type redisGlobal struct{}

func (c *redisGlobal) Set(ctx context.Context, key string, data []byte, ttl int) error {
	return instance.Set(ctx, key, data, ttl)
}

func (c *redisGlobal) Get(ctx context.Context, key string) ([]byte, error) {
	return instance.Get(ctx, key)
}
