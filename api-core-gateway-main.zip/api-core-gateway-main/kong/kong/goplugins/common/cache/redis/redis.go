package redis

import (
	"context"
	"crypto/tls"
	"errors"
	"time"

	redis "github.com/redis/go-redis/v9"

	"common/cache/base"
	"common/log"
)

type redisCache struct {
	client redis.Cmdable
}

const readWriteTimeout = 1 * time.Second

type RedisConfig struct {
	URL       string
	IsCluster bool
	IsTLS     bool
	Username  string
	Password  string
}

func New(cfg RedisConfig) *redisCache {
	tlsConfig := redisTLSConfig(cfg.IsTLS)
	var client redis.Cmdable
	if cfg.IsCluster {
		client = redis.NewClusterClient(
			&redis.ClusterOptions{Addrs: []string{cfg.URL}, DialTimeout: readWriteTimeout * 2, ReadTimeout: readWriteTimeout, WriteTimeout: readWriteTimeout, Username: cfg.Username, Password: cfg.Password, TLSConfig: tlsConfig},
		)
	} else {
		client = redis.NewClient(
			&redis.Options{Addr: cfg.URL, DialTimeout: readWriteTimeout * 2, ReadTimeout: readWriteTimeout, WriteTimeout: readWriteTimeout, Username: cfg.Username, Password: cfg.Password, TLSConfig: tlsConfig},
		)
	}
	return &redisCache{client: client}
}

var ErrTLSNoAuth = errors.New("could not create cache connection - AUTH requires TLS, but TLS is disabled")

// redisTLSConfig creates simple TLS config for redis connection.
func redisTLSConfig(isTLS bool) *tls.Config {
	if !isTLS {
		return nil
	}
	return &tls.Config{
		InsecureSkipVerify: true,
		MinVersion:         tls.VersionTLS12,
	}
}

// Set stores value with specified key in Redis with the specified expiration time (in seconds).
func (c *redisCache) Set(ctx context.Context, key string, data []byte, ttl int) error {
	logger := log.FromContext(ctx)
	// We shouldn't use request context here - it can cause cancellation of caching
	if err := c.client.Set(context.Background(), key, []byte(data), time.Duration(ttl)*time.Second).Err(); err != nil {
		logger.Error("cache request failed", "err", err)
		return err
	}
	logger.Debug("cache set", "key", key)
	return nil
}

// Get retrieves value for the specified key from Redis. Dedicated ErrCacheMiss error is returned on cache miss.
func (c *redisCache) Get(ctx context.Context, key string) ([]byte, error) {
	logger := log.FromContext(ctx)
	res := c.client.Get(ctx, key)
	if err := res.Err(); err != nil {
		if err == redis.Nil {
			logger.Debug("cache miss", "key", key)
			return nil, base.ErrCacheMiss
		}
		return nil, err
	}
	logger.Debug("cache hit", "key", key)
	return res.Bytes()
}
