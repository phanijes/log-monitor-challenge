package base

import (
	"common/log"
	"context"
	"errors"
)

type Cache interface {
	//Set stores data in cache under the provided key for 'ttl' seconds
	Set(ctx context.Context, key string, data []byte, ttl int) error
	//Get retrieves data associated with the provided key from cache
	Get(ctx context.Context, key string) ([]byte, error)
}

const MinTTL = 1

// ErrCacheMiss indicates that there is no data for the requested key
var ErrCacheMiss = errors.New("cache miss")

// ErrCacheSet indicates that the data could not be stored in cache
var ErrCacheSet = errors.New("failed to store value in cache")

type NoOpCache struct{}

func (c *NoOpCache) Set(ctx context.Context, key string, data []byte, ttl int) error {
	log.NewSimpleLogger().Error("no-op cache set", "key", key)
	return nil
}
func (c *NoOpCache) Get(ctx context.Context, key string) ([]byte, error) {
	log.NewSimpleLogger().Error("no-op cache get", "key", key)
	return nil, ErrCacheMiss
}
