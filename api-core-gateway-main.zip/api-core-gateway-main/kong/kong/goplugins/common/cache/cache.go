package cache

import (
	"common/cache/base"
	"common/cache/inmemory"
	"common/cache/layered"
	"common/cache/redis"
	"common/log"
	"context"
	"encoding/json"
)

func InitGlobal(ctx context.Context, redisCfg *redis.RedisConfig, useInMemory bool) {
	if redisCfg != nil {
		redis.InitGlobal(ctx, *redisCfg)
	}
	if useInMemory {
		inmemory.InitGlobal()
	}
}

func GetGlobal(useRedis, useInMemory bool, defaultTTL int) base.Cache {
	layers := []base.Cache{}
	//order of layers is important! The cheapest/fastest should be first.
	if useInMemory {
		layers = append(layers, inmemory.Global())
	}
	if useRedis {
		layers = append(layers, redis.Global())
	}
	if defaultTTL < 0 {
		defaultTTL = base.MinTTL
	}
	return layered.New(layers, defaultTTL)
}

func NewLocal(ctx context.Context, redisCfg *redis.RedisConfig, useInMemory bool, defaultTTL int) base.Cache {
	layers := []base.Cache{}
	//order of layers is important! The cheapest/fastest should be first.
	if useInMemory {
		layers = append(layers, inmemory.New())
	}
	if redisCfg != nil {
		layers = append(layers, redis.New(*redisCfg))
	}
	if defaultTTL < 0 {
		defaultTTL = base.MinTTL
	}
	return layered.New(layers, defaultTTL)
}

// GetFromCache retrieves the value for the specified key from the provided cache instance.
// If the key is not found or value cannot be extracted - nil is returned
func GetFromCache[T any](ctx context.Context, cacheInstance base.Cache, cacheKey string) *T {
	resultFromCache, cacheErr := cacheInstance.Get(ctx, cacheKey)
	if cacheErr != nil {
		if cacheErr != base.ErrCacheMiss {
			log.FromContext(ctx).Error("error during retrieving cached result", "err", cacheErr)
		}
		//cache miss or error
		return nil
	}
	var result = new(T)
	if err := json.Unmarshal(resultFromCache, result); err != nil {
		log.FromContext(ctx).Error("error during decoding cached result", "err", err)
		return nil
	}
	return result
}

// UpdateInCache stores the value in the provided cache instance under the specified key
func UpdateInCache(ctx context.Context, cacheInstance base.Cache, cacheKey string, data any, ttl int) {
	//260000 seconds is about 72 hours or 3 days
	if ttl < 1 || ttl > 2600000 {
		log.FromContext(ctx).Warn("unexpected TTL value. Setting to 1 second", "ttl", ttl)
		ttl = base.MinTTL
	}
	encodedResult, encodeErr := json.Marshal(data)
	if encodeErr != nil {
		log.FromContext(ctx).Error("error during encoding result for caching", "err", encodeErr)
		return
	}
	if cacheErr := cacheInstance.Set(ctx, cacheKey, encodedResult, ttl); cacheErr != nil {
		log.FromContext(ctx).Error("error during writing result to cache", "err", cacheErr)
	}

}
