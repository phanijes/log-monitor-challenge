package inmemory

import (
	"common/cache/base"
	"common/log"
	"context"
	"runtime"
	"time"

	"github.com/jellydator/ttlcache/v3"
)

type inMemoryCache struct {
	c *ttlcache.Cache[string, []byte]
}

func New() *inMemoryCache {
	ttlC := ttlcache.New(ttlcache.WithDisableTouchOnHit[string, []byte]())
	go ttlC.Start()
	c := &inMemoryCache{ttlC}
	runtime.SetFinalizer(c, finalizer)
	return c
}

func finalizer(c *inMemoryCache) {
	c.c.Stop()
}

func (c *inMemoryCache) Set(ctx context.Context, key string, data []byte, ttl int) error {
	v := c.c.Set(key, data, time.Duration(ttl)*time.Second)
	if v == nil {
		log.FromContext(ctx).Debug("cache set failed", "key", key)
		return base.ErrCacheSet
	}
	log.FromContext(ctx).Debug("cache set", "key", key)
	return nil
}

func (c *inMemoryCache) Get(ctx context.Context, key string) ([]byte, error) {
	v := c.c.Get(key)
	if v == nil {
		log.FromContext(ctx).Debug("cache miss", "key", key)
		return nil, base.ErrCacheMiss
	}
	log.FromContext(ctx).Debug("cache hit", "key", key)
	return v.Value(), nil
}
