package inmemory

import (
	"common/cache/base"
	"context"
	"sync"
)

// set to no-op cache by default
var instance base.Cache = new(base.NoOpCache)

func SetCache(cache base.Cache) {
	instance = cache
}

var mt = &sync.RWMutex{}

func InitGlobal() {
	mt.Lock()
	defer mt.Unlock()
	SetCache(New())
}

func Global() base.Cache {
	return &redisGlobal{}
}

type redisGlobal struct{}

func (c *redisGlobal) Set(ctx context.Context, key string, data []byte, ttl int) error {
	return instance.Set(ctx, key, data, ttl)
}

func (c *redisGlobal) Get(ctx context.Context, key string) ([]byte, error) {
	return instance.Get(ctx, key)
}
