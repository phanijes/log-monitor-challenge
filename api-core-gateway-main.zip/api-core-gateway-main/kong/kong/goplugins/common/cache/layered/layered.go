package layered

import (
	"common/cache/base"
	"common/log"
	"context"
)

type layeredCache struct {
	layers          []base.Cache
	defaultTTL      int
	minTTLThreshold int
}

// NewLayeredCache creates a wrapper on several caches. Caches are processed in order they are specified.
func New(layers []base.Cache, ttl int) *layeredCache {
	// the minimal time (second) caching could be attempted for re-caching in lower layers
	// this is also a period for which only the last level cache will be used.
	minTTLThreshold := base.MinTTL
	return &layeredCache{layers: layers, defaultTTL: ttl, minTTLThreshold: minTTLThreshold}
}

// Get tries to get the value for the provided key from caches. Result is returned from the first cache containing it.
// If result is not found, ErrCacheMiss is returned.
// If result is found, but not in the first cache, it is re-cached in lower layers with reduced TTL.
func (c *layeredCache) Get(ctx context.Context, key string) ([]byte, error) {
	var (
		hitLayer int = -1
		result   []byte
		err      error
	)
	for i, layer := range c.layers {
		result, err = layer.Get(ctx, key)
		//return first matched result
		if err == nil {
			hitLayer = i
			break
		}
		//always log errors
		if err != base.ErrCacheMiss {
			log.FromContext(ctx).Error("error getting data from cache", "layer", i, "key", key)
		}
	}
	if hitLayer == -1 {
		return nil, base.ErrCacheMiss
	}
	// update lower layers caches
	// TODO: consider obtaining TTL from the cache instead of using defaultTTL
	for i := 0; i < hitLayer; i++ {
		//ttl is reduced depending on number of layers to avoid making stale cache.
		ttl := (c.defaultTTL / len(c.layers)) * (i + 1)
		//do not cache for less than minimum threshold
		if ttl > (c.minTTLThreshold * (i + 1)) {
			go c.layers[i].Set(ctx, key, result, ttl)
		}
	}
	return result, nil
}

func (c *layeredCache) Set(ctx context.Context, key string, data []byte, ttl int) error {
	var nestedError error
	for _, layer := range c.layers {
		layer.Set(ctx, key, data, ttl)
	}
	return nestedError
}
