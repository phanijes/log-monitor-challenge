package log

import (
	"bytes"
	"context"
	"fmt"
	"io"
	"log"

	"go.uber.org/zap"
	"go.uber.org/zap/zapcore"
)

const (
	LOG_LEVEL_ENVIRONMENT_VARIABLE = "LOG_LEVEL"
)

type Logger interface {
	Info(message string, keyAndValues ...interface{})
	Debug(message string, keyAndValues ...interface{})
	Warn(message string, keyAndValues ...interface{})
	Error(message string, keyAndValues ...interface{})
	Fatal(message string, keyAndValues ...interface{})
	With(keyAndValues ...interface{}) Logger
	//Write(p []byte) (n int, err error)

}

var encoderConfig = zapcore.EncoderConfig{
	MessageKey:   "msg",
	LevelKey:     "lvl",
	TimeKey:      "tm",
	CallerKey:    "cl",
	EncodeTime:   zapcore.ISO8601TimeEncoder,
	EncodeCaller: zapcore.ShortCallerEncoder,
	EncodeLevel:  zapcore.LowercaseLevelEncoder,
}

func New(level string) *LogAdapter {
	logLevel := zap.InfoLevel
	switch level {
	case "debug":
		logLevel = zap.DebugLevel
	case "info":
	case "notice":
		logLevel = zap.InfoLevel
	case "warn":
		logLevel = zap.WarnLevel
	case "error":
		logLevel = zap.ErrorLevel
	case "crit":
		logLevel = zap.DPanicLevel
	}
	cfg := zap.Config{
		Encoding:         "json",
		Level:            zap.NewAtomicLevelAt(logLevel),
		OutputPaths:      []string{"/dev/stdout"},
		ErrorOutputPaths: []string{"/dev/stdout"},
		EncoderConfig:    encoderConfig,
	}
	logger, err := cfg.Build()
	if err != nil {
		panic(err)
	}
	logger = logger.WithOptions(zap.AddCallerSkip(1))
	zap.ReplaceGlobals(logger)

	return &LogAdapter{
		log: logger.Sugar(),
	}

}

type logKeyType int

const logKey logKeyType = iota

func NewContext(ctx context.Context, l Logger) context.Context {
	return context.WithValue(ctx, logKey, l)
}

func FromContext(ctx context.Context) Logger {
	return (ctx.Value(logKey)).(Logger)
}

type LogAdapter struct {
	log *zap.SugaredLogger
}

var _ io.Writer = &LogAdapter{}
var _ Logger = &LogAdapter{}

func (l *LogAdapter) Info(message string, keyAndValues ...interface{}) {
	l.log.Infow(message, keyAndValues...)
}

func (l *LogAdapter) Debug(message string, keyAndValues ...interface{}) {
	l.log.Debugw(message, keyAndValues...)
}

func (l *LogAdapter) Warn(message string, keyAndValues ...interface{}) {
	l.log.Warnw(message, keyAndValues...)
}

func (l *LogAdapter) Error(message string, keyAndValues ...interface{}) {
	l.log.Errorw(message, keyAndValues...)
}

func (l *LogAdapter) Fatal(message string, keyAndValues ...interface{}) {
	l.log.Fatalw(message, keyAndValues...)
}

func (l *LogAdapter) With(keyAndValues ...interface{}) Logger {
	return &LogAdapter{
		log: l.log.With(keyAndValues...),
	}
}

func (l *LogAdapter) Sync() error {
	return l.log.Sync()
}

func (l *LogAdapter) Write(p []byte) (n int, err error) {
	l.Error(string(bytes.TrimSpace(p)))
	return len(p), nil
}

func Default(msg string) {
	log.Println(msg)
}

// simpleLogger wraps Go sdk log package. Use it in case no other logger is available yet.
type simpleLogger struct{}

var _ Logger = &simpleLogger{}

func NewSimpleLogger() *simpleLogger {
	return &simpleLogger{}
}

func (l *simpleLogger) Info(message string, keyAndValues ...interface{}) {
	log.Println(l.getMessage(message, keyAndValues))
}

func (l *simpleLogger) Debug(message string, keyAndValues ...interface{}) {
	log.Println(l.getMessage(message, keyAndValues))
}

func (l *simpleLogger) Warn(message string, keyAndValues ...interface{}) {
	log.Println(l.getMessage(message, keyAndValues))
}

func (l *simpleLogger) Error(message string, keyAndValues ...interface{}) {
	log.Println(l.getMessage(message, keyAndValues))
}

func (l *simpleLogger) Fatal(message string, keyAndValues ...interface{}) {
	log.Println(l.getMessage(message, keyAndValues))
}
func (l *simpleLogger) With(keyAndValues ...interface{}) Logger {
	return l
}

func (l *simpleLogger) getMessage(msg string, fmtArgs []interface{}) string {
	args := append([]interface{}{msg}, fmtArgs)
	if msg != "" && len(args) == 1 {
		return msg
	}
	return fmt.Sprint(args...)
}
