package main

import (
	"common/cache"
	"common/configuration"
	"common/konglog"
	"common/log"
	"fmt"
)

var _ log.Logger = &log.LogAdapter{}
var _ log.Logger = &konglog.LogAdapter{}
var _ = cache.InitGlobal
var _ = configuration.Dummy{}

func main() {
	//just to make sonar happy
	fmt.Println("shared code library")
}
