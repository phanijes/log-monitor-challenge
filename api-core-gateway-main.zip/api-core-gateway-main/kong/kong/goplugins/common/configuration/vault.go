package configuration

import (
	"common/log"
	"encoding/json"
	"errors"
	"net/url"
	"os"
	"regexp"
	"strings"
)

type Vault interface {
	IsReference(reference string) bool
	ParseReference(reference string) (string, error)
	TryParseReference(reference string, logger log.Logger) string
}

var ErrNotReference = errors.New("not a reference")

// SimpleVault is simple vault implementation that can parse vault references
// At the moment, only environment variable vault is supported
type SimpleVault struct{}

func NewSimpleVault() *SimpleVault {
	return &SimpleVault{}
}

func (v *SimpleVault) IsReference(reference string) bool {
	match, err := regexp.MatchString(`^{vault://.+}$`, reference)
	if err != nil {
		return false
	}
	return match
}

func (v *SimpleVault) ParseReference(reference string) (string, error) {
	if !v.IsReference(reference) {
		return "", ErrNotReference
	}
	reference = reference[1 : len(reference)-1]
	urlRef, err := url.Parse(reference)
	if err != nil {
		return "", err
	}
	if urlRef.Scheme != "vault" {
		//should not happen
		return "", errors.New("invalid scheme, must be 'vault'")
	}
	if urlRef.Host != "env" {
		return "", errors.New("only environment variables are supported")
	}
	path := strings.TrimLeft(urlRef.Path, "/")
	if path == "" {
		return "", errors.New("missing path")
	}
	splitPath := strings.Split(path, "/")
	if len(splitPath) > 2 {
		return "", errors.New("invalid path, must be either variable name or variable name with key")
	}

	envVar := os.Getenv(splitPath[0])
	if envVar == "" {
		return "", errors.New("failed to get environment variable")
	}
	if len(splitPath) == 1 {
		return envVar, nil
	}
	m := make(map[string]string)
	if err := json.Unmarshal([]byte(envVar), &m); err != nil {
		return "m", errors.New("failed to json unmarshal environment variable into map")
	}
	return m[splitPath[1]], nil
}

func (v *SimpleVault) TryParseReference(reference string, logger log.Logger) string {
	result, err := v.ParseReference(reference)
	if err != nil {
		if errors.Is(err, ErrNotReference) {
			return reference
		}
		logger.Fatal("failed to parse reference", "err", err)
		return ""
	}
	return result
}
