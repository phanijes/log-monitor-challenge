package configuration

import (
	"encoding/json"
	"fmt"
	"os"
)

func GetJsonEnvVar(key string) (map[string]string, error) {
	v := os.Getenv(key)
	m := make(map[string]string)
	if v == "" {
		return m, fmt.Errorf("failed to get environment variable %s", key)
	}
	if err := json.Unmarshal([]byte(v), &m); err != nil {
		return m, fmt.Errorf("failed to json unmarshal environment variable %s: %s", key, err)
	}
	return m, nil
}

func EnvVarExists(key string) bool {
	_, ok := os.LookupEnv(key)
	return ok
}

func GetJsonDataEnvVar(key string, data any) error {
	v := os.Getenv(key)
	if v == "" {
		return fmt.Errorf("failed to get environment variable %s", key)
	}
	if err := json.Unmarshal([]byte(v), data); err != nil {
		return fmt.Errorf("failed to json unmarshal environment variable %s into %T: %s", key, data, err)
	}
	return nil
}

type Dummy struct{}
