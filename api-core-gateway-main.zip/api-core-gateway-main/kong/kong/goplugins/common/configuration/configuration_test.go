package configuration

import (
	"os"
	"testing"

	"github.com/stretchr/testify/assert"
)

func TestGetJsonEnvVar(t *testing.T) {
	tests := []struct {
		name   string
		key    string
		want   map[string]string
		errMsg string
	}{
		{
			"no var",
			"NOVAR",
			map[string]string{},
			"failed to get environment variable NOVAR",
		},
		{
			"ok",
			"TestGetJsonEnvVar_ok",
			map[string]string{"key": "value"},
			"",
		},
		{
			"bad",
			"TestGetJsonEnvVar_bad",
			map[string]string{},
			"failed to json unmarshal environment variable TestGetJsonEnvVar_bad: invalid character 'v' looking for beginning of value",
		},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			assert.NoError(t, os.Setenv("TestGetJsonEnvVar_ok", `{"key":"value"}`))
			assert.NoError(t, os.Setenv("TestGetJsonEnvVar_bad", `{"key":value}`))

			got, err := GetJsonEnvVar(tt.key)
			if err != nil || tt.errMsg != "" {
				assert.EqualError(t, err, tt.errMsg)
				return
			}
			assert.NoError(t, err)
			assert.Equal(t, tt.want, got)
		})
	}
}
