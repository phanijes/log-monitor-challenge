package configuration

import (
	"os"
	"testing"

	"github.com/stretchr/testify/assert"
)

func TestIsReference(t *testing.T) {
	vault := NewSimpleVault()

	tests := []struct {
		name      string
		reference string
		expected  bool
	}{
		{"ValidReferenceWithEnvVar", "{vault://env/VAR}", true},
		{"ValidReferenceWithEnvVarAndKey", "{vault://env/VAR/key}", true},
		{"MissingBraces", "vault://env/VAR", false},
		{"MissingBraces2", "vault://env/VAR}", false},
		{"MissingBraces3", "{vault://env/VAR", false},
		{"InvalidScheme", "{env://}", false},
		{"ValidReferenceWithEnvVarAndKey2", "{vault://env/VAR2/key2}", true},
		{"ValidReferenceWithEnvVar2", "{vault://env/VAR2}", true},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			result := vault.IsReference(tt.reference)
			assert.Equal(t, tt.expected, result)
		})
	}
}

func TestParseReference(t *testing.T) {
	vault := NewSimpleVault()

	tests := []struct {
		name        string
		reference   string
		envVarName  string
		envVarValue string
		expected    string
		errorMsg    string
	}{
		{"ValidReferenceWithEnvVar", "{vault://env/VAR}", "VAR", "value", "value", ""},
		{"ValidReferenceWithEnvVarAndKey", "{vault://env/VAR/key}", "VAR", `{"key":"value"}`, "value", ""},
		{"InvalidReferenceMissingBraces", "vault://env/VAR", "VAR", "", "", "not a reference"},
		{"InvalidReferenceMissingEnvVar", "{vault://env/}", "VAR", "", "", "missing path"},
		{"InvalidReferenceInvalidScheme", "{env://env/VAR}", "VAR", "", "", "not a reference"},
		{"InvalidReferenceInvalidHost", "{vault://invalid/VAR}", "VAR", "", "", "only environment variables are supported"},
		{"InvalidReferenceMissingPath", "{vault://env/}", "VAR", "", "", "missing path"},
		{"InvalidReferenceTooManyPathSegments", "{vault://env/VAR/key1/key2}", "VAR", "", "", "invalid path, must be either variable name or variable name with key"},
		{"ValidReferenceWithEnvVarAndKey2", "{vault://env/VAR2/key2}", "VAR2", `{"key2":"value2"}`, "value2", ""},
		{"ValidReferenceWithEnvVar2", "{vault://env/VAR2}", "VAR2", "value2", "value2", ""},
		{"InvalidReferenceWithInvalidScheme", "{vault://invalid/VAR}", "VAR", "", "", "only environment variables are supported"},
		{"InvalidReferenceWithEnvVarAndKey3", "{vault://env/VAR/key1/key2}", "VAR", "", "", "invalid path, must be either variable name or variable name with key"},
		{"InvalidEnvVarJsonUnmarshal", "{vault://env/VAR/key}", "VAR", `invalid_json`, "", "failed to json unmarshal environment variable into map"},
		{"MissingEnvVar", "{vault://env/MISSING_VAR}", "", "", "", "failed to get environment variable"},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if tt.envVarName != "" {
				os.Setenv(tt.envVarName, tt.envVarValue)
				defer os.Unsetenv(tt.envVarName)
			}

			result, err := vault.ParseReference(tt.reference)
			if tt.errorMsg != "" || err != nil {
				assert.EqualError(t, err, tt.errorMsg)
				return
			}
			assert.NoError(t, err)
			assert.Equal(t, tt.expected, result)
		})
	}
}
