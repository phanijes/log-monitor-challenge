package main

import (
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"time"
)

const (
	contentTypeHeader = "Content-Type"
	jsonType          = "application/json"
)

func odpssimple(w http.ResponseWriter, req *http.Request) {
	fmt.Fprintf(w, `SUCCESS:
TEST_SERVICE,1`)
}

func errorsimple(w http.ResponseWriter, req *http.Request) {
	w.Header().Set(contentTypeHeader, jsonType)
	w.WriteHeader(400)
	fmt.Fprintf(w, `{"code":"somecode","description":"some error"}`)
}
func errorsimpleproblem(w http.ResponseWriter, req *http.Request) {
	w.Header().Set(contentTypeHeader, "application/problem+json")
	w.WriteHeader(400)
	fmt.Fprintf(w, `{"code":"somecode","description":"some error problem"}`)
}

func errorjustcode(w http.ResponseWriter, req *http.Request) {
	w.Header().Set(contentTypeHeader, jsonType)
	w.WriteHeader(401)
	fmt.Fprintf(w, `{"code":"somecode","message":"some message"}`)
}

func errorcustom(w http.ResponseWriter, req *http.Request) {
	w.Header().Set(contentTypeHeader, jsonType)
	w.WriteHeader(403)
	fmt.Fprintf(w, `{"id":"custom","msg":"custom message"}`)
}

func errorbadjson(w http.ResponseWriter, req *http.Request) {
	w.Header().Set(contentTypeHeader, jsonType)
	w.WriteHeader(500)
	fmt.Fprintf(w, `non-json response`)
}

func errorother(w http.ResponseWriter, req *http.Request) {
	w.Header().Set(contentTypeHeader, "text/html")
	w.WriteHeader(502)
	fmt.Fprintf(w, `non-json response`)
}

func sts(w http.ResponseWriter, req *http.Request) {
	type stsRequest struct {
		Token string `json:"token"`
	}
	type stsResponse struct {
		Active     bool   `json:"active,omitempty"`
		Scope      string `json:"scope,omitempty"`
		Username   string `json:"username,omitempty"`
		TokenType  string `json:"token_type,omitempty"`
		Exp        int64  `json:"exp,omitempty"`
		Iat        int64  `json:"iat,omitempty"`
		UUID       string `json:"sub,omitempty"`
		Aud        string `json:"aud,omitempty"`
		Iss        string `json:"iss,omitempty"`
		Type       string `json:"type,omitempty"`
		Session    string `json:"session,omitempty"`
		ActiveSite string `json:"activeSite,omitempty"`
		SapVersion string `json:"sapVersion,omitempty"`
		Version    string `json:"version,omitempty"`
	}
	w.Header().Set(contentTypeHeader, jsonType)
	bt, err := io.ReadAll(req.Body)
	if err != nil {
		w.WriteHeader(500)
		fmt.Fprintf(w, `{"error": "%s"}`, err)
		return
	}
	r := stsRequest{}
	if err = json.Unmarshal(bt, &r); err != nil {
		w.WriteHeader(500)
		fmt.Fprintf(w, `{"error": "%s"}`, err)
		return
	}
	if r.Token != "a.eyJpc3MiOiJ0ZXN0aXNzdWVyIn0.a" {
		bt, err = json.Marshal(&stsResponse{Active: false})
		if err != nil {
			w.WriteHeader(500)
			fmt.Fprintf(w, `{"error": "%s"}`, err)
			return
		}
		w.Write(bt)
	}
	bt, err = json.Marshal(&stsResponse{Active: true, Scope: "testscope", Username: "test", UUID: "GENTC-184489", Exp: time.Now().Add(5 * time.Minute).Unix()})
	if err != nil {
		w.WriteHeader(500)
		fmt.Fprintf(w, `{"error": "%s"}`, err)
		return
	}
	w.Write(bt)
}

func main() {

	http.HandleFunc("/odpssimple/", odpssimple)
	http.HandleFunc("/error/simple", errorsimple)
	http.HandleFunc("/error/simpleproblem", errorsimpleproblem)
	http.HandleFunc("/error/justcode", errorjustcode)
	http.HandleFunc("/error/custom", errorcustom)
	http.HandleFunc("/error/badjson", errorbadjson)
	http.HandleFunc("/error/other", errorother)
	http.HandleFunc("/sts/", sts)

	http.ListenAndServe(":8090", nil)
}
