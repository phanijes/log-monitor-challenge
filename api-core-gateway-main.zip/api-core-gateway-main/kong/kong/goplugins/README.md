# Custom Kong Go Plugins

## General Considerations On Kong Go PDK Usage

- Kong Go PDK creates a new instance of plugin each time configuration is changed. There could be several instances working at the same time. Outdated instances will be replaces with new version eventually.
- Kong Go PDK do not allow initialization. Plugin constructor is a function without parameters used to generate the object in which plugin configuration will be decoded (JSON unmarshal). Any initialization have to be done in the actual request processing (e.g. via sync.Once)
- Due to the nature of how Kong Go PDK works, package level variables should be used with care: multiple instances of plugin, potentially with different configuration, could be using them. Try limit use to components which do not change with plugin configuration and should persist on configuration change or be shared between instances (e.g. some in memory caches, http clients, etc.).
- Each call to Kong PDK is essentially IPC (gRPC) call to Kong process. We should try to minimize PDK interaction. This is especially crucial for logs, e.g. Debug, cause it wil initiate IPC but will be discarded by Kong if such log level is not enabled. TODO: respect Kong configured log level locally (we should be able to get the environment variable).

## Global plugin configuration

Most Kong plugins a designed to have all configuration per plugin instance. In our use case however, there is no reason to duplicate the same identical configuration across all the API (cache, auth, etc.). Additionally, due to the nature of Kong PDK and interaction with external plugins, it is non-trivial to have shared state between the plugin instances. Thus, it makes sense to support 'global' configuration, which is not tied to the specific plugin configuration, but is based on the Kong instance itself. Using environment variables is the simplest approach. Configuration files might be even better approach for the future enhancements.

### Cache configuration

*Variable name:* GLOBAL_PLUGIN_SETTINGS
*Variable payload:* TODO
