#!/bin/sh

export pluginlist="$(cat /usr/local/bin/pluginlist.txt)"
export configfile="/etc/kong/kong.conf"
echo "plugins = bundled,moesif,${pluginlist}">> $configfile
echo "pluginserver_names = ${pluginlist}" >> $configfile

for plugin in $(echo $pluginlist| sed "s/,/ /g")
do
    #note: kubernetes deployment has to be done with readonly root filesystem,
    # so we need a modifiable location for socket files.
    # /kong_prefix is mounted by kong chart as emptyDir by default, and also supported by plugins - using it.
    echo "pluginserver_${plugin}_socket = /kong_prefix/${plugin}.socket" >> $configfile
    echo "pluginserver_${plugin}_query_cmd = /usr/local/bin/${plugin} -dump -kong-prefix /kong_prefix" >> $configfile
    echo "pluginserver_${plugin}_start_cmd = /usr/local/bin/${plugin} -kong-prefix /kong_prefix" >> $configfile
done

