# Kong image with custom Go plugins

## Running Kong locally

### As compose

Get username and password from LSEG Artifactory and fill in below command:

First build code:

```bash
podman compose build --build-arg="ARTIFACTORY_USERNAME={NAME.SURNAME}" --build-arg="ARTIFACTORY_PASSWORD={ARTIFACTORY_PASSWORD}"
```

To test downstream_plugin you need to set AZURE_CLIENT_SECRET env variable, it's value for dev SPN can be found in Vault or AKS

```bash
export AZURE_CLIENT_SECRET=asdasdqweqweqweqweqw
```

Second run code:

```bash
podman compose up
```

`Kong` will come configured with `echo` endpoint. To test it, you can use this script:

```bash
curl localhost:8000/echo
```

If you want to see Kong configuration, you can go to UI under `http://localhost:8002`

To change `Kong` configuration, edit `kong.yml` file.

To stop `Kong` run, use this script:

```bash
podman compose down
```

Note: as custom plugins are now configured to use kong_prefix (for k8s compatibility), we nee to have amount specified.
You can change the source folder to whatever value, but the target must be 'kong_prefix' as it is hardcoded into the Kong helm chart.

### As individual images

Get username and password from LSEG Artifactory and fill in below command:

First build code:

```bash
podman build --build-arg="ARTIFACTORY_USERNAME={NAME.SURNAME}" --build-arg="ARTIFACTORY_PASSWORD={ARTIFACTORY_PASSWORD}" --tag konglocal:latest .
```

To run Kong in DB mode, postgresql image is required. Here is an example of using container for that:

```bash
podman run -d --name kong-database \
  -p 5432:5432 \
  -e "POSTGRES_USER=kong" \
  -e "POSTGRES_DB=kong" \
  -e "POSTGRES_PASSWORD=kongpass" \
  docker.io/postgres:13
```

Having fresh DB or using new Kong version we need to bootstrap DB. In this example locally build Kong image is used as well as WSL IP (vary, use your own):

```bash
podman run --rm \
 -e "KONG_DATABASE=postgres" \
 -e "KONG_PG_HOST=172.28.56.152" \
 -e "KONG_PG_PASSWORD=kongpass" \
 -e "KONG_PASSWORD=test" \
  konglocal:latest kong migrations bootstrap
```

You might want to use a few environment variables:

- KONG_LICENSE_DATA - premium license, required for version 3.10+ or to see the custom plugins in UI.
- GLOBAL_PLUGIN_SETTINGS - default config to use for our custom plugins, here is an example '{"cache_configuration": {"redis_enabled": true,"redis_url": "172.28.56.152:6379","redis_is_cluster": false,"redis_is_tls": false,"redis_username": "","redis_password": "","inmemory_enabled": true}}'
- PLUGIN_PARAMETERS - additional plugin parameters which can be accessed from some plugin supporting environment variables value. Mostly to pass credentials (e.g. for PING). Sample: '{"ping-client-id":"use proper one here","ping-client-secret": "use proper one here","redis-password":"foobared","LOG_LEVEL":"debug"}'
- KONG_LOG_LEVEL - set kong log level
Add chosen ones to the below list like this:

```bash
 -e "KONG_LOG_LEVEL=debug" \
 -e "KONG_LICENSE_DATA=$KONG_LICENSE_DATA" \
 -e "KONG_NGINX_MAIN_ENV=PLUGIN_PARAMETERS; env GLOBAL_PLUGIN_SETTINGS" \
 -e "PLUGIN_PARAMETERS=$PLUGIN_PARAMETERS" \
 -e "GLOBAL_PLUGIN_SETTINGS=$GLOBAL_PLUGIN_SETTINGS" \
```

Note: as custom plugins are now configured to use kong_prefix (for k8s compatibility), we nee to have amount specified.
You can change the source folder to whatever value, but the target must be 'kong_prefix' as it is hardcoded into the Kong helm chart.

```bash
 -v "./kong_prefix:/kong_prefix" \
 -e "KONG_PREFIX=/kong_prefix" \
```

```bash
podman run -d --name kong-gateway \
 -v "./kong_prefix:/kong_prefix" \
 -e "KONG_PREFIX=/kong_prefix" \
 -e "KONG_DATABASE=postgres" \
 -e "KONG_PG_HOST=172.28.56.152" \
 -e "KONG_PG_USER=kong" \
 -e "KONG_PG_PASSWORD=kongpass" \
 -e "KONG_PROXY_ACCESS_LOG=/dev/stdout" \
 -e "KONG_ADMIN_ACCESS_LOG=/dev/stdout" \
 -e "KONG_PROXY_ERROR_LOG=/dev/stderr" \
 -e "KONG_ADMIN_ERROR_LOG=/dev/stderr" \
 -e "KONG_ADMIN_LISTEN=0.0.0.0:8001" \
 -e "KONG_ADMIN_GUI_URL=http://localhost:8002" \
 -e "KONG_UNTRUSTED_LUA_SANDBOX_REQUIRES=cjson.safe" \
 --cap-add=SYS_PTRACE \
 -p 5555:5555 \
 -p 8000:8000 \
 -p 8443:8443 \
 -p 8001:8001 \
 -p 8444:8444 \
 -p 8002:8002 \
 -p 8445:8445 \
 -p 8003:8003 \
 -p 8004:8004 \
 konglocal:latest
```

Optionally run redis locally:

```bash
 podman run -d --name kong-redis -p 6379:6379 docker.io/redis:6.2-alpine

```

## Working with plugins

As we have multiple plugins (modules) in the same repository, Go workspace feature is used [Documentation](https://go.dev/ref/mod#workspaces)
"goplugins" folder is the workspace root. Each module (plugins or common library) should be in separate subfolders. Build script will iterate each folder and build it.

### Adding new module (plugin)

1. Create the module folder inside "goplugins". E.g. `mkdir my_plugin_name && cd my_plugin_name`
2. Init the Go module `go mod init my_plugin_name`
3. Add the module to workspace `go work use my_plugin_name` (note: in case subfolder name != module name, use subfolder here, or its relative path)

## Updating dependencies

Run `bash ./update.sh` to update dependencies for all modules & vendor them in workspace. Preferably do so & commit changes before creating the merge request.

### Details (updating dependencies manually)

Modules handling is still done on per module level, so don't forget to run `go mod tidy` from time to time.

~~Note: until issue with go packages access in CI resolved, module vendoring is used.~~
~~For workspaces, vendoring is global, so "vendor" folder is in workspace root. Run `go work vendor` from 'goplugins' folder before commit to update all dependencies.~~
GOPROXY is set to LSEG Artifactory now, so we do not need vendor anymore.
